Explanation of the native libs location:

http://stackoverflow.com/a/20886180/986533

  "As Xavier said, you can put your prebuilts in /src/main/jniLibs/ if you are using gradle 0.7.2+
  taken from: https://groups.google.com/d/msg/adt-dev/nQobKd2Gl_8/ctDp9viWaxoJ"

