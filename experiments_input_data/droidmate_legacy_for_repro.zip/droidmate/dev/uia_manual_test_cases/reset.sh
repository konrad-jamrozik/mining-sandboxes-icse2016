#!/bin/bash

adb shell pm clear $1