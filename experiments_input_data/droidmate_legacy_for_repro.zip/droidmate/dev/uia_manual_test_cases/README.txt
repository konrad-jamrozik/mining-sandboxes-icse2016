By Konrad on Feb 9, 2015

How this project came to be:
1. Created a new java project in IntelliJ // Based on [1], adapted to IntelliJ
2. Added uiautomator.jar and android.jar // Based on [1]
3. Ran command from [2] The command was:
android create uitest-project -n uia_manual_test_cases -t 1 -p .

[1] http://developer.android.com/tools/testing/testing_ui.html
[2] http://developer.android.com/tools/testing/testing_ui.html#builddeploy