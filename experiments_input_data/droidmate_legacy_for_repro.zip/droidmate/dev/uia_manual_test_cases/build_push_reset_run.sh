#!/bin/bash
./build_push.sh
./reset.sh $3
./run.sh $1 $2