#!/bin/bash
./build_push.sh
./run.sh $1 $2