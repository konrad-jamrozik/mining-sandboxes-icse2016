#!/bin/bash

adb shell am force-stop $1