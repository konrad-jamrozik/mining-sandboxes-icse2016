
  Copyright (c) 2012-2015 Saarland University Software Engineering Chair.
  All right reserved.

  Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de

  This file is part of the "DroidMate" project.

  www.droidmate.org

--------------------------------------------------------------------------------
About this file
--------------------------------------------------------------------------------

This file pertains to DroidMate source. It gives brief introduction to what
DroidMate is, how to build, contribute to and run DroidMate. It also tells where
to seek for detailed technical documentation of DroidMate. The README
of DroidMate distribution can be found here:

  ./projects/core/src/dist/README.txt

--------------------------------------------------------------------------------
About DroidMate
--------------------------------------------------------------------------------

Introductory information about DroidMate is provided in DroidMate_primer.pdf
you should have obtained from me. If not, contact me.

--------------------------------------------------------------------------------
Building and running DroidMate
--------------------------------------------------------------------------------

DroidMate is built with Gradle, the build script being ./build.gradle

The commands below assume you work on Linux or Mac OS. If you work on Windows,
substitute "./gradlew" with "gradlew.bat".

A step by step guide how to build and run DroidMate:

Ask Konrad (located in his OneNote)

--------------------------------------------------------------------------------
Working with DroidMate code base
--------------------------------------------------------------------------------

I am developing DroidMate using IntelliJ IDEA, but configuring your
IntelliJ IDE is not supported yet (deadline, you know... but I will get
around to this eventually). If you try to import DroidMate's IntelliJ IDEA
project to your IDE instance let me know, I'll help you as much as possible
and write down solutions to your difficulties to spare tears of those who will
come after you.

--------------------------------------------------------------------------------
Repositories
--------------------------------------------------------------------------------

DroidMate repository address is:

  https://hg.st.cs.uni-saarland.de/git/droidmate

Only I have write access to it. The file you are reading right now should have
been obtained by you by cloning the repository. If this is not the case and you
want read access to the repository, contact me.

While only I can write to DroidMate repository, anybody approved can read and
write to DroidMate-contrib repository, whose address is:

  https://hg.st.cs.uni-saarland.de/git/droidmate-contrib

This repository holds contributions from DroidMate collaborators.
Some of the contributions might have been pulled by me to the DroidMate repo,
but some of them might be available only in DroidMate-contrib, under the branch
with name of the contributor.

If you are reading this file you should already have read & write access to the
DroidMate-contrib repo. If not, contact me.

--------------------------------------------------------------------------------
How to contribute
--------------------------------------------------------------------------------

To contribute to DroidMate, use the following workflow:

1. clone the DroidMate repo to your local machine.
2. implement the contribution, pushing to DroidMate-contrib, to branch named
the same as your surname.
2. when the feature is mature enough, ask me to pull from your branch in
DroidMate-contrib.

--------------------------------------------------------------------------------
Source code documentation dictionary
--------------------------------------------------------------------------------

AUE   : Application/Apk Under Exploration
AUT   : Application/Apk Under Test
AVD   : Android (Virtual) Device
-> AVD is a real device or an emulator.

--------------------------------------------------------------------------------
Architectural overview of DroidMate
--------------------------------------------------------------------------------

The main code of DroidMate is in the "core" project, which also is the
frontend for DroidMate and so, can be built into executable distribution.

The "aut-addon" is an Android project built with Android ant script.
The resulting .dex file is the put into 's resources dir, to be used in the
instrumentation of the apk. Thus, the source code of aut-addon effectively is
the source code of the bytecode that will be attached to the apk on which
DroidMate will operate.

The "uiautomator-daemon" project is an Android uiautomator scripts project built
with Android ant script, resulting in jar file that can be run on Android
(Virtual) Device (AVD) using uiautomator. The output .jar is, like output
of aut-addon, is placed in core's resources dir. DroidMate deploys
uiautomator-daemon.jar to the device, establishes TCP connection with it and
uses it to extract the device xml GUI hierarchy and to click on the AVD.

The "common" project contains code reused by two or more of the aforementioned
projects.

All the remaining projects (scratchpad, javaScratchpad, soot-instrumenter) are
irrelevant.

Note that all the operations like copying the output .jar file happen when
appropriate tasks are called from the build.gradle script.

--------------------------------------------------------------------------------
Detailed technical documentation
--------------------------------------------------------------------------------
Please search for file named "DroidmateFrontend.groovy" and read its javadoc.
It contains references to all other relevant javadocs, guiding you through
DroidMate code.
