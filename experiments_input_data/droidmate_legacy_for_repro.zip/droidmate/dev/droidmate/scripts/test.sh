#!/bin/bash
echo <(`./read_manual_run_log.sh`)