#!/bin/bash

java -jar c:/my/local/repos/chair/droidmate/dev/droidmate/projects/core/src/main/resources/apktool.jar decode --no-src --force $1