// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org

package org.droidmate.apis

import org.droidmate.common.logcat.Api

class ApiMapping
{

  final List<ApiMethodSignature> apis

  ApiMapping(
    List<String> jellybeanPublishedApiMapping,
    List<String> jellybeanStaticMethods,
    List<String> appguardMonitoredApis)
  {
    assert jellybeanPublishedApiMapping.size() > 0

    List<Map<String, String>> staticMethodsInfo = jellybeanStaticMethods.findAll {
      it.size() > 0 && !(it.startsWith("#"))
    }.collect {
      def (objectClass, methodName) = it.tokenize("->");
      return [objectClass: objectClass, methodName: methodName] as Map<String, String>
    }

    List<ApiMethodSignature> pscoutApis = parsePscoutApis(jellybeanPublishedApiMapping, staticMethodsInfo)

    List<ApiMethodSignature> appguardApis = parseAppguardApis(appguardMonitoredApis)

    this.apis = pscoutApis + appguardApis
    this.apis.each {it.assertValid()}
    pscoutApis.each {def psApi ->
      appguardApis.each {def appgApi ->
        if (psApi.distinctSignature == appgApi.distinctSignature)
          assert psApi.returnClass == appgApi.returnClass
      }
    }

    this.apis.unique {it.distinctSignature}
    this.apis.sort {it.paramClasses.size()}.sort {it.methodName}.sort {it.objectClass}
  }

  private static List<ApiMethodSignature> parsePscoutApis(List<String> apiMapping, List<Map<String, String>> staticMethodsInfo)
  {
    // methodSignature: e.g. <android.nfc.NfcAdapter: void enableForegroundDispatch(android.app.Activity,android.app.PendingIntent,android.content.IntentFilter[],java.lang.String[][])>
    return apiMapping.findAll {it.startsWith("<")}.collect {String methodSignature ->

      // objectClass: e.g. android.nfc.NfcAdapter
      def (objectClass, methodHeader) = methodSignature[1..-2].tokenize(":")

      methodHeader = (methodHeader as String)[1..-1] // e.g. void enableForegroundDispatch(android.app.Activity,android.app.PendingIntent,android.content.IntentFilter[],java.lang.String[][])

      def (returnClass, methodBody) = methodHeader.tokenize(" ")
      def (methodName, methodParams) = methodBody.tokenize("(")

      // e.g. void
      // The replacement of _ with space is done for generics, e.g. generic "<T> T" is encoded as "<T>_T" to simplify tokenizing, by allowing tokenizing by space without ripping apart returnClass.
      returnClass = returnClass.replace("\$", ".").replace("_", " ")

      methodName = methodName.replace("\$", "_") // e.g. enableForegroundDispatch

      methodParams = methodParams.replace(")", "") // e.g. android.app.Activity,android.app.PendingIntent,android.content.IntentFilter[],java.lang.String[][]
      List<String> paramsList = methodParams.tokenize(",")
      paramsList = paramsList.collectNested {
        it.replace("\$", ".").replace("_", " ")
      } // e.g. [android.app.Activity, android.app.PendingIntent, android.content.IntentFilter[], java.lang.String[][]]

      boolean isStatic = false;
      if (staticMethodsInfo.any {it.objectClass == objectClass && it.methodName == methodName})
        isStatic = true;

      return new ApiMethodSignature(objectClass, returnClass, methodName, paramsList, isStatic)
    }
  }

  /**
   * <p>
   * Parsing done according to:
   *
   * </p><p>
   * <code>
   * http://docs.oracle.com/javase/specs/jvms/se7/html/jvms-4.html#jvms-4.3<br/>
   * </code>
   * </p><p>
   * Additional reference:
   * </p><p>
   * <code>
   * http://docs.oracle.com/javase/6/docs/api/java/lang/Class.html#getName%28%29<br/>
   * http://stackoverflow.com/questions/5085889/l-array-notation-where-does-it-come-from<br/>
   * http://stackoverflow.com/questions/3442090/java-what-is-this-ljava-lang-object<br/>
   * </code>
   * </p>
   */
  public static List<ApiMethodSignature> parseAppguardApis(List<String> apiMapping)
  {
    List<String> processedApiMapping
    processedApiMapping = apiMapping.findAll {it.size() > 0 && !it.startsWith("#")}

    // methodSignature: e.g. Landroid/content/ContentProviderClient;->update(Landroid/net/Uri;ZLandroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/Object; static
    def out = processedApiMapping.collect {String methodSignature ->

      def (objectClass, _) = methodSignature.split("->")
      objectClass = convertJNItypeNotationToSourceCode(objectClass) // e.g. android.content.ContentProviderClient

      def (methodHeader, staticness) = methodSignature.tokenize(" ")
      assert staticness in ["static", "instance", null]
      boolean isStatic = staticness == "static"

      /* This line ensures that if there are no params, the match below will match a one-space string to methodParams, instead of skipping it and matching returnClass to methodParams.
         The matchParameterDescriptors then will properly handle the " " methodParams.
      */
      methodHeader = methodHeader.replace("()", "( )")
      // methodName: e.g. update
      // returnClass: e.g. Ljava/lang/Object;
      def (methodName, methodParams, returnClass) = methodHeader.tokenize("()")

      methodName = methodName.split("->")[1]

      List<String> paramsList = Api.matchClassFieldDescriptors(methodParams)
      paramsList = paramsList.collect {convertJNItypeNotationToSourceCode(it)}
      returnClass = convertJNItypeNotationToSourceCode(returnClass)


      return new ApiMethodSignature(objectClass, returnClass, methodName, paramsList, isStatic)
    }

    out.each {it.assertValid()}
    return out
  }

  static String convertJNItypeNotationToSourceCode(String type)
  {
    StringBuilder out = new StringBuilder()
    int arraysCount = type.count("[")
    type = type.replace("[", "")

    if (type.startsWith("L"))
    {
      assert type.endsWith(";")
      out.append(type[1..-2].replace("/", "."))
    } else
    {
      assert type.size() == 1
      String baseType = type.find {it in Api.baseTypeToSourceMap.keySet()}
      assert baseType != null
      out.append(Api.baseTypeToSourceMap[baseType])
    }


    arraysCount.times {out.append "[]"}
    return out.toString()
  }

  @SuppressWarnings("GroovyUnusedDeclaration")
  private
  static debugPrintln(String methodSignature, String objectClass, String returnClass, String methodName, List<String> paramsList, Boolean isStatic)
  {
    println "signature   $methodSignature"
    println "objectClass $objectClass"
    println "returnClass $returnClass"
    println "methodName  $methodName"
    println "paramsList  $paramsList"
    println "isStatic    $isStatic"
    println ""
  }
}
