// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org

package org.droidmate.logcat

import java.time.format.DateTimeFormatter

// !!! DUPLICATION WARNING !!! with org.droidmate.lib_android.MonitorJavaTemplate
class MonitorConstants
{

  public static final String message_monitor_constructed        = "Monitor constructed."
  /**
   * <p>
   * Example full message:
   * </p><p>
   * {@code M onitor initialized for package org.droidmate.fixtures.apks.monitored}
   * </p>
   */
  public static final String message_prefix_monitor_initialized = "Monitor initialized for package "

  public static DateTimeFormatter monitorTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS")

  public static final String log_level       = "I"
  public static final String tag_monitor_init = "Monitor_init"
  public static final String tag_monitor_serv = "Monitor_server"
  public static final String tag_monitor_api = "Monitored_API_method_call";

  public static final String MONITOR_SRV_COMMAND_GET_LOGS = "getLogs";
  public static final String MONITOR_SRV_COMMAND_GET_TIME = "getTime";
  public static final String MONITOR_SRV_COMMAND_CLOSE = "close";
}
