// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org

package org.droidmate.common.logging


public class LogbackConstants
{

  public static final String LOGS_DIR_PATH = getLogsDirPath()

  private static String getLogsDirPath()
  {
    String logsDir = System.getProperty("logsDir")
    if (logsDir == null)
      return "." + File.separator + "dev1" + File.separator + "logs"
    else
      return "." + File.separator + logsDir
  }

  public static final List<String> fileAppendersUsedBeforeCleanLogsDir = [
    appender_name_master_log,
    appender_name_std_streams,
    appender_name_run_data
  ]

  /**
   * Denotes name of logger for logs that have been obtained from logcat from uiautomator-daemon classes during exploration.
   */
  public static final String logger_name_uiad = "From uiautomator-daemon logcat"

  /**
   * Denotes name of logger for logs that have been obtained from logcat from the loaded monitor class during exploration.
   */
  public static final String logger_name_monitor = "from monitor"

  public static final String appender_name_uiad = "uiad.txt"

  public static final String appender_name_monitor = "monitor.txt"

  public static final String system_prop_stdout_loglevel = "loglevel"

  public static final String appender_name_std_streams = "std_streams.txt"

  public static final String appender_name_master_log = "master_log.txt"

  public static final String appender_name_warnings_log = "warnings.txt"

  public static final String appender_name_run_data = "run_data.txt"

  // WISH More exception hierarchy in the file: which exceptions came together, for which apk. E.g. Apk XYZ, Expl. Act. 150, EX1 attempt failed EX2 attempt failed E3 complete failure.
  public static final String appender_name_exceptions = "exceptions.txt"

  public static final String appender_name_exploration = "exploration.txt"

  public static final String exceptions_log_path = "${LOGS_DIR_PATH}${File.separator}${appender_name_exceptions}"

  public static final String err_log_msg =
    "Please see $exceptions_log_path log for details on the exception."
}
