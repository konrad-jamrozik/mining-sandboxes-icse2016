// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org

// WISH move to org.droidmate.logcat. Now it is not done as it would break deserialization.
package org.droidmate.common.logcat

import groovy.transform.Canonical
import org.droidmate.apis.IApi
import org.droidmate.logcat.IApiLogcatMessage
import org.droidmate.logcat.ITimeFormattedLogcatMessage

/**
 * See {@link IApiLogcatMessage}
 */
@Canonical
class ApiLogcatMessage implements IApiLogcatMessage, Serializable
{
  private static final long serialVersionUID = 1

  @Delegate
  ITimeFormattedLogcatMessage message

  @Delegate
  IApi api

  static ApiLogcatMessage from(ITimeFormattedLogcatMessage logcatMessage)
  {
    assert logcatMessage?.messagePayload?.size() > 0

    IApi monitoredApiCallData = Api.from(logcatMessage.messagePayload)

    return new ApiLogcatMessage(logcatMessage, monitoredApiCallData)
  }

  @Override
  public String toString()
  {
    toLogcatMessage()
  }

  /**
   * <p>
   * If {@code useVarNames} is true, the output string, when treated as code, will evaluate
   * {@code api.paramValues} and {@code api.stackTrace} as variable names instead of constants in a string.
   *
   * </p><p>
   * As an example, if {@code useVarNames} is false, the method will return a string like (not an actual implementation):
   * <pre><code>"lorem ipsum param1: param1value param2: param2value stackTrace: contents"</code></pre>
   * but if set to true it will return:
   * <pre><code>"lorem ipsum param1: "+param1Value+" param2: "+param2Value+" stackTrace: "+stackTrace+""</pre></code>
   *
   * </p>
   */
  static String toLogcatMessagePayload(IApi api, boolean useVarNames = false)
  {
    api.with {
      assert paramTypes.size() == paramValues.size()

      List<String> params = []
      [paramTypes, paramValues].transpose().eachWithIndex {List<String> param, int i ->

        String paramType = param[0].replace(" ",Api.spaceEscapeInParamValue)
        String paramValue = useVarNames ?
          /"+/+param[1]+/+"/ :
          param[1].replace(" ",Api.spaceEscapeInParamValue)

        params << "$paramType $paramValue"
      }

      String actualThreadId = useVarNames ? /"+/+threadId+/+"/ : threadId
      String actualStackTrace = useVarNames ? /"+/+stackTrace+/+"/ : stackTrace

      String paramsStr = params.join(" ")
      // This string has to be kept in sync with the corresponding one in org.droidmate.common.logcat.Api.from
      // !!! DUPLICATION WARNING !!! with org.droidmate.lib_android.MonitorJavaTemplate.MonitorTCPServer#removeSocketInitLogFromMonitorTCPServer
      return "TId: $actualThreadId objCls: $objectClass mthd: $methodName retCls: $returnClass params: $paramsStr stacktrace: $actualStackTrace"
    }
  }


}

