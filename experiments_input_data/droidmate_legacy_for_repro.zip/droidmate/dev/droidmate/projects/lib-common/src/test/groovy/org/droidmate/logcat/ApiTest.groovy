// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org

package org.droidmate.logcat

import groovy.transform.TypeChecked
import org.droidmate.common.logcat.Api
import org.junit.FixMethodOrder
import org.junit.Test
import org.junit.runner.RunWith
import org.junit.runners.JUnit4
import org.junit.runners.MethodSorters

import java.util.regex.Matcher

@TypeChecked
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(JUnit4)
class ApiTest
{

  @Test
  public void "Parses java parameter descriptors"()
  {
    List<String> expected = [
      "Z",
      "C",
      "[[D",
      "Landroid/net/Uri;",
      "[Lclass1;",
      "[Lclas/s2s/x;",
      "J",
      "Landroid/content/ContentValues;",
      "[Z",
      "F",
      "S",
      "[V",
      "[[Ljava/lang/String;"]

    // Act
    List<String> descriptors = Api.matchClassFieldDescriptors(expected.join(""))

    assert descriptors == expected
  }

  @Test
  void "Matches java type patterns"()
  {
    Matcher m

    ["boolean",
     "int",
     "some.class.name",
     "java.lang.String[][]",
     "java.util.List<java.util.String[]>[]",
     "org.apache.http.client.ResponseHandler<?_extends_T>",
     "java.util.List<?_extends_Integer[][]>[]"

    ].each {
      // Act
      m = it =~ Api.javaTypePattern
      assert m.matches() : it
    }
    ["intx","[]<>?"].each {
      // Act
      m = it =~ Api.javaTypePattern
      assert !m.matches() : it
    }
  }


}
