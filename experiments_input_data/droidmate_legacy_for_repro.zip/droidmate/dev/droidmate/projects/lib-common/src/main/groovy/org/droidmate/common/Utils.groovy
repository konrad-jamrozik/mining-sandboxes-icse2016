// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org

package org.droidmate.common

import org.apache.commons.lang3.SystemUtils
import org.droidmate.common.logging.LogbackConstants
import org.slf4j.Logger

import java.nio.file.Files
import java.nio.file.Paths

import static org.droidmate.common.logging.Markers.exceptions

public class Utils
{

  // WISH DRY-violation with `core` Utils class.
  public static String quoteIfIsPathToExecutable(String path)
  {
    if (SystemUtils.IS_OS_WINDOWS)
    {
      if (Files.isExecutable(Paths.get(path)))
        return '"' + path + '"';
      else
        return path;
    } else
    {
      return path;
    }
  }

  public static void quoteAbsolutePaths(String[] stringArray)
  {
    stringArray.eachWithIndex {it, idx ->
      if (new File(it).isAbsolute())
        stringArray[idx] = '"' + it + '"'
    }
  }

  public static boolean attempt(int attempts, Logger log, String description, Closure recover = null, Closure compute)
  {
    int attemptsLeft = attempts
    boolean succeeded = false

    Exception lastException = null
    while (!succeeded && attemptsLeft > 0)
    {
      attemptsLeft--

      String attemptsCounter = "${attempts - attemptsLeft}/$attempts attempt"
      log.trace("Making $attemptsCounter at '$description'")

      try
      {
        succeeded = compute()
        lastException = null
      }
      catch (Exception e)
      {
        succeeded = false
        lastException = e
      }

      if (!succeeded)
      {
        if (lastException != null && attemptsLeft > 0)
        {
          log.warn("Got exception from failed $attemptsCounter of executing '$description'. Exception msg: $lastException.message $LogbackConstants.err_log_msg")
          // WISH Log it to a separate, new file, like "attempts" or "soft exceptions" or "non-fatal exceptions" or something. Maybe classify exceptions in multiple levels: attempt fail (e.g. launch main act), expl action fail (e.g. all attempts exhausted), apk expl fail (e.g. no clickable stuff - this is not exception as of right now), entire expl fail (assertion fail)
          log.error(exceptions, "Got exception from failed $attemptsCounter of executing '$description':\n", lastException)
        }
        if (lastException == null)
          log.warn("$attemptsCounter at '$description' failed.")

        if (recover != null)
        {
          log.trace("Recovering from a failed attempt $attemptsCounter at '$description'")
          recover()
        }

        if (attemptsLeft > 0)
          sleep(2000)
      }

    }

    assert succeeded || attemptsLeft == 0
    assert succeeded.implies(lastException == null)

    if (lastException != null)
      throw lastException

    return succeeded
  }
}
