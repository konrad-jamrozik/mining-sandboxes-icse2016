// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org
package org.droidmate.lib_android;

import org.junit.FixMethodOrder;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.junit.runners.MethodSorters;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(JUnit4.class)
public class MonitorJavaTemplateTest
{
  private static SimpleDateFormat monitorTimeFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US);

  /**
   * Failed attempt at replicating bug in org.droidmate.lib_android.MonitorJavaTemplate#addCurrentLogs(java.lang.String)
   */
  @Ignore
  @Test
  public void messageFormatBugTest()
  {
    // The bug manifested itself at date: '2015-0008-05 09:24:12.163'
    final String time = monitorTimeFormatter.format(new Date(2015, 8, 5, 9, 24, 12));
    System.out.println(time);
  }

}