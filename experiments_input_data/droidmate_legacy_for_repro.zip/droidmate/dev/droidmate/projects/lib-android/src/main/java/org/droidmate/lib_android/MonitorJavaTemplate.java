// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org

package org.droidmate.lib_android;
// TODO in Monitor.java.template:
// package org.droidmate.monitor_generator.generated;

import android.annotation.SuppressLint;
import android.util.Log;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.text.SimpleDateFormat;
import java.util.*;

// TODO in Monitor.java.template: uncomment
// import de.uds.infsec.instrumentation.Instrumentation;
// import de.uds.infsec.instrumentation.annotation.Redirect;
// import de.uds.infsec.instrumentation.util.Signature;

/**<p>
 * The {@code MonitorJavaTemplate} class exists solely for developer convenience when attempting to edit
 * <pre><code>
 *   [repo root]\dev\droidmate\projects\monitor-generator\src\main\resources\Monitor.java.template
 * </code></pre>
 *
 * </p><p>
 * Just edit this file, then copy-paste it into the destination file of {@code Monitor.java.template} and manually adjust all the locations marked with TODO.
 *
 * </p><p>
 * Note that the final generated version of this file, after running {@code :projects:monitor-generator:build}, will be placed in
 * <pre><code>
 *   [repo root]\dev\droidmate\projects\monitor-generator\monitor-apk-scaffolding\src\org\droidmate\monitor_generator\generated\Monitor.java
 * </code></pre>
 *
 * </p><p>
 * Finally, take note that there is a copy of the final generated version of serving as an oracle expectation for the test of
 * {@code org.droidmate.monitor_generator.MonitorGeneratorFrontendTest#Generates DroidMate monitor()}.
 *
 * </p><p>
 * The copy can be found here:
 * <pre><code>
 *   [repo root]\dev\droidmate\projects\monitor-generator\src\test\resources\generated\Monitor_for_testing.java
 * </code></pre>
 * </p><p>
 *   See also: {@code org.droidmate.monitor_generator.RedirectionsGenerator}
 *
 * </p>
 */
// TODO in Monitor.java.template: rename everywhere to Monitor
// The resulting Monitor.java deployed to the device will be compiled with legacy ant script from Android SDK that supports only Java 5.
@SuppressWarnings("Convert2Diamond")
@SuppressLint("NewApi")
public class MonitorJavaTemplate
{

  // !!! DUPLICATION WARNING !!! with org.droidmate.logcat.MonitorConstants
  public static final String TAG_MONITOR_INIT = "Monitor_init";
  public static final String TAG_MONITOR_SERV = "Monitor_server";
  public static final String TAG_MONITOR_API  = "Monitored_API_method_call";

  // !!! DUPLICATION WARNING !!! with org.droidmate.common_android.Constants.MONITOR_SERVER_PORT
  public static final int    MONITOR_SERVER_PORT      = 59776;
  public static final String MONITOR_SERVER_START_TAG = "monitor_server_start_tag";
  public static final String MONITOR_SERVER_START_MSG = "Monitor server started successfully";

  // !!! DUPLICATION WARNING !!! with org.droidmate.logcat.MonitorConstants
  private static final String MONITOR_SRV_COMMAND_GET_LOGS = "getLogs";
  private static final String MONITOR_SRV_COMMAND_GET_TIME = "getTime";
  private static final String MONITOR_SRV_COMMAND_CLOSE    = "close";
  // End of DUPLICATION WARNING

  // !!! DUPLICATION WARNING !!! with many places in "core" project. Just hard-coded there.
  private static final String STACK_TRACE_FRAME_DELIMITER = "->";

  //region Class init code
  public MonitorJavaTemplate()
  {
    startTCPServer();

    // !!! DUPLICATION WARNING !!! with org.droidmate.logcat.MonitorLogcatMessages
    Log.i(TAG_MONITOR_INIT, "Monitor constructed.");
  }

  public void init(android.content.Context context)
  {
    // TODO in Monitor.java.template: uncomment
    // Instrumentation.processClass(Monitor.class);

    redirectConstructors();

    // !!! DUPLICATION WARNING !!! with org.droidmate.logcat.MonitorLogcatMessages
    Log.i(TAG_MONITOR_INIT, "Monitor initialized for package " + context.getPackageName());
  }
  //endregion

  //region TCP server code

  private static void startTCPServer()
  {
    MonitorTCPServer tcpServer = new MonitorTCPServer(MONITOR_SERVER_START_TAG, MONITOR_SERVER_START_MSG);

    Log.i(TAG_MONITOR_SERV, "Starting TCP server...");

    Thread serverThread = null;
    try
    {
      serverThread = tcpServer.start(MONITOR_SERVER_PORT);
    } catch (InterruptedException e)
    {
      Log.e(TAG_MONITOR_SERV, "Starting TCP server failed.", e);
    }
    if (serverThread == null) throw new AssertionError();
    if (tcpServer.isClosed()) throw new AssertionError();
    Log.i(TAG_MONITOR_SERV, "Starting TCP server succeeded.");
  }

  static class MonitorTCPServer extends SerializableTCPServerBase<String, ArrayList<ArrayList<String>>>
  {
    private final static String monitorTcpServerClassName = MonitorTCPServer.class.getSimpleName();

    protected MonitorTCPServer(String serverStartMessageTag, String serverStartMessage)
    {
      super(serverStartMessageTag, serverStartMessage);
    }

    @Override
    protected ArrayList<ArrayList<String>> OnServerRequest(String input, Exception inputEx)
    {
      // KJA2 handle exceptions: inputException and anything that can result from executing this method. See org.droidmate.uiautomatordaemon.UiAutomatorDaemonServer.OnServerRequest()
      if (Objects.equals(input, MONITOR_SRV_COMMAND_GET_LOGS))
      {
        removeSocketInitLogFromMonitorTCPServer(currentLogs);
        ArrayList<ArrayList<String>> logsToSend = new ArrayList<ArrayList<String>>(currentLogs);
        currentLogs.clear();
        return logsToSend;

      } else if (Objects.equals(input, MONITOR_SRV_COMMAND_GET_TIME))
      {
        final String time = monitorTimeFormatter.format(new Date());
        final ArrayList<String> payload = new ArrayList<String>(Arrays.asList(time, null, null));

        Log.d(monitorTcpServerClassName, "Sending time: " + time);

        return new ArrayList<ArrayList<String>>(Collections.singletonList(payload));

      } else if (Objects.equals(input, MONITOR_SRV_COMMAND_CLOSE))
      {
        // Do nothing here. The command will be handled in org.droidmate.lib_android.MonitorJavaTemplate.MonitorTCPServer.shouldCloseServerSocket
        return new ArrayList<ArrayList<String>>();

      } else
      {
        Log.wtf(monitorTcpServerClassName, "Unexpected command from DroidMate TCP client. The command: " + input);
        return new ArrayList<ArrayList<String>>();
      }
    }

    private void removeSocketInitLogFromMonitorTCPServer(ArrayList<ArrayList<String>> currentLogs)
    {
      ArrayList<ArrayList<String>> logsToRemove = new ArrayList<ArrayList<String>>();
      for (ArrayList<String> log : currentLogs)
      {
        String msgPayload = log.get(2);
        // !!! DUPLICATION WARNING !!! with org.droidmate.common.logcat.ApiLogcatMessage.toLogcatMessagePayload(org.droidmate.apis.IApi, boolean)
        int stacktraceIndex = msgPayload.lastIndexOf("stacktrace: ");
        if (stacktraceIndex == -1)
          throw new AssertionError("The message payload was expected to have 'stacktrace: ' substring in it");
        String stackTrace = msgPayload.substring(stacktraceIndex);
        String[] frames = stackTrace.split(STACK_TRACE_FRAME_DELIMITER);
        if (frames.length >= 2)
        {
          String secondLastFrame = frames[frames.length - 2];
          if (secondLastFrame.startsWith("org.droidmate"))
          {
            if (!secondLastFrame.startsWith("org.droidmate.monitor_generator.generated.Monitor")) throw new AssertionError();
            if (!anyContains(frames, "Socket.<init>")) throw new AssertionError();
            logsToRemove.add(log);
          }
        }
      }

      // Zero logs to remove can happen when the TCP server started to accept socket from client before monitor finished initing.
      // In all other cases there should be one log.
      if (logsToRemove.size() > 1) throw new AssertionError(
        "Expected to remove zero or one logs of Socket.<init>, caused by monitor TCP server. Instead, removed "
          + logsToRemove.size() + " logs.");

      if (logsToRemove.size() == 1)
        currentLogs.remove(logsToRemove.get(0));

    }

    private boolean anyContains(String[] strings, String s)
    {
      for (String string : strings)
      {
        if (string.contains(s))
          return true;
      }
      return false;
    }

    @Override
    protected boolean shouldCloseServerSocket(String serverInput)
    {
      return Objects.equals(serverInput, "close");
    }
  }

  // !!! DUPLICATION WARNING !!! with org.droidmate.lib_android.SerializableTCPServerBase
  static abstract class SerializableTCPServerBase<ServerInputT extends Serializable, ServerOutputT extends Serializable>
  {

    private int port;
    ServerSocket serverSocket;

    private String serverStartMessageTag;
    private String serverStartMessage;

    private final static String thisClassName = SerializableTCPServerBase.class.getSimpleName();

    protected SerializableTCPServerBase(String serverStartMessageTag, String serverStartMessage)
    {
      this.serverStartMessageTag = serverStartMessageTag;
      this.serverStartMessage = serverStartMessage;

    }

    protected abstract ServerOutputT OnServerRequest(ServerInputT input, Exception inputReadEx);

    protected abstract boolean shouldCloseServerSocket(ServerInputT serverInput);

    // Used in org.droidmate.uiautomatordaemon.UiAutomatorDaemon.init()
    public Thread start(int port) throws InterruptedException
    {

      try
      {
        this.port = port;
        MonitorServerRunnable monitorServerRunnable = new MonitorServerRunnable();
        Thread serverThread = new Thread(monitorServerRunnable);

        //noinspection SynchronizationOnLocalVariableOrMethodParameter
        synchronized (monitorServerRunnable)
        {
          assert (serverSocket == null);
          serverThread.start();
          monitorServerRunnable.wait();
          assert (serverSocket != null);
        }
        Log.i(serverStartMessageTag, serverStartMessage);

        return serverThread;

      } catch (InterruptedException e)
      {
        throw e;
      }
    }

    public void close()
    {
      try
      {
        serverSocket.close();
      } catch (IOException e)
      {
        Log.wtf(thisClassName, "Failed to close SerializableTCPServerBase.");
      }
    }

    // Used in org.droidmate.uiautomatordaemon.UiAutomatorDaemon.init()
    public boolean isClosed()
    {
      return serverSocket.isClosed();
    }

    private class MonitorServerRunnable implements Runnable
    {

      public final String monitorServerRunnableClassName = MonitorServerRunnable.class.getSimpleName() + port;

      public void run()
      {

        Log.d(monitorServerRunnableClassName, "Started MonitorServerRunnable.");
        try
        {

          // Synchronize to ensure the parent thread (the one which started this one) will continue only after the
          // serverSocket is initialized.
          synchronized (this)
          {
            Log.d(monitorServerRunnableClassName, String.format("Creating server socket bound to port %s...", port));
            /*
            This call might cause: java.net.BindException: bind failed: EADDRINUSE (Address already in use).

            This can be seen in logcat in log tagged E/MonitorServerRunnable59776.

            In such case manually kill the app. Note the address might be held by another app, that was explored next. To find and kill it, do:
            adb shell
            ps // find the package name
            am force-stop <package_name>

            Also note some of the explored apps, like com.antivirus, can start on system startup, thus rebooting the device won't release the port!

            WISH actually this could be somewhat automated: on droidmate launch, find all processes with package names and force stop them.
            Maybe adb shell am force-stop <package name from adb shell ps>
            See http://stackoverflow.com/questions/3117095/stopping-an-android-app-from-console
             */
            serverSocket = new ServerSocket(port);
            this.notify();
          }

          while (!serverSocket.isClosed())
          {
            Log.d(monitorServerRunnableClassName, String.format("Accepting socket from client on port %s...", port));
            Socket clientSocket = serverSocket.accept();
            Log.v(monitorServerRunnableClassName, "Socket accepted.");

            ObjectOutputStream output = new ObjectOutputStream(clientSocket.getOutputStream());

          /*
           * Flushing done to prevent client blocking on creation of input stream reading output from this stream. See:
           * org.droidmate.device.SerializableTCPClient.queryServer
           *
           * References:
           * 1. http://stackoverflow.com/questions/8088557/getinputstream-blocks
           * 2. Search for: "Note - The ObjectInputStream constructor blocks until" in:
           * http://docs.oracle.com/javase/7/docs/platform/serialization/spec/input.html
           */
            output.flush();

            ObjectInputStream input = new ObjectInputStream(clientSocket.getInputStream());

            ServerInputT serverInput = null;

            Exception serverInputReadEx = null;

            try
            {
              @SuppressWarnings("unchecked") // Without this var here, there is no place to put the "unchecked" suppression warning.
                ServerInputT localVarForSuppressionAnnotation = (ServerInputT) input.readObject();
              serverInput = localVarForSuppressionAnnotation;

            } catch (ClassNotFoundException e)
            {
              serverInputReadEx = handleInputReadObjectException(input, e);
            } catch (IOException e)
            {
              serverInputReadEx = handleInputReadObjectException(input, e);
            }

            ServerOutputT serverOutput;
            serverOutput = OnServerRequest(serverInput, serverInputReadEx);
            output.writeObject(serverOutput);
            clientSocket.close();

            if (shouldCloseServerSocket(serverInput))
              close();
          }

          Log.d(monitorServerRunnableClassName, "Closed MonitorServerRunnable.");

        } catch (SocketTimeoutException e)
        {
          Log.e(monitorServerRunnableClassName, "Closing MonitorServerRunnable due to a timeout.", e);
          close();
        } catch (IOException e)
        {
          Log.e(monitorServerRunnableClassName, "Exception was thrown while operating MonitorServerRunnable", e);
        }
      }

      private Exception handleInputReadObjectException(ObjectInputStream input, Exception e) throws IOException
      {
        Exception serverInputReadEx;
        Log.e(monitorServerRunnableClassName, "Exception was thrown while reading input sent to MonitorServerRunnable from " +
          "client through socket.", e);
        serverInputReadEx = e;
        input.close();
        return serverInputReadEx;
      }
    }
  }
  //endregion

  //region Helper code
  private static ArrayList<Integer> ctorHandles = new ArrayList<Integer>();

  private static String getStackTrace()
  {
    StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
    StringBuilder sb = new StringBuilder();
    for (int i = 0; i < stackTrace.length; i++)
    {
      sb.append(stackTrace[i].toString());
      if (i < stackTrace.length - 1)
        sb.append(STACK_TRACE_FRAME_DELIMITER);
    }
    return sb.toString();
  }

  private static long getThreadId()
  {
    return Thread.currentThread().getId();
  }

  private static String convert(Object param)
  {
    if (param == null)
      return "null";

    String paramStr;
    if (param.getClass().isArray())
    {
      StringBuilder sb = new StringBuilder("[");
      boolean first = true;

      for (Object item : (Object[]) param)
      {
        if (first)
          first = false;
        else
          sb.append(", ");

        sb.append(String.format("%s", item));
      }
      sb.append("]");

      paramStr = sb.toString();
    } else if (param instanceof android.content.Intent)
    {
      paramStr = ((android.content.Intent) param).toUri(1);
      assert paramStr.endsWith("end");

      /*
        Logcat buffer size is 4096 [1]. I have encountered a case in which intent's string extra has eaten up entire log line,
        preventing the remaining parts of the log (in particular, stack trace) to be transferred to DroidMate,
        causing regex match fail. This is how the offending intent value looked like:

          intent:#Intent;action=com.picsart.studio.notification.action;S.extra.result.string=%7B%22response%22%3A%5B%7B%...
          ...<and_so_on_until_entire_line_buffer_was_eaten>

        [1] http://stackoverflow.com/questions/6321555/what-is-the-size-limit-for-logcat
      */
      if (paramStr.length() > 1024)
      {
        paramStr = paramStr.substring(0, 1024 - 24) + "_TRUNCATED_TO_1000_CHARS" + "end";
      }

    } else
    {
      paramStr = String.format("%s", param);
      if (paramStr.length() > 1024)
      {
        paramStr = paramStr.substring(0, 1024 - 24) + "_TRUNCATED_TO_1000_CHARS";
      }
    }

    // !!! DUPLICATION WARNING !!! with: org.droidmate.logcat.Api.spaceEscapeInParamValue
    // solution would be to provide this method with an generated code injection point.
    // end of duplication warning
    return paramStr.replace(" ", "_");
  }

  // !!! DUPLICATION WARNING !!! with org.droidmate.logcat.MonitorConstants.monitorTimeFormatter
  private static SimpleDateFormat monitorTimeFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US);

  private static void addCurrentLogs(String payload)
  {
    // KNOWN BUG this resulted in '2015-0008-05 09:24:12.163' which is unparseable with the same time formatter at org.droidmate.exploration.ApiLogsReader.extractLogcatMessagesFromTcpMessages()
    String now = monitorTimeFormatter.format(new Date());
    currentLogs.add(new ArrayList<String>(Arrays.asList(getPid(), now, payload)));
  }

  private static String getPid()
  {
    return String.valueOf(android.os.Process.myPid());
  }

  static ArrayList<ArrayList<String>> currentLogs = new ArrayList<ArrayList<String>>();

  //endregion

  //region Generated code

  private static void redirectConstructors()
  {
    ClassLoader[] classLoaders = {Thread.currentThread().getContextClassLoader(), MonitorJavaTemplate.class.getClassLoader()};

    // GENERATED_CODE_INJECTION_POINT:CTOR_REDIR_CALLS
  }

  // GENERATED_CODE_INJECTION_POINT:CTOR_REDIR_TARGETS

  // GENERATED_CODE_INJECTION_POINT:METHOD_REDIR_TARGETS

  //endregion


}

