// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org

package org.droidmate.monitor_generator

import groovy.transform.TypeChecked
import org.droidmate.common.ResourcePath
import org.droidmate.init.InitConstants
import org.junit.FixMethodOrder
import org.junit.Ignore
import org.junit.Test
import org.junit.runner.RunWith
import org.junit.runners.JUnit4
import org.junit.runners.MethodSorters

import java.nio.file.Files
import java.nio.file.Path

import static groovy.transform.TypeCheckingMode.SKIP

@TypeChecked(SKIP)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(JUnit4)
public class MonitorGeneratorFrontendTest
{
  @Ignore("This test usually just irritates me after I update the monitor.java.template but forget to update expectedMonitorJava here")
  @Test
  public void "Generates DroidMate monitor"()
  {
    Path expectedMonitorJava = new ResourcePath("generated/Monitor_for_testing.java").path
    Path actualMonitorJava = InitConstants.monitor_generator_generated_monitor
    assert Files.notExists(actualMonitorJava) || Files.isWritable(actualMonitorJava)

    MonitorGeneratorFrontend.handleException = { Exception e -> throw e }

    // Act
    MonitorGeneratorFrontend.main([] as String[])

    assert Files.isRegularFile(actualMonitorJava)

    List<String> expectedLines = expectedMonitorJava.readLines()
    List<String> actualLines = actualMonitorJava.readLines()

    expectedLines.eachWithIndex {String expectedLine, int i ->
      if (actualLines.size() < i)
        assert false : "Line number $i doesn't exist in actual result. The missing expected line: $expectedLine"
      String actualLine = actualLines[i]
      assert expectedLine == actualLine : "Difference at line $i:\nExpected: $expectedLine\nActual: $actualLine"
    }
    assert expectedLines.size() == actualLines.size() : "Sizes differ. Expected: ${expectedLines.size()}. Actual: ${actualLines.size()}"
  }
}

