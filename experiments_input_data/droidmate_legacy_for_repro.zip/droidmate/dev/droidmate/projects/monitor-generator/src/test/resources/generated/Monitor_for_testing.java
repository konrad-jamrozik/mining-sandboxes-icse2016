// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org

package org.droidmate.monitor_generator.generated;

import android.annotation.SuppressLint;
import android.os.AsyncTask;
import android.util.Log;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.text.SimpleDateFormat;
import java.util.*;

import de.uds.infsec.instrumentation.Instrumentation;
import de.uds.infsec.instrumentation.annotation.Redirect;
import de.uds.infsec.instrumentation.util.Signature;

@SuppressWarnings("Convert2Diamond")
@SuppressLint("NewApi")
public class Monitor
{

  // !!! DUPLICATION WARNING !!! with org.droidmate.logcat.MonitorConstants
  public static final  String TAG_MONITOR_INIT = "Monitor_init";
  public static final  String TAG_MONITOR_SERV = "Monitor_server";

  // !!! DUPLICATION WARNING !!! with org.droidmate.monitor_generator.RedirectionsGenerator
  public static final String TAG_MONITOR_API  = "Monitored_API_method_call";

  // !!! DUPLICATION WARNING !!! with org.droidmate.common_android.Constants.MONITOR_SERVER_PORT
  public static final int    MONITOR_SERVER_PORT      = 59776;
  public static final String MONITOR_SERVER_START_TAG = "monitor_server_start_tag";
  public static final String MONITOR_SERVER_START_MSG = "Monitor server started successfully";

  // !!! DUPLICATION WARNING !!! with org.droidmate.logcat.MonitorConstants
  private static final String MONITOR_SRV_COMMAND_GET_LOGS = "getLogs";
  private static final String MONITOR_SRV_COMMAND_GET_TIME = "getTime";
  private static final String MONITOR_SRV_COMMAND_CLOSE    = "close";
  // End of DUPLICATION WARNING

  // !!! DUPLICATION WARNING !!! with many places in "core" project. Just hard-coded there.
  private static final String STACK_TRACE_FRAME_DELIMITER = "->";

  //region Class init code
  public Monitor()
  {
    startTCPServer();

    // !!! DUPLICATION WARNING !!! with org.droidmate.logcat.MonitorConstants
    Log.i(TAG_MONITOR_INIT, "Monitor constructed.");
  }

  public void init(android.content.Context context)
  {
    Instrumentation.processClass(Monitor.class);

    redirectConstructors();

    // !!! DUPLICATION WARNING !!! with org.droidmate.logcat.MonitorConstants
    Log.i(TAG_MONITOR_INIT, "Monitor initialized for package " + context.getPackageName());
  }
  //endregion

  //region TCP server code

  private static void startTCPServer()
  {
    MonitorTCPServer tcpServer = new MonitorTCPServer(MONITOR_SERVER_START_TAG, MONITOR_SERVER_START_MSG);

    Log.i(TAG_MONITOR_SERV, "Starting TCP server...");

    Thread serverThread = null;
    try
    {
      serverThread = tcpServer.start(MONITOR_SERVER_PORT);
    } catch (InterruptedException e)
    {
      Log.e(TAG_MONITOR_SERV, "Starting TCP server failed.", e);
    }
    if (serverThread == null) throw new AssertionError();
    if (tcpServer.isClosed()) throw new AssertionError();
    Log.i(TAG_MONITOR_SERV, "Starting TCP server succeeded.");
  }

  static class MonitorTCPServer extends SerializableTCPServerBase<String, ArrayList<ArrayList<String>>>
  {
    private final static String monitorTcpServerClassName = MonitorTCPServer.class.getSimpleName();

    protected MonitorTCPServer(String serverStartMessageTag, String serverStartMessage)
    {
      super(serverStartMessageTag, serverStartMessage);
    }

    @Override
    protected ArrayList<ArrayList<String>> OnServerRequest(String input, Exception inputEx)
    {
      if (Objects.equals(input, MONITOR_SRV_COMMAND_GET_LOGS))
      {
        removeSocketInitLogFromMonitorTCPServer(currentLogs);
        ArrayList<ArrayList<String>> logsToSend = new ArrayList<ArrayList<String>>(currentLogs);
        currentLogs.clear();
        return logsToSend;

      } else if (Objects.equals(input, MONITOR_SRV_COMMAND_GET_TIME))
      {
        final String time = monitorTimeFormatter.format(new Date());
        final ArrayList<String> payload = new ArrayList<String>(Arrays.asList(time, null, null));

        Log.d(monitorTcpServerClassName, "Sending time: "+time);

        return new ArrayList<ArrayList<String>>(Collections.singletonList(payload));

      } else if (Objects.equals(input, MONITOR_SRV_COMMAND_CLOSE))
      {
        // Do nothing here. The command will be handled in org.droidmate.lib_android.MonitorJavaTemplate.MonitorTCPServer.shouldCloseServerSocket
        return new ArrayList<ArrayList<String>>();

      } else
      {
        Log.wtf(monitorTcpServerClassName, "Unexpected command from DroidMate TCP client. The command: " + input);
        return new ArrayList<ArrayList<String>>();
      }
    }

    private void removeSocketInitLogFromMonitorTCPServer(ArrayList<ArrayList<String>> currentLogs)
    {
      ArrayList<ArrayList<String>> logsToRemove = new ArrayList<ArrayList<String>>();
      for (ArrayList<String> log : currentLogs)
      {
        String msgPayload = log.get(2);
        // !!! DUPLICATION WARNING !!! with org.droidmate.common.logcat.ApiLogcatMessage.toLogcatMessagePayload(org.droidmate.apis.IApi, boolean)
        int stacktraceIndex = msgPayload.lastIndexOf("stacktrace: ");
        if (stacktraceIndex == -1)
          throw new AssertionError("The message payload was expected to have 'stacktrace: ' substring in it");
        String stackTrace = msgPayload.substring(stacktraceIndex);
        String[] frames = stackTrace.split(STACK_TRACE_FRAME_DELIMITER);
        if (frames.length >= 2)
        {
          String secondLastFrame = frames[frames.length-2];
          if (secondLastFrame.startsWith("org.droidmate"))
          {
            if (!secondLastFrame.startsWith("org.droidmate.monitor_generator.generated.Monitor")) throw new AssertionError();
            if (!anyContains(frames,"Socket.<init>")) throw new AssertionError();
            logsToRemove.add(log);
          }
        }
      }
      if (logsToRemove.size() != 1) throw new AssertionError();

      currentLogs.remove(logsToRemove.get(0));
    }

    private boolean anyContains(String[] strings, String s)
    {
      for (String string : strings)
      {
        if (string.contains(s))
          return true;
      }
      return false;
    }

    @Override
    protected boolean shouldCloseServerSocket(String serverInput)
    {
      return Objects.equals(serverInput, "close");
    }
  }

  static abstract class SerializableTCPServerBase<ServerInputT extends Serializable, ServerOutputT extends Serializable>
  {

    private int port;
    ServerSocket serverSocket;

    private String serverStartMessageTag;
    private String serverStartMessage;

    private final static String thisClassName = SerializableTCPServerBase.class.getSimpleName();

    protected SerializableTCPServerBase(String serverStartMessageTag, String serverStartMessage)
    {
      this.serverStartMessageTag = serverStartMessageTag;
      this.serverStartMessage = serverStartMessage;

    }

    protected abstract ServerOutputT OnServerRequest(ServerInputT input, Exception inputReadEx);

    protected abstract boolean shouldCloseServerSocket(ServerInputT serverInput);

    // Used in org.droidmate.uiautomatordaemon.UiAutomatorDaemon.init()
    public Thread start(int port) throws InterruptedException
    {

      try
      {
        this.port = port;
        MonitorServerRunnable monitorServerRunnable = new MonitorServerRunnable();
        Thread serverThread = new Thread(monitorServerRunnable);

        //noinspection SynchronizationOnLocalVariableOrMethodParameter
        synchronized (monitorServerRunnable)
        {
          assert (serverSocket == null);
          serverThread.start();
          monitorServerRunnable.wait();
          assert (serverSocket != null);
        }
        Log.i(serverStartMessageTag, serverStartMessage);

        return serverThread;

      } catch (InterruptedException e)
      {
        throw e;
      }
    }

    public void close()
    {
      try
      {
        serverSocket.close();
      } catch (IOException e)
      {
        Log.wtf(thisClassName, "Failed to close SerializableTCPServerBase.");
      }
    }

    // Used in org.droidmate.uiautomatordaemon.UiAutomatorDaemon.init()
    public boolean isClosed()
    {
      return serverSocket.isClosed();
    }

    private class MonitorServerRunnable implements Runnable
    {

      public final String monitorServerRunnableClassName = MonitorServerRunnable.class.getSimpleName() + port;

      public void run()
      {

        Log.d(monitorServerRunnableClassName, "Started MonitorServerRunnable.");
        try
        {

          // Synchronize to ensure the parent thread (the one which started this one) will continue only after the
          // serverSocket is initialized.
          synchronized (this)
          {
            Log.d(monitorServerRunnableClassName, String.format("Creating server socket bound to port %s...", port));
            serverSocket = new ServerSocket(port);
            this.notify();
          }

          while (!serverSocket.isClosed())
          {
            Log.d(monitorServerRunnableClassName, String.format("Accepting socket from client on port %s...", port));
            Socket clientSocket = serverSocket.accept();
            Log.v(monitorServerRunnableClassName, "Socket accepted.");

            ObjectOutputStream output = new ObjectOutputStream(clientSocket.getOutputStream());

          /*
           * Flushing done to prevent client blocking on creation of input stream reading output from this stream. See:
           * org.droidmate.device.SerializableTCPClient.queryServer
           *
           * References:
           * 1. http://stackoverflow.com/questions/8088557/getinputstream-blocks
           * 2. Search for: "Note - The ObjectInputStream constructor blocks until" in:
           * http://docs.oracle.com/javase/7/docs/platform/serialization/spec/input.html
           */
            output.flush();

            ObjectInputStream input = new ObjectInputStream(clientSocket.getInputStream());

            ServerInputT serverInput = null;

            Exception serverInputReadEx = null;

            try
            {
              @SuppressWarnings("unchecked") // Without this var here, there is no place to put the "unchecked" suppression warning.
                ServerInputT localVarForSuppressionAnnotation = (ServerInputT) input.readObject();
              serverInput = localVarForSuppressionAnnotation;

            } catch (ClassNotFoundException e)
            {
              serverInputReadEx = handleInputReadObjectException(input, e);
            } catch (IOException e)
            {
              serverInputReadEx = handleInputReadObjectException(input, e);
            }

            ServerOutputT serverOutput;
            serverOutput = OnServerRequest(serverInput, serverInputReadEx);
            output.writeObject(serverOutput);
            clientSocket.close();

            if (shouldCloseServerSocket(serverInput))
              close();
          }

          Log.d(monitorServerRunnableClassName, "Closed MonitorServerRunnable.");

        } catch (SocketTimeoutException e)
        {
          Log.e(monitorServerRunnableClassName, "Closing MonitorServerRunnable due to a timeout.", e);
          close();
        } catch (IOException e)
        {
          Log.e(monitorServerRunnableClassName, "Exception was thrown while operating MonitorServerRunnable", e);
        }
      }

      private Exception handleInputReadObjectException(ObjectInputStream input, Exception e) throws IOException
      {
        Exception serverInputReadEx;
        Log.e(monitorServerRunnableClassName, "Exception was thrown while reading input sent to MonitorServerRunnable from " +
          "client through socket.", e);
        serverInputReadEx = e;
        input.close();
        return serverInputReadEx;
      }
    }
  }
  //endregion

  //region Helper code
  private static ArrayList<Integer> ctorHandles = new ArrayList<Integer>();

  private static String getStackTrace()
  {
    StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
    StringBuilder sb = new StringBuilder();
    for (int i = 0; i < stackTrace.length; i++)
    {
      sb.append(stackTrace[i].toString());
      if (i < stackTrace.length - 1)
        sb.append("->");
    }
    return sb.toString();
  }

  private static long getThreadId()
  {
    return Thread.currentThread().getId();
  }

  private static String convert(Object param)
  {
    if (param == null)
      return "null";

    String paramStr;
    if (param.getClass().isArray())
    {
      StringBuilder sb = new StringBuilder("[");
      boolean first = true;

      for (Object item : (Object[]) param)
      {
        if (first)
          first = false;
        else
          sb.append(", ");

        sb.append(String.format("%s", item));
      }
      sb.append("]");

      paramStr = sb.toString();
    } else if (param instanceof android.content.Intent)
    {
      paramStr = ((android.content.Intent) param).toUri(1);
      assert paramStr.endsWith("end");

      /*
        Logcat buffer size is 4096 [1]. I have encountered a case in which intent's string extra has eaten up entire log line,
        preventing the remaining parts of the log (in particular, stack trace) to be transferred to DroidMate,
        causing regex match fail. This is how the offending intent value looked like:

          intent:#Intent;action=com.picsart.studio.notification.action;S.extra.result.string=%7B%22response%22%3A%5B%7B%...
          ...<and_so_on_until_entire_line_buffer_was_eaten>

        [1] http://stackoverflow.com/questions/6321555/what-is-the-size-limit-for-logcat
      */
      if (paramStr.length() > 1024)
      {
        paramStr = paramStr.substring(0, 1024 - 24) + "_TRUNCATED_TO_1000_CHARS" + "end";
      }

    } else
    {
      paramStr = String.format("%s", param);
      if (paramStr.length() > 1024)
      {
        paramStr = paramStr.substring(0, 1024 - 24) + "_TRUNCATED_TO_1000_CHARS";
      }
    }

    // !!! DUPLICATION WARNING !!! with: org.droidmate.logcat.Api.spaceEscapeInParamValue
    // solution would be to provide this method with an generated code injection point.
    // end of duplication warning
    return paramStr.replace(" ", "_");
  }

  // !!! DUPLICATION WARNING !!! with org.droidmate.logcat.MonitorConstants.monitorTimeFormatter
  private static SimpleDateFormat monitorTimeFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US);

  private static void addCurrentLogs(String payload)
  {
    String now = monitorTimeFormatter.format(new Date());
    currentLogs.add(new ArrayList<String>(Arrays.asList(getPid(), now, payload)));
  }

  private static String getPid()
  {
    return String.valueOf(android.os.Process.myPid());
  }

  static ArrayList<ArrayList<String>> currentLogs = new ArrayList<ArrayList<String>>();

  //endregion

  //region Generated code

  private static void redirectConstructors()
  {
    ClassLoader[] classLoaders = {Thread.currentThread().getContextClassLoader(), Monitor.class.getClassLoader()};

      ctorHandles.add(Instrumentation.redirectMethod(
          Signature.fromIdentifier("Landroid/bluetooth/BluetoothServerSocket;-><init>(IZZI)V", classLoaders),
          Signature.fromIdentifier("Lorg/droidmate/monitor_generator/generated/Monitor;->redir_0_android_bluetooth_BluetoothServerSocket_ctor4(Ljava/lang/Object;IZZI)V", classLoaders)));

      ctorHandles.add(Instrumentation.redirectMethod(
          Signature.fromIdentifier("Landroid/bluetooth/BluetoothSocket;-><init>(IIZZLjava/lang/String;I)V", classLoaders),
          Signature.fromIdentifier("Lorg/droidmate/monitor_generator/generated/Monitor;->redir_1_android_bluetooth_BluetoothSocket_ctor6(Ljava/lang/Object;IIZZLjava/lang/String;I)V", classLoaders)));

      ctorHandles.add(Instrumentation.redirectMethod(
          Signature.fromIdentifier("Landroid/bluetooth/BluetoothSocket;-><init>(IIZZLandroid/bluetooth/BluetoothDevice;ILandroid/os/ParcelUuid;)V", classLoaders),
          Signature.fromIdentifier("Lorg/droidmate/monitor_generator/generated/Monitor;->redir_2_android_bluetooth_BluetoothSocket_ctor7(Ljava/lang/Object;IIZZLandroid/bluetooth/BluetoothDevice;ILandroid/os/ParcelUuid;)V", classLoaders)));

      ctorHandles.add(Instrumentation.redirectMethod(
          Signature.fromIdentifier("Landroid/media/AudioRecord;-><init>(IIIII)V", classLoaders),
          Signature.fromIdentifier("Lorg/droidmate/monitor_generator/generated/Monitor;->redir_3_android_media_AudioRecord_ctor5(Ljava/lang/Object;IIIII)V", classLoaders)));

      ctorHandles.add(Instrumentation.redirectMethod(
          Signature.fromIdentifier("Landroid/webkit/WebView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;ILjava/util/Map;Z)V", classLoaders),
          Signature.fromIdentifier("Lorg/droidmate/monitor_generator/generated/Monitor;->redir_4_android_webkit_WebView_ctor5(Ljava/lang/Object;Landroid/content/Context;Landroid/util/AttributeSet;ILjava/util/Map;Z)V", classLoaders)));

      ctorHandles.add(Instrumentation.redirectMethod(
          Signature.fromIdentifier("Ljava/net/DatagramSocket;-><init>(I)V", classLoaders),
          Signature.fromIdentifier("Lorg/droidmate/monitor_generator/generated/Monitor;->redir_5_java_net_DatagramSocket_ctor1(Ljava/lang/Object;I)V", classLoaders)));

      ctorHandles.add(Instrumentation.redirectMethod(
          Signature.fromIdentifier("Ljava/net/MulticastSocket;-><init>(I)V", classLoaders),
          Signature.fromIdentifier("Lorg/droidmate/monitor_generator/generated/Monitor;->redir_6_java_net_MulticastSocket_ctor1(Ljava/lang/Object;I)V", classLoaders)));

      ctorHandles.add(Instrumentation.redirectMethod(
          Signature.fromIdentifier("Ljava/net/ServerSocket;-><init>(I)V", classLoaders),
          Signature.fromIdentifier("Lorg/droidmate/monitor_generator/generated/Monitor;->redir_7_java_net_ServerSocket_ctor1(Ljava/lang/Object;I)V", classLoaders)));

      ctorHandles.add(Instrumentation.redirectMethod(
          Signature.fromIdentifier("Ljava/net/Socket;-><init>()V", classLoaders),
          Signature.fromIdentifier("Lorg/droidmate/monitor_generator/generated/Monitor;->redir_8_java_net_Socket_ctor0(Ljava/lang/Object;)V", classLoaders)));

      ctorHandles.add(Instrumentation.redirectMethod(
          Signature.fromIdentifier("Ljava/net/Socket;-><init>(Ljava/net/Proxy;)V", classLoaders),
          Signature.fromIdentifier("Lorg/droidmate/monitor_generator/generated/Monitor;->redir_9_java_net_Socket_ctor1(Ljava/lang/Object;Ljava/net/Proxy;)V", classLoaders)));

      ctorHandles.add(Instrumentation.redirectMethod(
          Signature.fromIdentifier("Ljava/net/Socket;-><init>(Ljava/net/SocketImpl;)V", classLoaders),
          Signature.fromIdentifier("Lorg/droidmate/monitor_generator/generated/Monitor;->redir_10_java_net_Socket_ctor1(Ljava/lang/Object;Ljava/net/SocketImpl;)V", classLoaders)));

      ctorHandles.add(Instrumentation.redirectMethod(
          Signature.fromIdentifier("Ljava/net/Socket;-><init>(Ljava/lang/String;IZ)V", classLoaders),
          Signature.fromIdentifier("Lorg/droidmate/monitor_generator/generated/Monitor;->redir_11_java_net_Socket_ctor3(Ljava/lang/Object;Ljava/lang/String;IZ)V", classLoaders)));

      ctorHandles.add(Instrumentation.redirectMethod(
          Signature.fromIdentifier("Ljava/net/Socket;-><init>(Ljava/net/InetAddress;IZ)V", classLoaders),
          Signature.fromIdentifier("Lorg/droidmate/monitor_generator/generated/Monitor;->redir_12_java_net_Socket_ctor3(Ljava/lang/Object;Ljava/net/InetAddress;IZ)V", classLoaders)));

      ctorHandles.add(Instrumentation.redirectMethod(
          Signature.fromIdentifier("Ljava/net/Socket;-><init>(Ljava/lang/String;ILjava/net/InetAddress;I)V", classLoaders),
          Signature.fromIdentifier("Lorg/droidmate/monitor_generator/generated/Monitor;->redir_13_java_net_Socket_ctor4(Ljava/lang/Object;Ljava/lang/String;ILjava/net/InetAddress;I)V", classLoaders)));

      ctorHandles.add(Instrumentation.redirectMethod(
          Signature.fromIdentifier("Ljava/net/Socket;-><init>(Ljava/net/InetAddress;ILjava/net/InetAddress;I)V", classLoaders),
          Signature.fromIdentifier("Lorg/droidmate/monitor_generator/generated/Monitor;->redir_14_java_net_Socket_ctor4(Ljava/lang/Object;Ljava/net/InetAddress;ILjava/net/InetAddress;I)V", classLoaders)));

      ctorHandles.add(Instrumentation.redirectMethod(
          Signature.fromIdentifier("Ljava/net/URLConnection;-><init>(Ljava/net/URL;)V", classLoaders),
          Signature.fromIdentifier("Lorg/droidmate/monitor_generator/generated/Monitor;->redir_15_java_net_URLConnection_ctor1(Ljava/lang/Object;Ljava/net/URL;)V", classLoaders)));


  }

    public static void redir_0_android_bluetooth_BluetoothServerSocket_ctor4(Object _this, int p0, boolean p1, boolean p2, int p3)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothServerSocket mthd: <init> retCls: void params: int "+convert(p0)+" boolean "+convert(p1)+" boolean "+convert(p2)+" int "+convert(p3)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothServerSocket mthd: <init> retCls: void params: int "+convert(p0)+" boolean "+convert(p1)+" boolean "+convert(p2)+" int "+convert(p3)+" stacktrace: "+stackTrace+"");
        Instrumentation.callVoidMethod(ctorHandles.get(0), _this, p0, p1, p2, p3);
    }

    public static void redir_1_android_bluetooth_BluetoothSocket_ctor6(Object _this, int p0, int p1, boolean p2, boolean p3, java.lang.String p4, int p5)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothSocket mthd: <init> retCls: void params: int "+convert(p0)+" int "+convert(p1)+" boolean "+convert(p2)+" boolean "+convert(p3)+" java.lang.String "+convert(p4)+" int "+convert(p5)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothSocket mthd: <init> retCls: void params: int "+convert(p0)+" int "+convert(p1)+" boolean "+convert(p2)+" boolean "+convert(p3)+" java.lang.String "+convert(p4)+" int "+convert(p5)+" stacktrace: "+stackTrace+"");
        Instrumentation.callVoidMethod(ctorHandles.get(1), _this, p0, p1, p2, p3, p4, p5);
    }

    public static void redir_2_android_bluetooth_BluetoothSocket_ctor7(Object _this, int p0, int p1, boolean p2, boolean p3, android.bluetooth.BluetoothDevice p4, int p5, android.os.ParcelUuid p6)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothSocket mthd: <init> retCls: void params: int "+convert(p0)+" int "+convert(p1)+" boolean "+convert(p2)+" boolean "+convert(p3)+" android.bluetooth.BluetoothDevice "+convert(p4)+" int "+convert(p5)+" android.os.ParcelUuid "+convert(p6)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothSocket mthd: <init> retCls: void params: int "+convert(p0)+" int "+convert(p1)+" boolean "+convert(p2)+" boolean "+convert(p3)+" android.bluetooth.BluetoothDevice "+convert(p4)+" int "+convert(p5)+" android.os.ParcelUuid "+convert(p6)+" stacktrace: "+stackTrace+"");
        Instrumentation.callVoidMethod(ctorHandles.get(2), _this, p0, p1, p2, p3, p4, p5, p6);
    }

    public static void redir_3_android_media_AudioRecord_ctor5(Object _this, int p0, int p1, int p2, int p3, int p4)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.media.AudioRecord mthd: <init> retCls: void params: int "+convert(p0)+" int "+convert(p1)+" int "+convert(p2)+" int "+convert(p3)+" int "+convert(p4)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.media.AudioRecord mthd: <init> retCls: void params: int "+convert(p0)+" int "+convert(p1)+" int "+convert(p2)+" int "+convert(p3)+" int "+convert(p4)+" stacktrace: "+stackTrace+"");
        Instrumentation.callVoidMethod(ctorHandles.get(3), _this, p0, p1, p2, p3, p4);
    }

    public static void redir_4_android_webkit_WebView_ctor5(Object _this, android.content.Context p0, android.util.AttributeSet p1, int p2, java.util.Map p3, boolean p4)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.webkit.WebView mthd: <init> retCls: void params: android.content.Context "+convert(p0)+" android.util.AttributeSet "+convert(p1)+" int "+convert(p2)+" java.util.Map "+convert(p3)+" boolean "+convert(p4)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.webkit.WebView mthd: <init> retCls: void params: android.content.Context "+convert(p0)+" android.util.AttributeSet "+convert(p1)+" int "+convert(p2)+" java.util.Map "+convert(p3)+" boolean "+convert(p4)+" stacktrace: "+stackTrace+"");
        Instrumentation.callVoidMethod(ctorHandles.get(4), _this, p0, p1, p2, p3, p4);
    }

    public static void redir_5_java_net_DatagramSocket_ctor1(Object _this, int p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: java.net.DatagramSocket mthd: <init> retCls: void params: int "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: java.net.DatagramSocket mthd: <init> retCls: void params: int "+convert(p0)+" stacktrace: "+stackTrace+"");
        Instrumentation.callVoidMethod(ctorHandles.get(5), _this, p0);
    }

    public static void redir_6_java_net_MulticastSocket_ctor1(Object _this, int p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: java.net.MulticastSocket mthd: <init> retCls: void params: int "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: java.net.MulticastSocket mthd: <init> retCls: void params: int "+convert(p0)+" stacktrace: "+stackTrace+"");
        Instrumentation.callVoidMethod(ctorHandles.get(6), _this, p0);
    }

    public static void redir_7_java_net_ServerSocket_ctor1(Object _this, int p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: java.net.ServerSocket mthd: <init> retCls: void params: int "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: java.net.ServerSocket mthd: <init> retCls: void params: int "+convert(p0)+" stacktrace: "+stackTrace+"");
        Instrumentation.callVoidMethod(ctorHandles.get(7), _this, p0);
    }

    public static void redir_8_java_net_Socket_ctor0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: java.net.Socket mthd: <init> retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: java.net.Socket mthd: <init> retCls: void params:  stacktrace: "+stackTrace+"");
        Instrumentation.callVoidMethod(ctorHandles.get(8), _this);
    }

    public static void redir_9_java_net_Socket_ctor1(Object _this, java.net.Proxy p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: java.net.Socket mthd: <init> retCls: void params: java.net.Proxy "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: java.net.Socket mthd: <init> retCls: void params: java.net.Proxy "+convert(p0)+" stacktrace: "+stackTrace+"");
        Instrumentation.callVoidMethod(ctorHandles.get(9), _this, p0);
    }

    public static void redir_10_java_net_Socket_ctor1(Object _this, java.net.SocketImpl p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: java.net.Socket mthd: <init> retCls: void params: java.net.SocketImpl "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: java.net.Socket mthd: <init> retCls: void params: java.net.SocketImpl "+convert(p0)+" stacktrace: "+stackTrace+"");
        Instrumentation.callVoidMethod(ctorHandles.get(10), _this, p0);
    }

    public static void redir_11_java_net_Socket_ctor3(Object _this, java.lang.String p0, int p1, boolean p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: java.net.Socket mthd: <init> retCls: void params: java.lang.String "+convert(p0)+" int "+convert(p1)+" boolean "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: java.net.Socket mthd: <init> retCls: void params: java.lang.String "+convert(p0)+" int "+convert(p1)+" boolean "+convert(p2)+" stacktrace: "+stackTrace+"");
        Instrumentation.callVoidMethod(ctorHandles.get(11), _this, p0, p1, p2);
    }

    public static void redir_12_java_net_Socket_ctor3(Object _this, java.net.InetAddress p0, int p1, boolean p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: java.net.Socket mthd: <init> retCls: void params: java.net.InetAddress "+convert(p0)+" int "+convert(p1)+" boolean "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: java.net.Socket mthd: <init> retCls: void params: java.net.InetAddress "+convert(p0)+" int "+convert(p1)+" boolean "+convert(p2)+" stacktrace: "+stackTrace+"");
        Instrumentation.callVoidMethod(ctorHandles.get(12), _this, p0, p1, p2);
    }

    public static void redir_13_java_net_Socket_ctor4(Object _this, java.lang.String p0, int p1, java.net.InetAddress p2, int p3)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: java.net.Socket mthd: <init> retCls: void params: java.lang.String "+convert(p0)+" int "+convert(p1)+" java.net.InetAddress "+convert(p2)+" int "+convert(p3)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: java.net.Socket mthd: <init> retCls: void params: java.lang.String "+convert(p0)+" int "+convert(p1)+" java.net.InetAddress "+convert(p2)+" int "+convert(p3)+" stacktrace: "+stackTrace+"");
        Instrumentation.callVoidMethod(ctorHandles.get(13), _this, p0, p1, p2, p3);
    }

    public static void redir_14_java_net_Socket_ctor4(Object _this, java.net.InetAddress p0, int p1, java.net.InetAddress p2, int p3)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: java.net.Socket mthd: <init> retCls: void params: java.net.InetAddress "+convert(p0)+" int "+convert(p1)+" java.net.InetAddress "+convert(p2)+" int "+convert(p3)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: java.net.Socket mthd: <init> retCls: void params: java.net.InetAddress "+convert(p0)+" int "+convert(p1)+" java.net.InetAddress "+convert(p2)+" int "+convert(p3)+" stacktrace: "+stackTrace+"");
        Instrumentation.callVoidMethod(ctorHandles.get(14), _this, p0, p1, p2, p3);
    }

    public static void redir_15_java_net_URLConnection_ctor1(Object _this, java.net.URL p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: java.net.URLConnection mthd: <init> retCls: void params: java.net.URL "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: java.net.URLConnection mthd: <init> retCls: void params: java.net.URL "+convert(p0)+" stacktrace: "+stackTrace+"");
        Instrumentation.callVoidMethod(ctorHandles.get(15), _this, p0);
    }



    @Redirect("android.accounts.AccountManager->addAccount")
    public static android.accounts.AccountManagerFuture redir_android_accounts_AccountManager_addAccount7(Object _this, java.lang.String p0, java.lang.String p1, java.lang.String[] p2, android.os.Bundle p3, android.app.Activity p4, android.accounts.AccountManagerCallback p5, android.os.Handler p6)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.accounts.AccountManager mthd: addAccount retCls: android.accounts.AccountManagerFuture params: java.lang.String "+convert(p0)+" java.lang.String "+convert(p1)+" java.lang.String[] "+convert(p2)+" android.os.Bundle "+convert(p3)+" android.app.Activity "+convert(p4)+" android.accounts.AccountManagerCallback "+convert(p5)+" android.os.Handler "+convert(p6)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.accounts.AccountManager mthd: addAccount retCls: android.accounts.AccountManagerFuture params: java.lang.String "+convert(p0)+" java.lang.String "+convert(p1)+" java.lang.String[] "+convert(p2)+" android.os.Bundle "+convert(p3)+" android.app.Activity "+convert(p4)+" android.accounts.AccountManagerCallback "+convert(p5)+" android.os.Handler "+convert(p6)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.accounts.AccountManagerFuture) Instrumentation.callObjectMethod($.class, _this, p0, p1, p2, p3, p4, p5, p6);
    }

    @Redirect("android.accounts.AccountManager->addAccountExplicitly")
    public static boolean redir_android_accounts_AccountManager_addAccountExplicitly3(Object _this, android.accounts.Account p0, java.lang.String p1, android.os.Bundle p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.accounts.AccountManager mthd: addAccountExplicitly retCls: boolean params: android.accounts.Account "+convert(p0)+" java.lang.String "+convert(p1)+" android.os.Bundle "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.accounts.AccountManager mthd: addAccountExplicitly retCls: boolean params: android.accounts.Account "+convert(p0)+" java.lang.String "+convert(p1)+" android.os.Bundle "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this, p0, p1, p2);
    }

    @Redirect("android.accounts.AccountManager->addOnAccountsUpdatedListener")
    public static void redir_android_accounts_AccountManager_addOnAccountsUpdatedListener3(Object _this, android.accounts.OnAccountsUpdateListener p0, android.os.Handler p1, boolean p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.accounts.AccountManager mthd: addOnAccountsUpdatedListener retCls: void params: android.accounts.OnAccountsUpdateListener "+convert(p0)+" android.os.Handler "+convert(p1)+" boolean "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.accounts.AccountManager mthd: addOnAccountsUpdatedListener retCls: void params: android.accounts.OnAccountsUpdateListener "+convert(p0)+" android.os.Handler "+convert(p1)+" boolean "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1, p2);
    }

    @Redirect("android.accounts.AccountManager->blockingGetAuthToken")
    public static java.lang.String redir_android_accounts_AccountManager_blockingGetAuthToken3(Object _this, android.accounts.Account p0, java.lang.String p1, boolean p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.accounts.AccountManager mthd: blockingGetAuthToken retCls: java.lang.String params: android.accounts.Account "+convert(p0)+" java.lang.String "+convert(p1)+" boolean "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.accounts.AccountManager mthd: blockingGetAuthToken retCls: java.lang.String params: android.accounts.Account "+convert(p0)+" java.lang.String "+convert(p1)+" boolean "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (java.lang.String) Instrumentation.callObjectMethod($.class, _this, p0, p1, p2);
    }

    @Redirect("android.accounts.AccountManager->clearPassword")
    public static void redir_android_accounts_AccountManager_clearPassword1(Object _this, android.accounts.Account p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.accounts.AccountManager mthd: clearPassword retCls: void params: android.accounts.Account "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.accounts.AccountManager mthd: clearPassword retCls: void params: android.accounts.Account "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0);
    }

    @Redirect("android.accounts.AccountManager->confirmCredentials")
    public static android.accounts.AccountManagerFuture redir_android_accounts_AccountManager_confirmCredentials5(Object _this, android.accounts.Account p0, android.os.Bundle p1, android.app.Activity p2, android.accounts.AccountManagerCallback p3, android.os.Handler p4)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.accounts.AccountManager mthd: confirmCredentials retCls: android.accounts.AccountManagerFuture params: android.accounts.Account "+convert(p0)+" android.os.Bundle "+convert(p1)+" android.app.Activity "+convert(p2)+" android.accounts.AccountManagerCallback "+convert(p3)+" android.os.Handler "+convert(p4)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.accounts.AccountManager mthd: confirmCredentials retCls: android.accounts.AccountManagerFuture params: android.accounts.Account "+convert(p0)+" android.os.Bundle "+convert(p1)+" android.app.Activity "+convert(p2)+" android.accounts.AccountManagerCallback "+convert(p3)+" android.os.Handler "+convert(p4)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.accounts.AccountManagerFuture) Instrumentation.callObjectMethod($.class, _this, p0, p1, p2, p3, p4);
    }

    @Redirect("android.accounts.AccountManager->editProperties")
    public static android.accounts.AccountManagerFuture redir_android_accounts_AccountManager_editProperties4(Object _this, java.lang.String p0, android.app.Activity p1, android.accounts.AccountManagerCallback p2, android.os.Handler p3)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.accounts.AccountManager mthd: editProperties retCls: android.accounts.AccountManagerFuture params: java.lang.String "+convert(p0)+" android.app.Activity "+convert(p1)+" android.accounts.AccountManagerCallback "+convert(p2)+" android.os.Handler "+convert(p3)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.accounts.AccountManager mthd: editProperties retCls: android.accounts.AccountManagerFuture params: java.lang.String "+convert(p0)+" android.app.Activity "+convert(p1)+" android.accounts.AccountManagerCallback "+convert(p2)+" android.os.Handler "+convert(p3)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.accounts.AccountManagerFuture) Instrumentation.callObjectMethod($.class, _this, p0, p1, p2, p3);
    }

    @Redirect("android.accounts.AccountManager->getAccounts")
    public static android.accounts.Account[] redir_android_accounts_AccountManager_getAccounts0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.accounts.AccountManager mthd: getAccounts retCls: android.accounts.Account[] params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.accounts.AccountManager mthd: getAccounts retCls: android.accounts.Account[] params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (android.accounts.Account[]) Instrumentation.callObjectMethod($.class, _this);
    }

    @Redirect("android.accounts.AccountManager->getAccountsByType")
    public static android.accounts.Account[] redir_android_accounts_AccountManager_getAccountsByType1(Object _this, java.lang.String p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.accounts.AccountManager mthd: getAccountsByType retCls: android.accounts.Account[] params: java.lang.String "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.accounts.AccountManager mthd: getAccountsByType retCls: android.accounts.Account[] params: java.lang.String "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.accounts.Account[]) Instrumentation.callObjectMethod($.class, _this, p0);
    }

    @Redirect("android.accounts.AccountManager->getAccountsByTypeAndFeatures")
    public static android.accounts.AccountManagerFuture redir_android_accounts_AccountManager_getAccountsByTypeAndFeatures4(Object _this, java.lang.String p0, java.lang.String[] p1, android.accounts.AccountManagerCallback p2, android.os.Handler p3)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.accounts.AccountManager mthd: getAccountsByTypeAndFeatures retCls: android.accounts.AccountManagerFuture params: java.lang.String "+convert(p0)+" java.lang.String[] "+convert(p1)+" android.accounts.AccountManagerCallback "+convert(p2)+" android.os.Handler "+convert(p3)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.accounts.AccountManager mthd: getAccountsByTypeAndFeatures retCls: android.accounts.AccountManagerFuture params: java.lang.String "+convert(p0)+" java.lang.String[] "+convert(p1)+" android.accounts.AccountManagerCallback "+convert(p2)+" android.os.Handler "+convert(p3)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.accounts.AccountManagerFuture) Instrumentation.callObjectMethod($.class, _this, p0, p1, p2, p3);
    }

    @Redirect("android.accounts.AccountManager->getAuthToken")
    public static android.accounts.AccountManagerFuture redir_android_accounts_AccountManager_getAuthToken5(Object _this, android.accounts.Account p0, java.lang.String p1, boolean p2, android.accounts.AccountManagerCallback p3, android.os.Handler p4)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.accounts.AccountManager mthd: getAuthToken retCls: android.accounts.AccountManagerFuture params: android.accounts.Account "+convert(p0)+" java.lang.String "+convert(p1)+" boolean "+convert(p2)+" android.accounts.AccountManagerCallback "+convert(p3)+" android.os.Handler "+convert(p4)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.accounts.AccountManager mthd: getAuthToken retCls: android.accounts.AccountManagerFuture params: android.accounts.Account "+convert(p0)+" java.lang.String "+convert(p1)+" boolean "+convert(p2)+" android.accounts.AccountManagerCallback "+convert(p3)+" android.os.Handler "+convert(p4)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.accounts.AccountManagerFuture) Instrumentation.callObjectMethod($.class, _this, p0, p1, p2, p3, p4);
    }

    @Redirect("android.accounts.AccountManager->getAuthToken")
    public static android.accounts.AccountManagerFuture redir_android_accounts_AccountManager_getAuthToken6(Object _this, android.accounts.Account p0, java.lang.String p1, android.os.Bundle p2, boolean p3, android.accounts.AccountManagerCallback p4, android.os.Handler p5)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.accounts.AccountManager mthd: getAuthToken retCls: android.accounts.AccountManagerFuture params: android.accounts.Account "+convert(p0)+" java.lang.String "+convert(p1)+" android.os.Bundle "+convert(p2)+" boolean "+convert(p3)+" android.accounts.AccountManagerCallback "+convert(p4)+" android.os.Handler "+convert(p5)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.accounts.AccountManager mthd: getAuthToken retCls: android.accounts.AccountManagerFuture params: android.accounts.Account "+convert(p0)+" java.lang.String "+convert(p1)+" android.os.Bundle "+convert(p2)+" boolean "+convert(p3)+" android.accounts.AccountManagerCallback "+convert(p4)+" android.os.Handler "+convert(p5)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.accounts.AccountManagerFuture) Instrumentation.callObjectMethod($.class, _this, p0, p1, p2, p3, p4, p5);
    }

    @Redirect("android.accounts.AccountManager->getAuthToken")
    public static android.accounts.AccountManagerFuture redir_android_accounts_AccountManager_getAuthToken6(Object _this, android.accounts.Account p0, java.lang.String p1, android.os.Bundle p2, android.app.Activity p3, android.accounts.AccountManagerCallback p4, android.os.Handler p5)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.accounts.AccountManager mthd: getAuthToken retCls: android.accounts.AccountManagerFuture params: android.accounts.Account "+convert(p0)+" java.lang.String "+convert(p1)+" android.os.Bundle "+convert(p2)+" android.app.Activity "+convert(p3)+" android.accounts.AccountManagerCallback "+convert(p4)+" android.os.Handler "+convert(p5)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.accounts.AccountManager mthd: getAuthToken retCls: android.accounts.AccountManagerFuture params: android.accounts.Account "+convert(p0)+" java.lang.String "+convert(p1)+" android.os.Bundle "+convert(p2)+" android.app.Activity "+convert(p3)+" android.accounts.AccountManagerCallback "+convert(p4)+" android.os.Handler "+convert(p5)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.accounts.AccountManagerFuture) Instrumentation.callObjectMethod($.class, _this, p0, p1, p2, p3, p4, p5);
    }

    @Redirect("android.accounts.AccountManager->getAuthTokenByFeatures")
    public static android.accounts.AccountManagerFuture redir_android_accounts_AccountManager_getAuthTokenByFeatures8(Object _this, java.lang.String p0, java.lang.String p1, java.lang.String[] p2, android.app.Activity p3, android.os.Bundle p4, android.os.Bundle p5, android.accounts.AccountManagerCallback p6, android.os.Handler p7)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.accounts.AccountManager mthd: getAuthTokenByFeatures retCls: android.accounts.AccountManagerFuture params: java.lang.String "+convert(p0)+" java.lang.String "+convert(p1)+" java.lang.String[] "+convert(p2)+" android.app.Activity "+convert(p3)+" android.os.Bundle "+convert(p4)+" android.os.Bundle "+convert(p5)+" android.accounts.AccountManagerCallback "+convert(p6)+" android.os.Handler "+convert(p7)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.accounts.AccountManager mthd: getAuthTokenByFeatures retCls: android.accounts.AccountManagerFuture params: java.lang.String "+convert(p0)+" java.lang.String "+convert(p1)+" java.lang.String[] "+convert(p2)+" android.app.Activity "+convert(p3)+" android.os.Bundle "+convert(p4)+" android.os.Bundle "+convert(p5)+" android.accounts.AccountManagerCallback "+convert(p6)+" android.os.Handler "+convert(p7)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.accounts.AccountManagerFuture) Instrumentation.callObjectMethod($.class, _this, p0, p1, p2, p3, p4, p5, p6, p7);
    }

    @Redirect("android.accounts.AccountManager->getAuthTokenLabel")
    public static android.accounts.AccountManagerFuture redir_android_accounts_AccountManager_getAuthTokenLabel4(Object _this, java.lang.String p0, java.lang.String p1, android.accounts.AccountManagerCallback p2, android.os.Handler p3)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.accounts.AccountManager mthd: getAuthTokenLabel retCls: android.accounts.AccountManagerFuture params: java.lang.String "+convert(p0)+" java.lang.String "+convert(p1)+" android.accounts.AccountManagerCallback "+convert(p2)+" android.os.Handler "+convert(p3)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.accounts.AccountManager mthd: getAuthTokenLabel retCls: android.accounts.AccountManagerFuture params: java.lang.String "+convert(p0)+" java.lang.String "+convert(p1)+" android.accounts.AccountManagerCallback "+convert(p2)+" android.os.Handler "+convert(p3)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.accounts.AccountManagerFuture) Instrumentation.callObjectMethod($.class, _this, p0, p1, p2, p3);
    }

    @Redirect("android.accounts.AccountManager->getPassword")
    public static java.lang.String redir_android_accounts_AccountManager_getPassword1(Object _this, android.accounts.Account p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.accounts.AccountManager mthd: getPassword retCls: java.lang.String params: android.accounts.Account "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.accounts.AccountManager mthd: getPassword retCls: java.lang.String params: android.accounts.Account "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (java.lang.String) Instrumentation.callObjectMethod($.class, _this, p0);
    }

    @Redirect("android.accounts.AccountManager->getUserData")
    public static java.lang.String redir_android_accounts_AccountManager_getUserData2(Object _this, android.accounts.Account p0, java.lang.String p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.accounts.AccountManager mthd: getUserData retCls: java.lang.String params: android.accounts.Account "+convert(p0)+" java.lang.String "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.accounts.AccountManager mthd: getUserData retCls: java.lang.String params: android.accounts.Account "+convert(p0)+" java.lang.String "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (java.lang.String) Instrumentation.callObjectMethod($.class, _this, p0, p1);
    }

    @Redirect("android.accounts.AccountManager->hasFeatures")
    public static android.accounts.AccountManagerFuture redir_android_accounts_AccountManager_hasFeatures4(Object _this, android.accounts.Account p0, java.lang.String[] p1, android.accounts.AccountManagerCallback p2, android.os.Handler p3)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.accounts.AccountManager mthd: hasFeatures retCls: android.accounts.AccountManagerFuture params: android.accounts.Account "+convert(p0)+" java.lang.String[] "+convert(p1)+" android.accounts.AccountManagerCallback "+convert(p2)+" android.os.Handler "+convert(p3)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.accounts.AccountManager mthd: hasFeatures retCls: android.accounts.AccountManagerFuture params: android.accounts.Account "+convert(p0)+" java.lang.String[] "+convert(p1)+" android.accounts.AccountManagerCallback "+convert(p2)+" android.os.Handler "+convert(p3)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.accounts.AccountManagerFuture) Instrumentation.callObjectMethod($.class, _this, p0, p1, p2, p3);
    }

    @Redirect("android.accounts.AccountManager->invalidateAuthToken")
    public static void redir_android_accounts_AccountManager_invalidateAuthToken2(Object _this, java.lang.String p0, java.lang.String p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.accounts.AccountManager mthd: invalidateAuthToken retCls: void params: java.lang.String "+convert(p0)+" java.lang.String "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.accounts.AccountManager mthd: invalidateAuthToken retCls: void params: java.lang.String "+convert(p0)+" java.lang.String "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1);
    }

    @Redirect("android.accounts.AccountManager->peekAuthToken")
    public static java.lang.String redir_android_accounts_AccountManager_peekAuthToken2(Object _this, android.accounts.Account p0, java.lang.String p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.accounts.AccountManager mthd: peekAuthToken retCls: java.lang.String params: android.accounts.Account "+convert(p0)+" java.lang.String "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.accounts.AccountManager mthd: peekAuthToken retCls: java.lang.String params: android.accounts.Account "+convert(p0)+" java.lang.String "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (java.lang.String) Instrumentation.callObjectMethod($.class, _this, p0, p1);
    }

    @Redirect("android.accounts.AccountManager->removeAccount")
    public static android.accounts.AccountManagerFuture redir_android_accounts_AccountManager_removeAccount3(Object _this, android.accounts.Account p0, android.accounts.AccountManagerCallback p1, android.os.Handler p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.accounts.AccountManager mthd: removeAccount retCls: android.accounts.AccountManagerFuture params: android.accounts.Account "+convert(p0)+" android.accounts.AccountManagerCallback "+convert(p1)+" android.os.Handler "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.accounts.AccountManager mthd: removeAccount retCls: android.accounts.AccountManagerFuture params: android.accounts.Account "+convert(p0)+" android.accounts.AccountManagerCallback "+convert(p1)+" android.os.Handler "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.accounts.AccountManagerFuture) Instrumentation.callObjectMethod($.class, _this, p0, p1, p2);
    }

    @Redirect("android.accounts.AccountManager->setAuthToken")
    public static void redir_android_accounts_AccountManager_setAuthToken3(Object _this, android.accounts.Account p0, java.lang.String p1, java.lang.String p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.accounts.AccountManager mthd: setAuthToken retCls: void params: android.accounts.Account "+convert(p0)+" java.lang.String "+convert(p1)+" java.lang.String "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.accounts.AccountManager mthd: setAuthToken retCls: void params: android.accounts.Account "+convert(p0)+" java.lang.String "+convert(p1)+" java.lang.String "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1, p2);
    }

    @Redirect("android.accounts.AccountManager->setPassword")
    public static void redir_android_accounts_AccountManager_setPassword2(Object _this, android.accounts.Account p0, java.lang.String p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.accounts.AccountManager mthd: setPassword retCls: void params: android.accounts.Account "+convert(p0)+" java.lang.String "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.accounts.AccountManager mthd: setPassword retCls: void params: android.accounts.Account "+convert(p0)+" java.lang.String "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1);
    }

    @Redirect("android.accounts.AccountManager->setUserData")
    public static void redir_android_accounts_AccountManager_setUserData3(Object _this, android.accounts.Account p0, java.lang.String p1, java.lang.String p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.accounts.AccountManager mthd: setUserData retCls: void params: android.accounts.Account "+convert(p0)+" java.lang.String "+convert(p1)+" java.lang.String "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.accounts.AccountManager mthd: setUserData retCls: void params: android.accounts.Account "+convert(p0)+" java.lang.String "+convert(p1)+" java.lang.String "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1, p2);
    }

    @Redirect("android.accounts.AccountManager->updateCredentials")
    public static android.accounts.AccountManagerFuture redir_android_accounts_AccountManager_updateCredentials6(Object _this, android.accounts.Account p0, java.lang.String p1, android.os.Bundle p2, android.app.Activity p3, android.accounts.AccountManagerCallback p4, android.os.Handler p5)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.accounts.AccountManager mthd: updateCredentials retCls: android.accounts.AccountManagerFuture params: android.accounts.Account "+convert(p0)+" java.lang.String "+convert(p1)+" android.os.Bundle "+convert(p2)+" android.app.Activity "+convert(p3)+" android.accounts.AccountManagerCallback "+convert(p4)+" android.os.Handler "+convert(p5)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.accounts.AccountManager mthd: updateCredentials retCls: android.accounts.AccountManagerFuture params: android.accounts.Account "+convert(p0)+" java.lang.String "+convert(p1)+" android.os.Bundle "+convert(p2)+" android.app.Activity "+convert(p3)+" android.accounts.AccountManagerCallback "+convert(p4)+" android.os.Handler "+convert(p5)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.accounts.AccountManagerFuture) Instrumentation.callObjectMethod($.class, _this, p0, p1, p2, p3, p4, p5);
    }

    @Redirect("android.app.Activity->startActivities")
    public static void redir_android_app_Activity_startActivities2(Object _this, android.content.Intent[] p0, android.os.Bundle p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.app.Activity mthd: startActivities retCls: void params: android.content.Intent[] "+convert(p0)+" android.os.Bundle "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.app.Activity mthd: startActivities retCls: void params: android.content.Intent[] "+convert(p0)+" android.os.Bundle "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1);
    }

    @Redirect("android.app.Activity->startActivityForResult")
    public static void redir_android_app_Activity_startActivityForResult3(Object _this, android.content.Intent p0, int p1, android.os.Bundle p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.app.Activity mthd: startActivityForResult retCls: void params: android.content.Intent "+convert(p0)+" int "+convert(p1)+" android.os.Bundle "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.app.Activity mthd: startActivityForResult retCls: void params: android.content.Intent "+convert(p0)+" int "+convert(p1)+" android.os.Bundle "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1, p2);
    }

    @Redirect("android.app.Activity->startActivityFromChild")
    public static void redir_android_app_Activity_startActivityFromChild4(Object _this, android.app.Activity p0, android.content.Intent p1, int p2, android.os.Bundle p3)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.app.Activity mthd: startActivityFromChild retCls: void params: android.app.Activity "+convert(p0)+" android.content.Intent "+convert(p1)+" int "+convert(p2)+" android.os.Bundle "+convert(p3)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.app.Activity mthd: startActivityFromChild retCls: void params: android.app.Activity "+convert(p0)+" android.content.Intent "+convert(p1)+" int "+convert(p2)+" android.os.Bundle "+convert(p3)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1, p2, p3);
    }

    @Redirect("android.app.Activity->startActivityFromFragment")
    public static void redir_android_app_Activity_startActivityFromFragment4(Object _this, android.app.Fragment p0, android.content.Intent p1, int p2, android.os.Bundle p3)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.app.Activity mthd: startActivityFromFragment retCls: void params: android.app.Fragment "+convert(p0)+" android.content.Intent "+convert(p1)+" int "+convert(p2)+" android.os.Bundle "+convert(p3)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.app.Activity mthd: startActivityFromFragment retCls: void params: android.app.Fragment "+convert(p0)+" android.content.Intent "+convert(p1)+" int "+convert(p2)+" android.os.Bundle "+convert(p3)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1, p2, p3);
    }

    @Redirect("android.app.Activity->startActivityIfNeeded")
    public static void redir_android_app_Activity_startActivityIfNeeded3(Object _this, android.content.Intent p0, int p1, android.os.Bundle p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.app.Activity mthd: startActivityIfNeeded retCls: void params: android.content.Intent "+convert(p0)+" int "+convert(p1)+" android.os.Bundle "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.app.Activity mthd: startActivityIfNeeded retCls: void params: android.content.Intent "+convert(p0)+" int "+convert(p1)+" android.os.Bundle "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1, p2);
    }

    @Redirect("android.app.Activity->startIntentSenderForResultInner")
    public static void redir_android_app_Activity_startIntentSenderForResultInner7(Object _this, android.content.IntentSender p0, int p1, android.content.Intent p2, int p3, int p4, android.app.Activity p5, android.os.Bundle p6)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.app.Activity mthd: startIntentSenderForResultInner retCls: void params: android.content.IntentSender "+convert(p0)+" int "+convert(p1)+" android.content.Intent "+convert(p2)+" int "+convert(p3)+" int "+convert(p4)+" android.app.Activity "+convert(p5)+" android.os.Bundle "+convert(p6)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.app.Activity mthd: startIntentSenderForResultInner retCls: void params: android.content.IntentSender "+convert(p0)+" int "+convert(p1)+" android.content.Intent "+convert(p2)+" int "+convert(p3)+" int "+convert(p4)+" android.app.Activity "+convert(p5)+" android.os.Bundle "+convert(p6)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1, p2, p3, p4, p5, p6);
    }

    @Redirect("android.app.ActivityManager->getRecentTasks")
    public static java.util.List redir_android_app_ActivityManager_getRecentTasks2(Object _this, int p0, int p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.app.ActivityManager mthd: getRecentTasks retCls: java.util.List params: int "+convert(p0)+" int "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.app.ActivityManager mthd: getRecentTasks retCls: java.util.List params: int "+convert(p0)+" int "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (java.util.List) Instrumentation.callObjectMethod($.class, _this, p0, p1);
    }

    @Redirect("android.app.ActivityManager->getRunningTasks")
    public static java.util.List redir_android_app_ActivityManager_getRunningTasks1(Object _this, int p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.app.ActivityManager mthd: getRunningTasks retCls: java.util.List params: int "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.app.ActivityManager mthd: getRunningTasks retCls: java.util.List params: int "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (java.util.List) Instrumentation.callObjectMethod($.class, _this, p0);
    }

    @Redirect("android.app.ActivityManager->killBackgroundProcesses")
    public static void redir_android_app_ActivityManager_killBackgroundProcesses1(Object _this, java.lang.String p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.app.ActivityManager mthd: killBackgroundProcesses retCls: void params: java.lang.String "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.app.ActivityManager mthd: killBackgroundProcesses retCls: void params: java.lang.String "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0);
    }

    @Redirect("android.app.ActivityManager->moveTaskToFront")
    public static void redir_android_app_ActivityManager_moveTaskToFront2(Object _this, int p0, int p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.app.ActivityManager mthd: moveTaskToFront retCls: void params: int "+convert(p0)+" int "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.app.ActivityManager mthd: moveTaskToFront retCls: void params: int "+convert(p0)+" int "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1);
    }

    @Redirect("android.app.ActivityManager->moveTaskToFront")
    public static void redir_android_app_ActivityManager_moveTaskToFront3(Object _this, int p0, int p1, android.os.Bundle p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.app.ActivityManager mthd: moveTaskToFront retCls: void params: int "+convert(p0)+" int "+convert(p1)+" android.os.Bundle "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.app.ActivityManager mthd: moveTaskToFront retCls: void params: int "+convert(p0)+" int "+convert(p1)+" android.os.Bundle "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1, p2);
    }

    @Redirect("android.app.ActivityManager->restartPackage")
    public static void redir_android_app_ActivityManager_restartPackage1(Object _this, java.lang.String p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.app.ActivityManager mthd: restartPackage retCls: void params: java.lang.String "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.app.ActivityManager mthd: restartPackage retCls: void params: java.lang.String "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0);
    }

    @Redirect("android.app.AlarmManager->setTimeZone")
    public static void redir_android_app_AlarmManager_setTimeZone1(Object _this, java.lang.String p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.app.AlarmManager mthd: setTimeZone retCls: void params: java.lang.String "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.app.AlarmManager mthd: setTimeZone retCls: void params: java.lang.String "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0);
    }

    @Redirect("android.app.ContextImpl->startActivities")
    public static void redir_android_app_ContextImpl_startActivities2(Object _this, android.content.Intent[] p0, android.os.Bundle p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.app.ContextImpl mthd: startActivities retCls: void params: android.content.Intent[] "+convert(p0)+" android.os.Bundle "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.app.ContextImpl mthd: startActivities retCls: void params: android.content.Intent[] "+convert(p0)+" android.os.Bundle "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1);
    }

    @Redirect("android.app.ContextImpl->startActivitiesAsUser")
    public static void redir_android_app_ContextImpl_startActivitiesAsUser3(Object _this, android.content.Intent[] p0, android.os.Bundle p1, android.os.UserHandle p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.app.ContextImpl mthd: startActivitiesAsUser retCls: void params: android.content.Intent[] "+convert(p0)+" android.os.Bundle "+convert(p1)+" android.os.UserHandle "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.app.ContextImpl mthd: startActivitiesAsUser retCls: void params: android.content.Intent[] "+convert(p0)+" android.os.Bundle "+convert(p1)+" android.os.UserHandle "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1, p2);
    }

    @Redirect("android.app.ContextImpl->startActivity")
    public static void redir_android_app_ContextImpl_startActivity2(Object _this, android.content.Intent p0, android.os.Bundle p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.app.ContextImpl mthd: startActivity retCls: void params: android.content.Intent "+convert(p0)+" android.os.Bundle "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.app.ContextImpl mthd: startActivity retCls: void params: android.content.Intent "+convert(p0)+" android.os.Bundle "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1);
    }

    @Redirect("android.app.ContextImpl->startActivityAsUser")
    public static void redir_android_app_ContextImpl_startActivityAsUser3(Object _this, android.content.Intent p0, android.os.Bundle p1, android.os.UserHandle p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.app.ContextImpl mthd: startActivityAsUser retCls: void params: android.content.Intent "+convert(p0)+" android.os.Bundle "+convert(p1)+" android.os.UserHandle "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.app.ContextImpl mthd: startActivityAsUser retCls: void params: android.content.Intent "+convert(p0)+" android.os.Bundle "+convert(p1)+" android.os.UserHandle "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1, p2);
    }

    @Redirect("android.app.ContextImpl->startIntentSender")
    public static void redir_android_app_ContextImpl_startIntentSender6(Object _this, android.content.IntentSender p0, android.content.Intent p1, int p2, int p3, int p4, android.os.Bundle p5)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.app.ContextImpl mthd: startIntentSender retCls: void params: android.content.IntentSender "+convert(p0)+" android.content.Intent "+convert(p1)+" int "+convert(p2)+" int "+convert(p3)+" int "+convert(p4)+" android.os.Bundle "+convert(p5)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.app.ContextImpl mthd: startIntentSender retCls: void params: android.content.IntentSender "+convert(p0)+" android.content.Intent "+convert(p1)+" int "+convert(p2)+" int "+convert(p3)+" int "+convert(p4)+" android.os.Bundle "+convert(p5)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1, p2, p3, p4, p5);
    }

    @Redirect("android.app.DownloadManager->addCompletedDownload")
    public static long redir_android_app_DownloadManager_addCompletedDownload7(Object _this, java.lang.String p0, java.lang.String p1, boolean p2, java.lang.String p3, java.lang.String p4, long p5, boolean p6)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.app.DownloadManager mthd: addCompletedDownload retCls: long params: java.lang.String "+convert(p0)+" java.lang.String "+convert(p1)+" boolean "+convert(p2)+" java.lang.String "+convert(p3)+" java.lang.String "+convert(p4)+" long "+convert(p5)+" boolean "+convert(p6)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.app.DownloadManager mthd: addCompletedDownload retCls: long params: java.lang.String "+convert(p0)+" java.lang.String "+convert(p1)+" boolean "+convert(p2)+" java.lang.String "+convert(p3)+" java.lang.String "+convert(p4)+" long "+convert(p5)+" boolean "+convert(p6)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (long) Instrumentation.callLongMethod($.class, _this, p0, p1, p2, p3, p4, p5, p6);
    }

    @Redirect("android.app.DownloadManager->enqueue")
    public static long redir_android_app_DownloadManager_enqueue1(Object _this, android.app.DownloadManager.Request p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.app.DownloadManager mthd: enqueue retCls: long params: android.app.DownloadManager.Request "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.app.DownloadManager mthd: enqueue retCls: long params: android.app.DownloadManager.Request "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (long) Instrumentation.callLongMethod($.class, _this, p0);
    }

    @Redirect("android.app.DownloadManager->getUriForDownloadedFile")
    public static android.net.Uri redir_android_app_DownloadManager_getUriForDownloadedFile1(Object _this, long p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.app.DownloadManager mthd: getUriForDownloadedFile retCls: android.net.Uri params: long "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.app.DownloadManager mthd: getUriForDownloadedFile retCls: android.net.Uri params: long "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.net.Uri) Instrumentation.callObjectMethod($.class, _this, p0);
    }

    @Redirect("android.app.KeyguardManager->exitKeyguardSecurely")
    public static void redir_android_app_KeyguardManager_exitKeyguardSecurely1(Object _this, android.app.KeyguardManager.OnKeyguardExitResult p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.app.KeyguardManager mthd: exitKeyguardSecurely retCls: void params: android.app.KeyguardManager.OnKeyguardExitResult "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.app.KeyguardManager mthd: exitKeyguardSecurely retCls: void params: android.app.KeyguardManager.OnKeyguardExitResult "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0);
    }

    @Redirect("android.app.KeyguardManager$KeyguardLock->disableKeyguard")
    public static void redir_android_app_KeyguardManager_KeyguardLock_disableKeyguard0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.app.KeyguardManager$KeyguardLock mthd: disableKeyguard retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.app.KeyguardManager$KeyguardLock mthd: disableKeyguard retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.app.KeyguardManager$KeyguardLock->reenableKeyguard")
    public static void redir_android_app_KeyguardManager_KeyguardLock_reenableKeyguard0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.app.KeyguardManager$KeyguardLock mthd: reenableKeyguard retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.app.KeyguardManager$KeyguardLock mthd: reenableKeyguard retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.app.NotificationManager->notify")
    public static void redir_android_app_NotificationManager_notify3(Object _this, java.lang.String p0, int p1, android.app.Notification p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.app.NotificationManager mthd: notify retCls: void params: java.lang.String "+convert(p0)+" int "+convert(p1)+" android.app.Notification "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.app.NotificationManager mthd: notify retCls: void params: java.lang.String "+convert(p0)+" int "+convert(p1)+" android.app.Notification "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1, p2);
    }

    @Redirect("android.app.WallpaperManager->clear")
    public static void redir_android_app_WallpaperManager_clear0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.app.WallpaperManager mthd: clear retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.app.WallpaperManager mthd: clear retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.app.WallpaperManager->setBitmap")
    public static void redir_android_app_WallpaperManager_setBitmap1(Object _this, android.graphics.Bitmap p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.app.WallpaperManager mthd: setBitmap retCls: void params: android.graphics.Bitmap "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.app.WallpaperManager mthd: setBitmap retCls: void params: android.graphics.Bitmap "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0);
    }

    @Redirect("android.app.WallpaperManager->setResource")
    public static void redir_android_app_WallpaperManager_setResource1(Object _this, int p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.app.WallpaperManager mthd: setResource retCls: void params: int "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.app.WallpaperManager mthd: setResource retCls: void params: int "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0);
    }

    @Redirect("android.app.WallpaperManager->setStream")
    public static void redir_android_app_WallpaperManager_setStream1(Object _this, java.io.InputStream p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.app.WallpaperManager mthd: setStream retCls: void params: java.io.InputStream "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.app.WallpaperManager mthd: setStream retCls: void params: java.io.InputStream "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0);
    }

    @Redirect("android.app.WallpaperManager->suggestDesiredDimensions")
    public static void redir_android_app_WallpaperManager_suggestDesiredDimensions2(Object _this, int p0, int p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.app.WallpaperManager mthd: suggestDesiredDimensions retCls: void params: int "+convert(p0)+" int "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.app.WallpaperManager mthd: suggestDesiredDimensions retCls: void params: int "+convert(p0)+" int "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1);
    }

    @Redirect("android.bluetooth.BluetoothA2dp->connect")
    public static boolean redir_android_bluetooth_BluetoothA2dp_connect1(Object _this, android.bluetooth.BluetoothDevice p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothA2dp mthd: connect retCls: boolean params: android.bluetooth.BluetoothDevice "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothA2dp mthd: connect retCls: boolean params: android.bluetooth.BluetoothDevice "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this, p0);
    }

    @Redirect("android.bluetooth.BluetoothA2dp->disconnect")
    public static boolean redir_android_bluetooth_BluetoothA2dp_disconnect1(Object _this, android.bluetooth.BluetoothDevice p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothA2dp mthd: disconnect retCls: boolean params: android.bluetooth.BluetoothDevice "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothA2dp mthd: disconnect retCls: boolean params: android.bluetooth.BluetoothDevice "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this, p0);
    }

    @Redirect("android.bluetooth.BluetoothA2dp->getConnectedDevices")
    public static java.util.List redir_android_bluetooth_BluetoothA2dp_getConnectedDevices0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothA2dp mthd: getConnectedDevices retCls: java.util.List params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothA2dp mthd: getConnectedDevices retCls: java.util.List params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (java.util.List) Instrumentation.callObjectMethod($.class, _this);
    }

    @Redirect("android.bluetooth.BluetoothA2dp->getConnectionState")
    public static int redir_android_bluetooth_BluetoothA2dp_getConnectionState1(Object _this, android.bluetooth.BluetoothDevice p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothA2dp mthd: getConnectionState retCls: int params: android.bluetooth.BluetoothDevice "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothA2dp mthd: getConnectionState retCls: int params: android.bluetooth.BluetoothDevice "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (int) Instrumentation.callIntMethod($.class, _this, p0);
    }

    @Redirect("android.bluetooth.BluetoothA2dp->getDevicesMatchingConnectionStates")
    public static java.util.List redir_android_bluetooth_BluetoothA2dp_getDevicesMatchingConnectionStates1(Object _this, int[] p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothA2dp mthd: getDevicesMatchingConnectionStates retCls: java.util.List params: int[] "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothA2dp mthd: getDevicesMatchingConnectionStates retCls: java.util.List params: int[] "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (java.util.List) Instrumentation.callObjectMethod($.class, _this, p0);
    }

    @Redirect("android.bluetooth.BluetoothA2dp->getPriority")
    public static int redir_android_bluetooth_BluetoothA2dp_getPriority1(Object _this, android.bluetooth.BluetoothDevice p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothA2dp mthd: getPriority retCls: int params: android.bluetooth.BluetoothDevice "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothA2dp mthd: getPriority retCls: int params: android.bluetooth.BluetoothDevice "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (int) Instrumentation.callIntMethod($.class, _this, p0);
    }

    @Redirect("android.bluetooth.BluetoothA2dp->isA2dpPlaying")
    public static boolean redir_android_bluetooth_BluetoothA2dp_isA2dpPlaying1(Object _this, android.bluetooth.BluetoothDevice p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothA2dp mthd: isA2dpPlaying retCls: boolean params: android.bluetooth.BluetoothDevice "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothA2dp mthd: isA2dpPlaying retCls: boolean params: android.bluetooth.BluetoothDevice "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this, p0);
    }

    @Redirect("android.bluetooth.BluetoothA2dp->isEnabled")
    public static boolean redir_android_bluetooth_BluetoothA2dp_isEnabled0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothA2dp mthd: isEnabled retCls: boolean params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothA2dp mthd: isEnabled retCls: boolean params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this);
    }

    @Redirect("android.bluetooth.BluetoothA2dp->setPriority")
    public static boolean redir_android_bluetooth_BluetoothA2dp_setPriority2(Object _this, android.bluetooth.BluetoothDevice p0, int p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothA2dp mthd: setPriority retCls: boolean params: android.bluetooth.BluetoothDevice "+convert(p0)+" int "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothA2dp mthd: setPriority retCls: boolean params: android.bluetooth.BluetoothDevice "+convert(p0)+" int "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this, p0, p1);
    }

    @Redirect("android.bluetooth.BluetoothAdapter->cancelDiscovery")
    public static boolean redir_android_bluetooth_BluetoothAdapter_cancelDiscovery0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothAdapter mthd: cancelDiscovery retCls: boolean params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothAdapter mthd: cancelDiscovery retCls: boolean params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this);
    }

    @Redirect("android.bluetooth.BluetoothAdapter->disable")
    public static boolean redir_android_bluetooth_BluetoothAdapter_disable0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothAdapter mthd: disable retCls: boolean params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothAdapter mthd: disable retCls: boolean params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this);
    }

    @Redirect("android.bluetooth.BluetoothAdapter->enable")
    public static boolean redir_android_bluetooth_BluetoothAdapter_enable0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothAdapter mthd: enable retCls: boolean params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothAdapter mthd: enable retCls: boolean params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this);
    }

    @Redirect("android.bluetooth.BluetoothAdapter->getAddress")
    public static java.lang.String redir_android_bluetooth_BluetoothAdapter_getAddress0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothAdapter mthd: getAddress retCls: java.lang.String params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothAdapter mthd: getAddress retCls: java.lang.String params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (java.lang.String) Instrumentation.callObjectMethod($.class, _this);
    }

    @Redirect("android.bluetooth.BluetoothAdapter->getBondedDevices")
    public static java.util.Set redir_android_bluetooth_BluetoothAdapter_getBondedDevices0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothAdapter mthd: getBondedDevices retCls: java.util.Set params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothAdapter mthd: getBondedDevices retCls: java.util.Set params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (java.util.Set) Instrumentation.callObjectMethod($.class, _this);
    }

    @Redirect("android.bluetooth.BluetoothAdapter->getConnectionState")
    public static int redir_android_bluetooth_BluetoothAdapter_getConnectionState0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothAdapter mthd: getConnectionState retCls: int params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothAdapter mthd: getConnectionState retCls: int params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (int) Instrumentation.callIntMethod($.class, _this);
    }

    @Redirect("android.bluetooth.BluetoothAdapter->getName")
    public static java.lang.String redir_android_bluetooth_BluetoothAdapter_getName0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothAdapter mthd: getName retCls: java.lang.String params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothAdapter mthd: getName retCls: java.lang.String params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (java.lang.String) Instrumentation.callObjectMethod($.class, _this);
    }

    @Redirect("android.bluetooth.BluetoothAdapter->getProfileConnectionState")
    public static int redir_android_bluetooth_BluetoothAdapter_getProfileConnectionState1(Object _this, int p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothAdapter mthd: getProfileConnectionState retCls: int params: int "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothAdapter mthd: getProfileConnectionState retCls: int params: int "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (int) Instrumentation.callIntMethod($.class, _this, p0);
    }

    @Redirect("android.bluetooth.BluetoothAdapter->getScanMode")
    public static int redir_android_bluetooth_BluetoothAdapter_getScanMode0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothAdapter mthd: getScanMode retCls: int params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothAdapter mthd: getScanMode retCls: int params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (int) Instrumentation.callIntMethod($.class, _this);
    }

    @Redirect("android.bluetooth.BluetoothAdapter->getState")
    public static int redir_android_bluetooth_BluetoothAdapter_getState0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothAdapter mthd: getState retCls: int params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothAdapter mthd: getState retCls: int params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (int) Instrumentation.callIntMethod($.class, _this);
    }

    @Redirect("android.bluetooth.BluetoothAdapter->getUuids")
    public static android.os.ParcelUuid[] redir_android_bluetooth_BluetoothAdapter_getUuids0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothAdapter mthd: getUuids retCls: android.os.ParcelUuid[] params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothAdapter mthd: getUuids retCls: android.os.ParcelUuid[] params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (android.os.ParcelUuid[]) Instrumentation.callObjectMethod($.class, _this);
    }

    @Redirect("android.bluetooth.BluetoothAdapter->isDiscovering")
    public static boolean redir_android_bluetooth_BluetoothAdapter_isDiscovering0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothAdapter mthd: isDiscovering retCls: boolean params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothAdapter mthd: isDiscovering retCls: boolean params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this);
    }

    @Redirect("android.bluetooth.BluetoothAdapter->isEnabled")
    public static boolean redir_android_bluetooth_BluetoothAdapter_isEnabled0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothAdapter mthd: isEnabled retCls: boolean params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothAdapter mthd: isEnabled retCls: boolean params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this);
    }

    @Redirect("android.bluetooth.BluetoothAdapter->listenUsingInsecureRfcommWithServiceRecord")
    public static android.bluetooth.BluetoothServerSocket redir_android_bluetooth_BluetoothAdapter_listenUsingInsecureRfcommWithServiceRecord2(Object _this, java.lang.String p0, java.util.UUID p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothAdapter mthd: listenUsingInsecureRfcommWithServiceRecord retCls: android.bluetooth.BluetoothServerSocket params: java.lang.String "+convert(p0)+" java.util.UUID "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothAdapter mthd: listenUsingInsecureRfcommWithServiceRecord retCls: android.bluetooth.BluetoothServerSocket params: java.lang.String "+convert(p0)+" java.util.UUID "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.bluetooth.BluetoothServerSocket) Instrumentation.callObjectMethod($.class, _this, p0, p1);
    }

    @Redirect("android.bluetooth.BluetoothAdapter->listenUsingRfcommWithServiceRecord")
    public static android.bluetooth.BluetoothServerSocket redir_android_bluetooth_BluetoothAdapter_listenUsingRfcommWithServiceRecord2(Object _this, java.lang.String p0, java.util.UUID p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothAdapter mthd: listenUsingRfcommWithServiceRecord retCls: android.bluetooth.BluetoothServerSocket params: java.lang.String "+convert(p0)+" java.util.UUID "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothAdapter mthd: listenUsingRfcommWithServiceRecord retCls: android.bluetooth.BluetoothServerSocket params: java.lang.String "+convert(p0)+" java.util.UUID "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.bluetooth.BluetoothServerSocket) Instrumentation.callObjectMethod($.class, _this, p0, p1);
    }

    @Redirect("android.bluetooth.BluetoothAdapter->setName")
    public static boolean redir_android_bluetooth_BluetoothAdapter_setName1(Object _this, java.lang.String p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothAdapter mthd: setName retCls: boolean params: java.lang.String "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothAdapter mthd: setName retCls: boolean params: java.lang.String "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this, p0);
    }

    @Redirect("android.bluetooth.BluetoothAdapter->startDiscovery")
    public static boolean redir_android_bluetooth_BluetoothAdapter_startDiscovery0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothAdapter mthd: startDiscovery retCls: boolean params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothAdapter mthd: startDiscovery retCls: boolean params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this);
    }

    @Redirect("android.bluetooth.BluetoothDevice->createInsecureRfcommSocketToServiceRecord")
    public static android.bluetooth.BluetoothSocket redir_android_bluetooth_BluetoothDevice_createInsecureRfcommSocketToServiceRecord1(Object _this, java.util.UUID p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothDevice mthd: createInsecureRfcommSocketToServiceRecord retCls: android.bluetooth.BluetoothSocket params: java.util.UUID "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothDevice mthd: createInsecureRfcommSocketToServiceRecord retCls: android.bluetooth.BluetoothSocket params: java.util.UUID "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.bluetooth.BluetoothSocket) Instrumentation.callObjectMethod($.class, _this, p0);
    }

    @Redirect("android.bluetooth.BluetoothDevice->createRfcommSocketToServiceRecord")
    public static android.bluetooth.BluetoothSocket redir_android_bluetooth_BluetoothDevice_createRfcommSocketToServiceRecord1(Object _this, java.util.UUID p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothDevice mthd: createRfcommSocketToServiceRecord retCls: android.bluetooth.BluetoothSocket params: java.util.UUID "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothDevice mthd: createRfcommSocketToServiceRecord retCls: android.bluetooth.BluetoothSocket params: java.util.UUID "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.bluetooth.BluetoothSocket) Instrumentation.callObjectMethod($.class, _this, p0);
    }

    @Redirect("android.bluetooth.BluetoothDevice->fetchUuidsWithSdp")
    public static boolean redir_android_bluetooth_BluetoothDevice_fetchUuidsWithSdp0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothDevice mthd: fetchUuidsWithSdp retCls: boolean params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothDevice mthd: fetchUuidsWithSdp retCls: boolean params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this);
    }

    @Redirect("android.bluetooth.BluetoothDevice->getBluetoothClass")
    public static android.bluetooth.BluetoothClass redir_android_bluetooth_BluetoothDevice_getBluetoothClass0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothDevice mthd: getBluetoothClass retCls: android.bluetooth.BluetoothClass params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothDevice mthd: getBluetoothClass retCls: android.bluetooth.BluetoothClass params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (android.bluetooth.BluetoothClass) Instrumentation.callObjectMethod($.class, _this);
    }

    @Redirect("android.bluetooth.BluetoothDevice->getBondState")
    public static int redir_android_bluetooth_BluetoothDevice_getBondState0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothDevice mthd: getBondState retCls: int params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothDevice mthd: getBondState retCls: int params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (int) Instrumentation.callIntMethod($.class, _this);
    }

    @Redirect("android.bluetooth.BluetoothDevice->getName")
    public static java.lang.String redir_android_bluetooth_BluetoothDevice_getName0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothDevice mthd: getName retCls: java.lang.String params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothDevice mthd: getName retCls: java.lang.String params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (java.lang.String) Instrumentation.callObjectMethod($.class, _this);
    }

    @Redirect("android.bluetooth.BluetoothDevice->getUuids")
    public static android.os.ParcelUuid[] redir_android_bluetooth_BluetoothDevice_getUuids0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothDevice mthd: getUuids retCls: android.os.ParcelUuid[] params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothDevice mthd: getUuids retCls: android.os.ParcelUuid[] params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (android.os.ParcelUuid[]) Instrumentation.callObjectMethod($.class, _this);
    }

    @Redirect("android.bluetooth.BluetoothHeadset->connect")
    public static boolean redir_android_bluetooth_BluetoothHeadset_connect1(Object _this, android.bluetooth.BluetoothDevice p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothHeadset mthd: connect retCls: boolean params: android.bluetooth.BluetoothDevice "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothHeadset mthd: connect retCls: boolean params: android.bluetooth.BluetoothDevice "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this, p0);
    }

    @Redirect("android.bluetooth.BluetoothHeadset->disconnect")
    public static boolean redir_android_bluetooth_BluetoothHeadset_disconnect1(Object _this, android.bluetooth.BluetoothDevice p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothHeadset mthd: disconnect retCls: boolean params: android.bluetooth.BluetoothDevice "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothHeadset mthd: disconnect retCls: boolean params: android.bluetooth.BluetoothDevice "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this, p0);
    }

    @Redirect("android.bluetooth.BluetoothHeadset->getConnectedDevices")
    public static java.util.List redir_android_bluetooth_BluetoothHeadset_getConnectedDevices0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothHeadset mthd: getConnectedDevices retCls: java.util.List params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothHeadset mthd: getConnectedDevices retCls: java.util.List params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (java.util.List) Instrumentation.callObjectMethod($.class, _this);
    }

    @Redirect("android.bluetooth.BluetoothHeadset->getConnectionState")
    public static int redir_android_bluetooth_BluetoothHeadset_getConnectionState1(Object _this, android.bluetooth.BluetoothDevice p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothHeadset mthd: getConnectionState retCls: int params: android.bluetooth.BluetoothDevice "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothHeadset mthd: getConnectionState retCls: int params: android.bluetooth.BluetoothDevice "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (int) Instrumentation.callIntMethod($.class, _this, p0);
    }

    @Redirect("android.bluetooth.BluetoothHeadset->getDevicesMatchingConnectionStates")
    public static java.util.List redir_android_bluetooth_BluetoothHeadset_getDevicesMatchingConnectionStates1(Object _this, int[] p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothHeadset mthd: getDevicesMatchingConnectionStates retCls: java.util.List params: int[] "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothHeadset mthd: getDevicesMatchingConnectionStates retCls: java.util.List params: int[] "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (java.util.List) Instrumentation.callObjectMethod($.class, _this, p0);
    }

    @Redirect("android.bluetooth.BluetoothHeadset->getPriority")
    public static int redir_android_bluetooth_BluetoothHeadset_getPriority1(Object _this, android.bluetooth.BluetoothDevice p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothHeadset mthd: getPriority retCls: int params: android.bluetooth.BluetoothDevice "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothHeadset mthd: getPriority retCls: int params: android.bluetooth.BluetoothDevice "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (int) Instrumentation.callIntMethod($.class, _this, p0);
    }

    @Redirect("android.bluetooth.BluetoothHeadset->isAudioConnected")
    public static boolean redir_android_bluetooth_BluetoothHeadset_isAudioConnected1(Object _this, android.bluetooth.BluetoothDevice p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothHeadset mthd: isAudioConnected retCls: boolean params: android.bluetooth.BluetoothDevice "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothHeadset mthd: isAudioConnected retCls: boolean params: android.bluetooth.BluetoothDevice "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this, p0);
    }

    @Redirect("android.bluetooth.BluetoothHeadset->isEnabled")
    public static boolean redir_android_bluetooth_BluetoothHeadset_isEnabled0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothHeadset mthd: isEnabled retCls: boolean params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothHeadset mthd: isEnabled retCls: boolean params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this);
    }

    @Redirect("android.bluetooth.BluetoothHeadset->setPriority")
    public static boolean redir_android_bluetooth_BluetoothHeadset_setPriority2(Object _this, android.bluetooth.BluetoothDevice p0, int p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothHeadset mthd: setPriority retCls: boolean params: android.bluetooth.BluetoothDevice "+convert(p0)+" int "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothHeadset mthd: setPriority retCls: boolean params: android.bluetooth.BluetoothDevice "+convert(p0)+" int "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this, p0, p1);
    }

    @Redirect("android.bluetooth.BluetoothHeadset->startVoiceRecognition")
    public static boolean redir_android_bluetooth_BluetoothHeadset_startVoiceRecognition1(Object _this, android.bluetooth.BluetoothDevice p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothHeadset mthd: startVoiceRecognition retCls: boolean params: android.bluetooth.BluetoothDevice "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothHeadset mthd: startVoiceRecognition retCls: boolean params: android.bluetooth.BluetoothDevice "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this, p0);
    }

    @Redirect("android.bluetooth.BluetoothHeadset->stopVoiceRecognition")
    public static boolean redir_android_bluetooth_BluetoothHeadset_stopVoiceRecognition1(Object _this, android.bluetooth.BluetoothDevice p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothHeadset mthd: stopVoiceRecognition retCls: boolean params: android.bluetooth.BluetoothDevice "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothHeadset mthd: stopVoiceRecognition retCls: boolean params: android.bluetooth.BluetoothDevice "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this, p0);
    }

    @Redirect("android.bluetooth.BluetoothHealth->connectChannelToSource")
    public static boolean redir_android_bluetooth_BluetoothHealth_connectChannelToSource2(Object _this, android.bluetooth.BluetoothDevice p0, android.bluetooth.BluetoothHealthAppConfiguration p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothHealth mthd: connectChannelToSource retCls: boolean params: android.bluetooth.BluetoothDevice "+convert(p0)+" android.bluetooth.BluetoothHealthAppConfiguration "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothHealth mthd: connectChannelToSource retCls: boolean params: android.bluetooth.BluetoothDevice "+convert(p0)+" android.bluetooth.BluetoothHealthAppConfiguration "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this, p0, p1);
    }

    @Redirect("android.bluetooth.BluetoothHealth->disconnectChannel")
    public static boolean redir_android_bluetooth_BluetoothHealth_disconnectChannel3(Object _this, android.bluetooth.BluetoothDevice p0, android.bluetooth.BluetoothHealthAppConfiguration p1, int p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothHealth mthd: disconnectChannel retCls: boolean params: android.bluetooth.BluetoothDevice "+convert(p0)+" android.bluetooth.BluetoothHealthAppConfiguration "+convert(p1)+" int "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothHealth mthd: disconnectChannel retCls: boolean params: android.bluetooth.BluetoothDevice "+convert(p0)+" android.bluetooth.BluetoothHealthAppConfiguration "+convert(p1)+" int "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this, p0, p1, p2);
    }

    @Redirect("android.bluetooth.BluetoothHealth->getConnectedDevices")
    public static java.util.List redir_android_bluetooth_BluetoothHealth_getConnectedDevices0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothHealth mthd: getConnectedDevices retCls: java.util.List params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothHealth mthd: getConnectedDevices retCls: java.util.List params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (java.util.List) Instrumentation.callObjectMethod($.class, _this);
    }

    @Redirect("android.bluetooth.BluetoothHealth->getConnectionState")
    public static int redir_android_bluetooth_BluetoothHealth_getConnectionState1(Object _this, android.bluetooth.BluetoothDevice p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothHealth mthd: getConnectionState retCls: int params: android.bluetooth.BluetoothDevice "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothHealth mthd: getConnectionState retCls: int params: android.bluetooth.BluetoothDevice "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (int) Instrumentation.callIntMethod($.class, _this, p0);
    }

    @Redirect("android.bluetooth.BluetoothHealth->getDevicesMatchingConnectionStates")
    public static java.util.List redir_android_bluetooth_BluetoothHealth_getDevicesMatchingConnectionStates1(Object _this, int[] p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothHealth mthd: getDevicesMatchingConnectionStates retCls: java.util.List params: int[] "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothHealth mthd: getDevicesMatchingConnectionStates retCls: java.util.List params: int[] "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (java.util.List) Instrumentation.callObjectMethod($.class, _this, p0);
    }

    @Redirect("android.bluetooth.BluetoothHealth->getMainChannelFd")
    public static android.os.ParcelFileDescriptor redir_android_bluetooth_BluetoothHealth_getMainChannelFd2(Object _this, android.bluetooth.BluetoothDevice p0, android.bluetooth.BluetoothHealthAppConfiguration p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothHealth mthd: getMainChannelFd retCls: android.os.ParcelFileDescriptor params: android.bluetooth.BluetoothDevice "+convert(p0)+" android.bluetooth.BluetoothHealthAppConfiguration "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothHealth mthd: getMainChannelFd retCls: android.os.ParcelFileDescriptor params: android.bluetooth.BluetoothDevice "+convert(p0)+" android.bluetooth.BluetoothHealthAppConfiguration "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.os.ParcelFileDescriptor) Instrumentation.callObjectMethod($.class, _this, p0, p1);
    }

    @Redirect("android.bluetooth.BluetoothHealth->isEnabled")
    public static boolean redir_android_bluetooth_BluetoothHealth_isEnabled0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothHealth mthd: isEnabled retCls: boolean params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothHealth mthd: isEnabled retCls: boolean params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this);
    }

    @Redirect("android.bluetooth.BluetoothHealth->registerSinkAppConfiguration")
    public static boolean redir_android_bluetooth_BluetoothHealth_registerSinkAppConfiguration3(Object _this, java.lang.String p0, int p1, android.bluetooth.BluetoothHealthCallback p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothHealth mthd: registerSinkAppConfiguration retCls: boolean params: java.lang.String "+convert(p0)+" int "+convert(p1)+" android.bluetooth.BluetoothHealthCallback "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothHealth mthd: registerSinkAppConfiguration retCls: boolean params: java.lang.String "+convert(p0)+" int "+convert(p1)+" android.bluetooth.BluetoothHealthCallback "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this, p0, p1, p2);
    }

    @Redirect("android.bluetooth.BluetoothHealth->unregisterAppConfiguration")
    public static boolean redir_android_bluetooth_BluetoothHealth_unregisterAppConfiguration1(Object _this, android.bluetooth.BluetoothHealthAppConfiguration p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothHealth mthd: unregisterAppConfiguration retCls: boolean params: android.bluetooth.BluetoothHealthAppConfiguration "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothHealth mthd: unregisterAppConfiguration retCls: boolean params: android.bluetooth.BluetoothHealthAppConfiguration "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this, p0);
    }

    @Redirect("android.bluetooth.BluetoothSocket->connect")
    public static void redir_android_bluetooth_BluetoothSocket_connect0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.bluetooth.BluetoothSocket mthd: connect retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.bluetooth.BluetoothSocket mthd: connect retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.content.ContentProviderClient->bulkInsert")
    public static int redir_android_content_ContentProviderClient_bulkInsert2(Object _this, android.net.Uri p0, android.content.ContentValues[] p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.content.ContentProviderClient mthd: bulkInsert retCls: int params: android.net.Uri "+convert(p0)+" android.content.ContentValues[] "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.content.ContentProviderClient mthd: bulkInsert retCls: int params: android.net.Uri "+convert(p0)+" android.content.ContentValues[] "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (int) Instrumentation.callIntMethod($.class, _this, p0, p1);
    }

    @Redirect("android.content.ContentProviderClient->delete")
    public static int redir_android_content_ContentProviderClient_delete3(Object _this, android.net.Uri p0, java.lang.String p1, java.lang.String[] p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.content.ContentProviderClient mthd: delete retCls: int params: android.net.Uri "+convert(p0)+" java.lang.String "+convert(p1)+" java.lang.String[] "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.content.ContentProviderClient mthd: delete retCls: int params: android.net.Uri "+convert(p0)+" java.lang.String "+convert(p1)+" java.lang.String[] "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (int) Instrumentation.callIntMethod($.class, _this, p0, p1, p2);
    }

    @Redirect("android.content.ContentProviderClient->insert")
    public static android.net.Uri redir_android_content_ContentProviderClient_insert2(Object _this, android.net.Uri p0, android.content.ContentValues p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.content.ContentProviderClient mthd: insert retCls: android.net.Uri params: android.net.Uri "+convert(p0)+" android.content.ContentValues "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.content.ContentProviderClient mthd: insert retCls: android.net.Uri params: android.net.Uri "+convert(p0)+" android.content.ContentValues "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.net.Uri) Instrumentation.callObjectMethod($.class, _this, p0, p1);
    }

    @Redirect("android.content.ContentProviderClient->openFile")
    public static android.os.ParcelFileDescriptor redir_android_content_ContentProviderClient_openFile2(Object _this, android.net.Uri p0, java.lang.String p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.content.ContentProviderClient mthd: openFile retCls: android.os.ParcelFileDescriptor params: android.net.Uri "+convert(p0)+" java.lang.String "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.content.ContentProviderClient mthd: openFile retCls: android.os.ParcelFileDescriptor params: android.net.Uri "+convert(p0)+" java.lang.String "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.os.ParcelFileDescriptor) Instrumentation.callObjectMethod($.class, _this, p0, p1);
    }

    @Redirect("android.content.ContentProviderClient->openFile")
    public static android.os.ParcelFileDescriptor redir_android_content_ContentProviderClient_openFile3(Object _this, android.net.Uri p0, java.lang.String p1, android.os.CancellationSignal p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.content.ContentProviderClient mthd: openFile retCls: android.os.ParcelFileDescriptor params: android.net.Uri "+convert(p0)+" java.lang.String "+convert(p1)+" android.os.CancellationSignal "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.content.ContentProviderClient mthd: openFile retCls: android.os.ParcelFileDescriptor params: android.net.Uri "+convert(p0)+" java.lang.String "+convert(p1)+" android.os.CancellationSignal "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.os.ParcelFileDescriptor) Instrumentation.callObjectMethod($.class, _this, p0, p1, p2);
    }

    @Redirect("android.content.ContentProviderClient->query")
    public static android.database.Cursor redir_android_content_ContentProviderClient_query5(Object _this, android.net.Uri p0, java.lang.String[] p1, java.lang.String p2, java.lang.String[] p3, java.lang.String p4)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.content.ContentProviderClient mthd: query retCls: android.database.Cursor params: android.net.Uri "+convert(p0)+" java.lang.String[] "+convert(p1)+" java.lang.String "+convert(p2)+" java.lang.String[] "+convert(p3)+" java.lang.String "+convert(p4)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.content.ContentProviderClient mthd: query retCls: android.database.Cursor params: android.net.Uri "+convert(p0)+" java.lang.String[] "+convert(p1)+" java.lang.String "+convert(p2)+" java.lang.String[] "+convert(p3)+" java.lang.String "+convert(p4)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.database.Cursor) Instrumentation.callObjectMethod($.class, _this, p0, p1, p2, p3, p4);
    }

    @Redirect("android.content.ContentProviderClient->query")
    public static android.database.Cursor redir_android_content_ContentProviderClient_query6(Object _this, android.net.Uri p0, java.lang.String[] p1, java.lang.String p2, java.lang.String[] p3, java.lang.String p4, android.os.CancellationSignal p5)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.content.ContentProviderClient mthd: query retCls: android.database.Cursor params: android.net.Uri "+convert(p0)+" java.lang.String[] "+convert(p1)+" java.lang.String "+convert(p2)+" java.lang.String[] "+convert(p3)+" java.lang.String "+convert(p4)+" android.os.CancellationSignal "+convert(p5)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.content.ContentProviderClient mthd: query retCls: android.database.Cursor params: android.net.Uri "+convert(p0)+" java.lang.String[] "+convert(p1)+" java.lang.String "+convert(p2)+" java.lang.String[] "+convert(p3)+" java.lang.String "+convert(p4)+" android.os.CancellationSignal "+convert(p5)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.database.Cursor) Instrumentation.callObjectMethod($.class, _this, p0, p1, p2, p3, p4, p5);
    }

    @Redirect("android.content.ContentProviderClient->update")
    public static int redir_android_content_ContentProviderClient_update4(Object _this, android.net.Uri p0, android.content.ContentValues p1, java.lang.String p2, java.lang.String[] p3)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.content.ContentProviderClient mthd: update retCls: int params: android.net.Uri "+convert(p0)+" android.content.ContentValues "+convert(p1)+" java.lang.String "+convert(p2)+" java.lang.String[] "+convert(p3)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.content.ContentProviderClient mthd: update retCls: int params: android.net.Uri "+convert(p0)+" android.content.ContentValues "+convert(p1)+" java.lang.String "+convert(p2)+" java.lang.String[] "+convert(p3)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (int) Instrumentation.callIntMethod($.class, _this, p0, p1, p2, p3);
    }

    @Redirect("android.content.ContentResolver->addPeriodicSync")
    public static void redir_android_content_ContentResolver_addPeriodicSync4(android.accounts.Account p0, java.lang.String p1, android.os.Bundle p2, long p3)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.content.ContentResolver mthd: addPeriodicSync retCls: void params: android.accounts.Account "+convert(p0)+" java.lang.String "+convert(p1)+" android.os.Bundle "+convert(p2)+" long "+convert(p3)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.content.ContentResolver mthd: addPeriodicSync retCls: void params: android.accounts.Account "+convert(p0)+" java.lang.String "+convert(p1)+" android.os.Bundle "+convert(p2)+" long "+convert(p3)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callStaticVoidMethod($.class, Object.class, p0, p1, p2, p3);
    }

    @Redirect("android.content.ContentResolver->applyBatch")
    public static android.content.ContentProviderResult[] redir_android_content_ContentResolver_applyBatch2(Object _this, java.lang.String p0, java.util.ArrayList p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.content.ContentResolver mthd: applyBatch retCls: android.content.ContentProviderResult[] params: java.lang.String "+convert(p0)+" java.util.ArrayList "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.content.ContentResolver mthd: applyBatch retCls: android.content.ContentProviderResult[] params: java.lang.String "+convert(p0)+" java.util.ArrayList "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.content.ContentProviderResult[]) Instrumentation.callObjectMethod($.class, _this, p0, p1);
    }

    @Redirect("android.content.ContentResolver->bulkInsert")
    public static int redir_android_content_ContentResolver_bulkInsert2(Object _this, android.net.Uri p0, android.content.ContentValues[] p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.content.ContentResolver mthd: bulkInsert retCls: int params: android.net.Uri "+convert(p0)+" android.content.ContentValues[] "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.content.ContentResolver mthd: bulkInsert retCls: int params: android.net.Uri "+convert(p0)+" android.content.ContentValues[] "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (int) Instrumentation.callIntMethod($.class, _this, p0, p1);
    }

    @Redirect("android.content.ContentResolver->delete")
    public static int redir_android_content_ContentResolver_delete3(Object _this, android.net.Uri p0, java.lang.String p1, java.lang.String[] p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.content.ContentResolver mthd: delete retCls: int params: android.net.Uri "+convert(p0)+" java.lang.String "+convert(p1)+" java.lang.String[] "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.content.ContentResolver mthd: delete retCls: int params: android.net.Uri "+convert(p0)+" java.lang.String "+convert(p1)+" java.lang.String[] "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (int) Instrumentation.callIntMethod($.class, _this, p0, p1, p2);
    }

    @Redirect("android.content.ContentResolver->getCurrentSync")
    public static android.content.SyncInfo redir_android_content_ContentResolver_getCurrentSync0()
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.content.ContentResolver mthd: getCurrentSync retCls: android.content.SyncInfo params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.content.ContentResolver mthd: getCurrentSync retCls: android.content.SyncInfo params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (android.content.SyncInfo) Instrumentation.callStaticObjectMethod($.class, Object.class, 0);
    }

    @Redirect("android.content.ContentResolver->getCurrentSyncs")
    public static java.util.List redir_android_content_ContentResolver_getCurrentSyncs0()
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.content.ContentResolver mthd: getCurrentSyncs retCls: java.util.List params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.content.ContentResolver mthd: getCurrentSyncs retCls: java.util.List params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (java.util.List) Instrumentation.callStaticObjectMethod($.class, Object.class, 0);
    }

    @Redirect("android.content.ContentResolver->getIsSyncable")
    public static int redir_android_content_ContentResolver_getIsSyncable2(android.accounts.Account p0, java.lang.String p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.content.ContentResolver mthd: getIsSyncable retCls: int params: android.accounts.Account "+convert(p0)+" java.lang.String "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.content.ContentResolver mthd: getIsSyncable retCls: int params: android.accounts.Account "+convert(p0)+" java.lang.String "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (int) Instrumentation.callStaticIntMethod($.class, Object.class, p0, p1);
    }

    @Redirect("android.content.ContentResolver->getMasterSyncAutomatically")
    public static boolean redir_android_content_ContentResolver_getMasterSyncAutomatically0()
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.content.ContentResolver mthd: getMasterSyncAutomatically retCls: boolean params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.content.ContentResolver mthd: getMasterSyncAutomatically retCls: boolean params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callStaticBooleanMethod($.class, Object.class, 0);
    }

    @Redirect("android.content.ContentResolver->getPeriodicSyncs")
    public static java.util.List redir_android_content_ContentResolver_getPeriodicSyncs2(android.accounts.Account p0, java.lang.String p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.content.ContentResolver mthd: getPeriodicSyncs retCls: java.util.List params: android.accounts.Account "+convert(p0)+" java.lang.String "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.content.ContentResolver mthd: getPeriodicSyncs retCls: java.util.List params: android.accounts.Account "+convert(p0)+" java.lang.String "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (java.util.List) Instrumentation.callStaticObjectMethod($.class, Object.class, p0, p1);
    }

    @Redirect("android.content.ContentResolver->getSyncAutomatically")
    public static boolean redir_android_content_ContentResolver_getSyncAutomatically2(android.accounts.Account p0, java.lang.String p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.content.ContentResolver mthd: getSyncAutomatically retCls: boolean params: android.accounts.Account "+convert(p0)+" java.lang.String "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.content.ContentResolver mthd: getSyncAutomatically retCls: boolean params: android.accounts.Account "+convert(p0)+" java.lang.String "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callStaticBooleanMethod($.class, Object.class, p0, p1);
    }

    @Redirect("android.content.ContentResolver->insert")
    public static android.net.Uri redir_android_content_ContentResolver_insert2(Object _this, android.net.Uri p0, android.content.ContentValues p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.content.ContentResolver mthd: insert retCls: android.net.Uri params: android.net.Uri "+convert(p0)+" android.content.ContentValues "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.content.ContentResolver mthd: insert retCls: android.net.Uri params: android.net.Uri "+convert(p0)+" android.content.ContentValues "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.net.Uri) Instrumentation.callObjectMethod($.class, _this, p0, p1);
    }

    @Redirect("android.content.ContentResolver->isSyncActive")
    public static boolean redir_android_content_ContentResolver_isSyncActive2(android.accounts.Account p0, java.lang.String p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.content.ContentResolver mthd: isSyncActive retCls: boolean params: android.accounts.Account "+convert(p0)+" java.lang.String "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.content.ContentResolver mthd: isSyncActive retCls: boolean params: android.accounts.Account "+convert(p0)+" java.lang.String "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callStaticBooleanMethod($.class, Object.class, p0, p1);
    }

    @Redirect("android.content.ContentResolver->isSyncPending")
    public static boolean redir_android_content_ContentResolver_isSyncPending2(android.accounts.Account p0, java.lang.String p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.content.ContentResolver mthd: isSyncPending retCls: boolean params: android.accounts.Account "+convert(p0)+" java.lang.String "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.content.ContentResolver mthd: isSyncPending retCls: boolean params: android.accounts.Account "+convert(p0)+" java.lang.String "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callStaticBooleanMethod($.class, Object.class, p0, p1);
    }

    @Redirect("android.content.ContentResolver->openFileDescriptor")
    public static android.os.ParcelFileDescriptor redir_android_content_ContentResolver_openFileDescriptor3(Object _this, android.net.Uri p0, java.lang.String p1, android.os.CancellationSignal p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.content.ContentResolver mthd: openFileDescriptor retCls: android.os.ParcelFileDescriptor params: android.net.Uri "+convert(p0)+" java.lang.String "+convert(p1)+" android.os.CancellationSignal "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.content.ContentResolver mthd: openFileDescriptor retCls: android.os.ParcelFileDescriptor params: android.net.Uri "+convert(p0)+" java.lang.String "+convert(p1)+" android.os.CancellationSignal "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.os.ParcelFileDescriptor) Instrumentation.callObjectMethod($.class, _this, p0, p1, p2);
    }

    @Redirect("android.content.ContentResolver->openInputStream")
    public static java.io.InputStream redir_android_content_ContentResolver_openInputStream1(Object _this, android.net.Uri p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.content.ContentResolver mthd: openInputStream retCls: java.io.InputStream params: android.net.Uri "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.content.ContentResolver mthd: openInputStream retCls: java.io.InputStream params: android.net.Uri "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (java.io.InputStream) Instrumentation.callObjectMethod($.class, _this, p0);
    }

    @Redirect("android.content.ContentResolver->query")
    public static android.database.Cursor redir_android_content_ContentResolver_query6(Object _this, android.net.Uri p0, java.lang.String[] p1, java.lang.String p2, java.lang.String[] p3, java.lang.String p4, android.os.CancellationSignal p5)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.content.ContentResolver mthd: query retCls: android.database.Cursor params: android.net.Uri "+convert(p0)+" java.lang.String[] "+convert(p1)+" java.lang.String "+convert(p2)+" java.lang.String[] "+convert(p3)+" java.lang.String "+convert(p4)+" android.os.CancellationSignal "+convert(p5)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.content.ContentResolver mthd: query retCls: android.database.Cursor params: android.net.Uri "+convert(p0)+" java.lang.String[] "+convert(p1)+" java.lang.String "+convert(p2)+" java.lang.String[] "+convert(p3)+" java.lang.String "+convert(p4)+" android.os.CancellationSignal "+convert(p5)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.database.Cursor) Instrumentation.callObjectMethod($.class, _this, p0, p1, p2, p3, p4, p5);
    }

    @Redirect("android.content.ContentResolver->registerContentObserver")
    public static void redir_android_content_ContentResolver_registerContentObserver3(Object _this, android.net.Uri p0, boolean p1, android.database.ContentObserver p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.content.ContentResolver mthd: registerContentObserver retCls: void params: android.net.Uri "+convert(p0)+" boolean "+convert(p1)+" android.database.ContentObserver "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.content.ContentResolver mthd: registerContentObserver retCls: void params: android.net.Uri "+convert(p0)+" boolean "+convert(p1)+" android.database.ContentObserver "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1, p2);
    }

    @Redirect("android.content.ContentResolver->removePeriodicSync")
    public static void redir_android_content_ContentResolver_removePeriodicSync3(android.accounts.Account p0, java.lang.String p1, android.os.Bundle p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.content.ContentResolver mthd: removePeriodicSync retCls: void params: android.accounts.Account "+convert(p0)+" java.lang.String "+convert(p1)+" android.os.Bundle "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.content.ContentResolver mthd: removePeriodicSync retCls: void params: android.accounts.Account "+convert(p0)+" java.lang.String "+convert(p1)+" android.os.Bundle "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callStaticVoidMethod($.class, Object.class, p0, p1, p2);
    }

    @Redirect("android.content.ContentResolver->setIsSyncable")
    public static void redir_android_content_ContentResolver_setIsSyncable3(android.accounts.Account p0, java.lang.String p1, int p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.content.ContentResolver mthd: setIsSyncable retCls: void params: android.accounts.Account "+convert(p0)+" java.lang.String "+convert(p1)+" int "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.content.ContentResolver mthd: setIsSyncable retCls: void params: android.accounts.Account "+convert(p0)+" java.lang.String "+convert(p1)+" int "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callStaticVoidMethod($.class, Object.class, p0, p1, p2);
    }

    @Redirect("android.content.ContentResolver->setMasterSyncAutomatically")
    public static void redir_android_content_ContentResolver_setMasterSyncAutomatically1(boolean p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.content.ContentResolver mthd: setMasterSyncAutomatically retCls: void params: boolean "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.content.ContentResolver mthd: setMasterSyncAutomatically retCls: void params: boolean "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callStaticVoidMethod($.class, Object.class, p0);
    }

    @Redirect("android.content.ContentResolver->setSyncAutomatically")
    public static void redir_android_content_ContentResolver_setSyncAutomatically3(android.accounts.Account p0, java.lang.String p1, boolean p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.content.ContentResolver mthd: setSyncAutomatically retCls: void params: android.accounts.Account "+convert(p0)+" java.lang.String "+convert(p1)+" boolean "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.content.ContentResolver mthd: setSyncAutomatically retCls: void params: android.accounts.Account "+convert(p0)+" java.lang.String "+convert(p1)+" boolean "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callStaticVoidMethod($.class, Object.class, p0, p1, p2);
    }

    @Redirect("android.content.ContentResolver->update")
    public static int redir_android_content_ContentResolver_update4(Object _this, android.net.Uri p0, android.content.ContentValues p1, java.lang.String p2, java.lang.String[] p3)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.content.ContentResolver mthd: update retCls: int params: android.net.Uri "+convert(p0)+" android.content.ContentValues "+convert(p1)+" java.lang.String "+convert(p2)+" java.lang.String[] "+convert(p3)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.content.ContentResolver mthd: update retCls: int params: android.net.Uri "+convert(p0)+" android.content.ContentValues "+convert(p1)+" java.lang.String "+convert(p2)+" java.lang.String[] "+convert(p3)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (int) Instrumentation.callIntMethod($.class, _this, p0, p1, p2, p3);
    }

    @Redirect("android.content.ContextWrapper->bindService")
    public static boolean redir_android_content_ContextWrapper_bindService3(Object _this, android.content.Intent p0, android.content.ServiceConnection p1, int p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.content.ContextWrapper mthd: bindService retCls: boolean params: android.content.Intent "+convert(p0)+" android.content.ServiceConnection "+convert(p1)+" int "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.content.ContextWrapper mthd: bindService retCls: boolean params: android.content.Intent "+convert(p0)+" android.content.ServiceConnection "+convert(p1)+" int "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this, p0, p1, p2);
    }

    @Redirect("android.content.ContextWrapper->bindServiceAsUser")
    public static boolean redir_android_content_ContextWrapper_bindServiceAsUser4(Object _this, android.content.Intent p0, android.content.ServiceConnection p1, int p2, android.os.UserHandle p3)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.content.ContextWrapper mthd: bindServiceAsUser retCls: boolean params: android.content.Intent "+convert(p0)+" android.content.ServiceConnection "+convert(p1)+" int "+convert(p2)+" android.os.UserHandle "+convert(p3)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.content.ContextWrapper mthd: bindServiceAsUser retCls: boolean params: android.content.Intent "+convert(p0)+" android.content.ServiceConnection "+convert(p1)+" int "+convert(p2)+" android.os.UserHandle "+convert(p3)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this, p0, p1, p2, p3);
    }

    @Redirect("android.content.ContextWrapper->removeStickyBroadcast")
    public static void redir_android_content_ContextWrapper_removeStickyBroadcast1(Object _this, android.content.Intent p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.content.ContextWrapper mthd: removeStickyBroadcast retCls: void params: android.content.Intent "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.content.ContextWrapper mthd: removeStickyBroadcast retCls: void params: android.content.Intent "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0);
    }

    @Redirect("android.content.ContextWrapper->sendBroadcast")
    public static void redir_android_content_ContextWrapper_sendBroadcast1(Object _this, android.content.Intent p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.content.ContextWrapper mthd: sendBroadcast retCls: void params: android.content.Intent "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.content.ContextWrapper mthd: sendBroadcast retCls: void params: android.content.Intent "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0);
    }

    @Redirect("android.content.ContextWrapper->sendBroadcast")
    public static void redir_android_content_ContextWrapper_sendBroadcast2(Object _this, android.content.Intent p0, java.lang.String p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.content.ContextWrapper mthd: sendBroadcast retCls: void params: android.content.Intent "+convert(p0)+" java.lang.String "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.content.ContextWrapper mthd: sendBroadcast retCls: void params: android.content.Intent "+convert(p0)+" java.lang.String "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1);
    }

    @Redirect("android.content.ContextWrapper->sendBroadcast")
    public static void redir_android_content_ContextWrapper_sendBroadcast3(Object _this, android.content.Intent p0, java.lang.String p1, int p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.content.ContextWrapper mthd: sendBroadcast retCls: void params: android.content.Intent "+convert(p0)+" java.lang.String "+convert(p1)+" int "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.content.ContextWrapper mthd: sendBroadcast retCls: void params: android.content.Intent "+convert(p0)+" java.lang.String "+convert(p1)+" int "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1, p2);
    }

    @Redirect("android.content.ContextWrapper->sendBroadcastAsUser")
    public static void redir_android_content_ContextWrapper_sendBroadcastAsUser2(Object _this, android.content.Intent p0, android.os.UserHandle p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.content.ContextWrapper mthd: sendBroadcastAsUser retCls: void params: android.content.Intent "+convert(p0)+" android.os.UserHandle "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.content.ContextWrapper mthd: sendBroadcastAsUser retCls: void params: android.content.Intent "+convert(p0)+" android.os.UserHandle "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1);
    }

    @Redirect("android.content.ContextWrapper->sendBroadcastAsUser")
    public static void redir_android_content_ContextWrapper_sendBroadcastAsUser3(Object _this, android.content.Intent p0, android.os.UserHandle p1, java.lang.String p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.content.ContextWrapper mthd: sendBroadcastAsUser retCls: void params: android.content.Intent "+convert(p0)+" android.os.UserHandle "+convert(p1)+" java.lang.String "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.content.ContextWrapper mthd: sendBroadcastAsUser retCls: void params: android.content.Intent "+convert(p0)+" android.os.UserHandle "+convert(p1)+" java.lang.String "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1, p2);
    }

    @Redirect("android.content.ContextWrapper->sendOrderedBroadcast")
    public static void redir_android_content_ContextWrapper_sendOrderedBroadcast2(Object _this, android.content.Intent p0, java.lang.String p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.content.ContextWrapper mthd: sendOrderedBroadcast retCls: void params: android.content.Intent "+convert(p0)+" java.lang.String "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.content.ContextWrapper mthd: sendOrderedBroadcast retCls: void params: android.content.Intent "+convert(p0)+" java.lang.String "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1);
    }

    @Redirect("android.content.ContextWrapper->sendOrderedBroadcast")
    public static void redir_android_content_ContextWrapper_sendOrderedBroadcast7(Object _this, android.content.Intent p0, java.lang.String p1, android.content.BroadcastReceiver p2, android.os.Handler p3, int p4, java.lang.String p5, android.os.Bundle p6)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.content.ContextWrapper mthd: sendOrderedBroadcast retCls: void params: android.content.Intent "+convert(p0)+" java.lang.String "+convert(p1)+" android.content.BroadcastReceiver "+convert(p2)+" android.os.Handler "+convert(p3)+" int "+convert(p4)+" java.lang.String "+convert(p5)+" android.os.Bundle "+convert(p6)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.content.ContextWrapper mthd: sendOrderedBroadcast retCls: void params: android.content.Intent "+convert(p0)+" java.lang.String "+convert(p1)+" android.content.BroadcastReceiver "+convert(p2)+" android.os.Handler "+convert(p3)+" int "+convert(p4)+" java.lang.String "+convert(p5)+" android.os.Bundle "+convert(p6)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1, p2, p3, p4, p5, p6);
    }

    @Redirect("android.content.ContextWrapper->sendOrderedBroadcast")
    public static void redir_android_content_ContextWrapper_sendOrderedBroadcast8(Object _this, android.content.Intent p0, java.lang.String p1, int p2, android.content.BroadcastReceiver p3, android.os.Handler p4, int p5, java.lang.String p6, android.os.Bundle p7)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.content.ContextWrapper mthd: sendOrderedBroadcast retCls: void params: android.content.Intent "+convert(p0)+" java.lang.String "+convert(p1)+" int "+convert(p2)+" android.content.BroadcastReceiver "+convert(p3)+" android.os.Handler "+convert(p4)+" int "+convert(p5)+" java.lang.String "+convert(p6)+" android.os.Bundle "+convert(p7)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.content.ContextWrapper mthd: sendOrderedBroadcast retCls: void params: android.content.Intent "+convert(p0)+" java.lang.String "+convert(p1)+" int "+convert(p2)+" android.content.BroadcastReceiver "+convert(p3)+" android.os.Handler "+convert(p4)+" int "+convert(p5)+" java.lang.String "+convert(p6)+" android.os.Bundle "+convert(p7)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1, p2, p3, p4, p5, p6, p7);
    }

    @Redirect("android.content.ContextWrapper->sendOrderedBroadcastAsUser")
    public static void redir_android_content_ContextWrapper_sendOrderedBroadcastAsUser8(Object _this, android.content.Intent p0, android.os.UserHandle p1, java.lang.String p2, android.content.BroadcastReceiver p3, android.os.Handler p4, int p5, java.lang.String p6, android.os.Bundle p7)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.content.ContextWrapper mthd: sendOrderedBroadcastAsUser retCls: void params: android.content.Intent "+convert(p0)+" android.os.UserHandle "+convert(p1)+" java.lang.String "+convert(p2)+" android.content.BroadcastReceiver "+convert(p3)+" android.os.Handler "+convert(p4)+" int "+convert(p5)+" java.lang.String "+convert(p6)+" android.os.Bundle "+convert(p7)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.content.ContextWrapper mthd: sendOrderedBroadcastAsUser retCls: void params: android.content.Intent "+convert(p0)+" android.os.UserHandle "+convert(p1)+" java.lang.String "+convert(p2)+" android.content.BroadcastReceiver "+convert(p3)+" android.os.Handler "+convert(p4)+" int "+convert(p5)+" java.lang.String "+convert(p6)+" android.os.Bundle "+convert(p7)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1, p2, p3, p4, p5, p6, p7);
    }

    @Redirect("android.content.ContextWrapper->sendStickyBroadcast")
    public static void redir_android_content_ContextWrapper_sendStickyBroadcast1(Object _this, android.content.Intent p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.content.ContextWrapper mthd: sendStickyBroadcast retCls: void params: android.content.Intent "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.content.ContextWrapper mthd: sendStickyBroadcast retCls: void params: android.content.Intent "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0);
    }

    @Redirect("android.content.ContextWrapper->sendStickyOrderedBroadcast")
    public static void redir_android_content_ContextWrapper_sendStickyOrderedBroadcast6(Object _this, android.content.Intent p0, android.content.BroadcastReceiver p1, android.os.Handler p2, int p3, java.lang.String p4, android.os.Bundle p5)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.content.ContextWrapper mthd: sendStickyOrderedBroadcast retCls: void params: android.content.Intent "+convert(p0)+" android.content.BroadcastReceiver "+convert(p1)+" android.os.Handler "+convert(p2)+" int "+convert(p3)+" java.lang.String "+convert(p4)+" android.os.Bundle "+convert(p5)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.content.ContextWrapper mthd: sendStickyOrderedBroadcast retCls: void params: android.content.Intent "+convert(p0)+" android.content.BroadcastReceiver "+convert(p1)+" android.os.Handler "+convert(p2)+" int "+convert(p3)+" java.lang.String "+convert(p4)+" android.os.Bundle "+convert(p5)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1, p2, p3, p4, p5);
    }

    @Redirect("android.content.ContextWrapper->startService")
    public static android.content.ComponentName redir_android_content_ContextWrapper_startService1(Object _this, android.content.Intent p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.content.ContextWrapper mthd: startService retCls: android.content.ComponentName params: android.content.Intent "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.content.ContextWrapper mthd: startService retCls: android.content.ComponentName params: android.content.Intent "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.content.ComponentName) Instrumentation.callObjectMethod($.class, _this, p0);
    }

    @Redirect("android.content.ContextWrapper->startServiceAsUser")
    public static android.content.ComponentName redir_android_content_ContextWrapper_startServiceAsUser2(Object _this, android.content.Intent p0, android.os.UserHandle p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.content.ContextWrapper mthd: startServiceAsUser retCls: android.content.ComponentName params: android.content.Intent "+convert(p0)+" android.os.UserHandle "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.content.ContextWrapper mthd: startServiceAsUser retCls: android.content.ComponentName params: android.content.Intent "+convert(p0)+" android.os.UserHandle "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.content.ComponentName) Instrumentation.callObjectMethod($.class, _this, p0, p1);
    }

    @Redirect("android.content.ContextWrapper->stopService")
    public static boolean redir_android_content_ContextWrapper_stopService1(Object _this, android.content.Intent p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.content.ContextWrapper mthd: stopService retCls: boolean params: android.content.Intent "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.content.ContextWrapper mthd: stopService retCls: boolean params: android.content.Intent "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this, p0);
    }

    @Redirect("android.content.ContextWrapper->stopServiceAsUser")
    public static boolean redir_android_content_ContextWrapper_stopServiceAsUser2(Object _this, android.content.Intent p0, android.os.UserHandle p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.content.ContextWrapper mthd: stopServiceAsUser retCls: boolean params: android.content.Intent "+convert(p0)+" android.os.UserHandle "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.content.ContextWrapper mthd: stopServiceAsUser retCls: boolean params: android.content.Intent "+convert(p0)+" android.os.UserHandle "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this, p0, p1);
    }

    @Redirect("android.content.ContextWrapper->unbindService")
    public static void redir_android_content_ContextWrapper_unbindService1(Object _this, android.content.ServiceConnection p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.content.ContextWrapper mthd: unbindService retCls: void params: android.content.ServiceConnection "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.content.ContextWrapper mthd: unbindService retCls: void params: android.content.ServiceConnection "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0);
    }

    @Redirect("android.hardware.Camera->open")
    public static android.hardware.Camera redir_android_hardware_Camera_open0()
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.hardware.Camera mthd: open retCls: android.hardware.Camera params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.hardware.Camera mthd: open retCls: android.hardware.Camera params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (android.hardware.Camera) Instrumentation.callStaticObjectMethod($.class, Object.class, 0);
    }

    @Redirect("android.hardware.Camera->open")
    public static android.hardware.Camera redir_android_hardware_Camera_open1(int p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.hardware.Camera mthd: open retCls: android.hardware.Camera params: int "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.hardware.Camera mthd: open retCls: android.hardware.Camera params: int "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.hardware.Camera) Instrumentation.callStaticObjectMethod($.class, Object.class, p0);
    }

    @Redirect("android.inputmethodservice.KeyboardView->onHoverEvent")
    public static boolean redir_android_inputmethodservice_KeyboardView_onHoverEvent1(Object _this, android.view.MotionEvent p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.inputmethodservice.KeyboardView mthd: onHoverEvent retCls: boolean params: android.view.MotionEvent "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.inputmethodservice.KeyboardView mthd: onHoverEvent retCls: boolean params: android.view.MotionEvent "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this, p0);
    }

    @Redirect("android.inputmethodservice.KeyboardView->onLongPress")
    public static boolean redir_android_inputmethodservice_KeyboardView_onLongPress1(Object _this, android.inputmethodservice.Keyboard.Key p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.inputmethodservice.KeyboardView mthd: onLongPress retCls: boolean params: android.inputmethodservice.Keyboard.Key "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.inputmethodservice.KeyboardView mthd: onLongPress retCls: boolean params: android.inputmethodservice.Keyboard.Key "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this, p0);
    }

    @Redirect("android.inputmethodservice.KeyboardView->onTouchEvent")
    public static boolean redir_android_inputmethodservice_KeyboardView_onTouchEvent1(Object _this, android.view.MotionEvent p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.inputmethodservice.KeyboardView mthd: onTouchEvent retCls: boolean params: android.view.MotionEvent "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.inputmethodservice.KeyboardView mthd: onTouchEvent retCls: boolean params: android.view.MotionEvent "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this, p0);
    }

    @Redirect("android.inputmethodservice.KeyboardView->setKeyboard")
    public static void redir_android_inputmethodservice_KeyboardView_setKeyboard1(Object _this, android.inputmethodservice.Keyboard p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.inputmethodservice.KeyboardView mthd: setKeyboard retCls: void params: android.inputmethodservice.Keyboard "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.inputmethodservice.KeyboardView mthd: setKeyboard retCls: void params: android.inputmethodservice.Keyboard "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0);
    }

    @Redirect("android.location.LocationManager->addGpsStatusListener")
    public static boolean redir_android_location_LocationManager_addGpsStatusListener1(Object _this, android.location.GpsStatus.Listener p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.location.LocationManager mthd: addGpsStatusListener retCls: boolean params: android.location.GpsStatus.Listener "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.location.LocationManager mthd: addGpsStatusListener retCls: boolean params: android.location.GpsStatus.Listener "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this, p0);
    }

    @Redirect("android.location.LocationManager->addNmeaListener")
    public static boolean redir_android_location_LocationManager_addNmeaListener1(Object _this, android.location.GpsStatus.NmeaListener p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.location.LocationManager mthd: addNmeaListener retCls: boolean params: android.location.GpsStatus.NmeaListener "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.location.LocationManager mthd: addNmeaListener retCls: boolean params: android.location.GpsStatus.NmeaListener "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this, p0);
    }

    @Redirect("android.location.LocationManager->addProximityAlert")
    public static void redir_android_location_LocationManager_addProximityAlert5(Object _this, double p0, double p1, float p2, long p3, android.app.PendingIntent p4)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.location.LocationManager mthd: addProximityAlert retCls: void params: double "+convert(p0)+" double "+convert(p1)+" float "+convert(p2)+" long "+convert(p3)+" android.app.PendingIntent "+convert(p4)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.location.LocationManager mthd: addProximityAlert retCls: void params: double "+convert(p0)+" double "+convert(p1)+" float "+convert(p2)+" long "+convert(p3)+" android.app.PendingIntent "+convert(p4)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1, p2, p3, p4);
    }

    @Redirect("android.location.LocationManager->addTestProvider")
    public static void redir_android_location_LocationManager_addTestProvider10(Object _this, java.lang.String p0, boolean p1, boolean p2, boolean p3, boolean p4, boolean p5, boolean p6, boolean p7, int p8, int p9)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.location.LocationManager mthd: addTestProvider retCls: void params: java.lang.String "+convert(p0)+" boolean "+convert(p1)+" boolean "+convert(p2)+" boolean "+convert(p3)+" boolean "+convert(p4)+" boolean "+convert(p5)+" boolean "+convert(p6)+" boolean "+convert(p7)+" int "+convert(p8)+" int "+convert(p9)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.location.LocationManager mthd: addTestProvider retCls: void params: java.lang.String "+convert(p0)+" boolean "+convert(p1)+" boolean "+convert(p2)+" boolean "+convert(p3)+" boolean "+convert(p4)+" boolean "+convert(p5)+" boolean "+convert(p6)+" boolean "+convert(p7)+" int "+convert(p8)+" int "+convert(p9)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9);
    }

    @Redirect("android.location.LocationManager->clearTestProviderEnabled")
    public static void redir_android_location_LocationManager_clearTestProviderEnabled1(Object _this, java.lang.String p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.location.LocationManager mthd: clearTestProviderEnabled retCls: void params: java.lang.String "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.location.LocationManager mthd: clearTestProviderEnabled retCls: void params: java.lang.String "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0);
    }

    @Redirect("android.location.LocationManager->clearTestProviderLocation")
    public static void redir_android_location_LocationManager_clearTestProviderLocation1(Object _this, java.lang.String p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.location.LocationManager mthd: clearTestProviderLocation retCls: void params: java.lang.String "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.location.LocationManager mthd: clearTestProviderLocation retCls: void params: java.lang.String "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0);
    }

    @Redirect("android.location.LocationManager->clearTestProviderStatus")
    public static void redir_android_location_LocationManager_clearTestProviderStatus1(Object _this, java.lang.String p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.location.LocationManager mthd: clearTestProviderStatus retCls: void params: java.lang.String "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.location.LocationManager mthd: clearTestProviderStatus retCls: void params: java.lang.String "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0);
    }

    @Redirect("android.location.LocationManager->getBestProvider")
    public static java.lang.String redir_android_location_LocationManager_getBestProvider2(Object _this, android.location.Criteria p0, boolean p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.location.LocationManager mthd: getBestProvider retCls: java.lang.String params: android.location.Criteria "+convert(p0)+" boolean "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.location.LocationManager mthd: getBestProvider retCls: java.lang.String params: android.location.Criteria "+convert(p0)+" boolean "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (java.lang.String) Instrumentation.callObjectMethod($.class, _this, p0, p1);
    }

    @Redirect("android.location.LocationManager->getLastKnownLocation")
    public static android.location.Location redir_android_location_LocationManager_getLastKnownLocation1(Object _this, java.lang.String p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.location.LocationManager mthd: getLastKnownLocation retCls: android.location.Location params: java.lang.String "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.location.LocationManager mthd: getLastKnownLocation retCls: android.location.Location params: java.lang.String "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.location.Location) Instrumentation.callObjectMethod($.class, _this, p0);
    }

    @Redirect("android.location.LocationManager->getProvider")
    public static android.location.LocationProvider redir_android_location_LocationManager_getProvider1(Object _this, java.lang.String p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.location.LocationManager mthd: getProvider retCls: android.location.LocationProvider params: java.lang.String "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.location.LocationManager mthd: getProvider retCls: android.location.LocationProvider params: java.lang.String "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.location.LocationProvider) Instrumentation.callObjectMethod($.class, _this, p0);
    }

    @Redirect("android.location.LocationManager->getProviders")
    public static java.util.List redir_android_location_LocationManager_getProviders1(Object _this, boolean p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.location.LocationManager mthd: getProviders retCls: java.util.List params: boolean "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.location.LocationManager mthd: getProviders retCls: java.util.List params: boolean "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (java.util.List) Instrumentation.callObjectMethod($.class, _this, p0);
    }

    @Redirect("android.location.LocationManager->getProviders")
    public static java.util.List redir_android_location_LocationManager_getProviders2(Object _this, android.location.Criteria p0, boolean p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.location.LocationManager mthd: getProviders retCls: java.util.List params: android.location.Criteria "+convert(p0)+" boolean "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.location.LocationManager mthd: getProviders retCls: java.util.List params: android.location.Criteria "+convert(p0)+" boolean "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (java.util.List) Instrumentation.callObjectMethod($.class, _this, p0, p1);
    }

    @Redirect("android.location.LocationManager->isProviderEnabled")
    public static boolean redir_android_location_LocationManager_isProviderEnabled1(Object _this, java.lang.String p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.location.LocationManager mthd: isProviderEnabled retCls: boolean params: java.lang.String "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.location.LocationManager mthd: isProviderEnabled retCls: boolean params: java.lang.String "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this, p0);
    }

    @Redirect("android.location.LocationManager->removeTestProvider")
    public static void redir_android_location_LocationManager_removeTestProvider1(Object _this, java.lang.String p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.location.LocationManager mthd: removeTestProvider retCls: void params: java.lang.String "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.location.LocationManager mthd: removeTestProvider retCls: void params: java.lang.String "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0);
    }

    @Redirect("android.location.LocationManager->requestLocationUpdates")
    public static void redir_android_location_LocationManager_requestLocationUpdates4(Object _this, java.lang.String p0, long p1, float p2, android.location.LocationListener p3)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.location.LocationManager mthd: requestLocationUpdates retCls: void params: java.lang.String "+convert(p0)+" long "+convert(p1)+" float "+convert(p2)+" android.location.LocationListener "+convert(p3)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.location.LocationManager mthd: requestLocationUpdates retCls: void params: java.lang.String "+convert(p0)+" long "+convert(p1)+" float "+convert(p2)+" android.location.LocationListener "+convert(p3)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1, p2, p3);
    }

    @Redirect("android.location.LocationManager->requestLocationUpdates")
    public static void redir_android_location_LocationManager_requestLocationUpdates4(Object _this, long p0, float p1, android.location.Criteria p2, android.app.PendingIntent p3)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.location.LocationManager mthd: requestLocationUpdates retCls: void params: long "+convert(p0)+" float "+convert(p1)+" android.location.Criteria "+convert(p2)+" android.app.PendingIntent "+convert(p3)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.location.LocationManager mthd: requestLocationUpdates retCls: void params: long "+convert(p0)+" float "+convert(p1)+" android.location.Criteria "+convert(p2)+" android.app.PendingIntent "+convert(p3)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1, p2, p3);
    }

    @Redirect("android.location.LocationManager->requestLocationUpdates")
    public static void redir_android_location_LocationManager_requestLocationUpdates4(Object _this, java.lang.String p0, long p1, float p2, android.app.PendingIntent p3)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.location.LocationManager mthd: requestLocationUpdates retCls: void params: java.lang.String "+convert(p0)+" long "+convert(p1)+" float "+convert(p2)+" android.app.PendingIntent "+convert(p3)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.location.LocationManager mthd: requestLocationUpdates retCls: void params: java.lang.String "+convert(p0)+" long "+convert(p1)+" float "+convert(p2)+" android.app.PendingIntent "+convert(p3)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1, p2, p3);
    }

    @Redirect("android.location.LocationManager->requestLocationUpdates")
    public static void redir_android_location_LocationManager_requestLocationUpdates5(Object _this, long p0, float p1, android.location.Criteria p2, android.location.LocationListener p3, android.os.Looper p4)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.location.LocationManager mthd: requestLocationUpdates retCls: void params: long "+convert(p0)+" float "+convert(p1)+" android.location.Criteria "+convert(p2)+" android.location.LocationListener "+convert(p3)+" android.os.Looper "+convert(p4)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.location.LocationManager mthd: requestLocationUpdates retCls: void params: long "+convert(p0)+" float "+convert(p1)+" android.location.Criteria "+convert(p2)+" android.location.LocationListener "+convert(p3)+" android.os.Looper "+convert(p4)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1, p2, p3, p4);
    }

    @Redirect("android.location.LocationManager->requestLocationUpdates")
    public static void redir_android_location_LocationManager_requestLocationUpdates5(Object _this, java.lang.String p0, long p1, float p2, android.location.LocationListener p3, android.os.Looper p4)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.location.LocationManager mthd: requestLocationUpdates retCls: void params: java.lang.String "+convert(p0)+" long "+convert(p1)+" float "+convert(p2)+" android.location.LocationListener "+convert(p3)+" android.os.Looper "+convert(p4)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.location.LocationManager mthd: requestLocationUpdates retCls: void params: java.lang.String "+convert(p0)+" long "+convert(p1)+" float "+convert(p2)+" android.location.LocationListener "+convert(p3)+" android.os.Looper "+convert(p4)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1, p2, p3, p4);
    }

    @Redirect("android.location.LocationManager->requestSingleUpdate")
    public static void redir_android_location_LocationManager_requestSingleUpdate2(Object _this, android.location.Criteria p0, android.app.PendingIntent p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.location.LocationManager mthd: requestSingleUpdate retCls: void params: android.location.Criteria "+convert(p0)+" android.app.PendingIntent "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.location.LocationManager mthd: requestSingleUpdate retCls: void params: android.location.Criteria "+convert(p0)+" android.app.PendingIntent "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1);
    }

    @Redirect("android.location.LocationManager->requestSingleUpdate")
    public static void redir_android_location_LocationManager_requestSingleUpdate2(Object _this, java.lang.String p0, android.app.PendingIntent p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.location.LocationManager mthd: requestSingleUpdate retCls: void params: java.lang.String "+convert(p0)+" android.app.PendingIntent "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.location.LocationManager mthd: requestSingleUpdate retCls: void params: java.lang.String "+convert(p0)+" android.app.PendingIntent "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1);
    }

    @Redirect("android.location.LocationManager->requestSingleUpdate")
    public static void redir_android_location_LocationManager_requestSingleUpdate3(Object _this, java.lang.String p0, android.location.LocationListener p1, android.os.Looper p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.location.LocationManager mthd: requestSingleUpdate retCls: void params: java.lang.String "+convert(p0)+" android.location.LocationListener "+convert(p1)+" android.os.Looper "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.location.LocationManager mthd: requestSingleUpdate retCls: void params: java.lang.String "+convert(p0)+" android.location.LocationListener "+convert(p1)+" android.os.Looper "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1, p2);
    }

    @Redirect("android.location.LocationManager->requestSingleUpdate")
    public static void redir_android_location_LocationManager_requestSingleUpdate3(Object _this, android.location.Criteria p0, android.location.LocationListener p1, android.os.Looper p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.location.LocationManager mthd: requestSingleUpdate retCls: void params: android.location.Criteria "+convert(p0)+" android.location.LocationListener "+convert(p1)+" android.os.Looper "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.location.LocationManager mthd: requestSingleUpdate retCls: void params: android.location.Criteria "+convert(p0)+" android.location.LocationListener "+convert(p1)+" android.os.Looper "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1, p2);
    }

    @Redirect("android.location.LocationManager->sendExtraCommand")
    public static boolean redir_android_location_LocationManager_sendExtraCommand3(Object _this, java.lang.String p0, java.lang.String p1, android.os.Bundle p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.location.LocationManager mthd: sendExtraCommand retCls: boolean params: java.lang.String "+convert(p0)+" java.lang.String "+convert(p1)+" android.os.Bundle "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.location.LocationManager mthd: sendExtraCommand retCls: boolean params: java.lang.String "+convert(p0)+" java.lang.String "+convert(p1)+" android.os.Bundle "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this, p0, p1, p2);
    }

    @Redirect("android.location.LocationManager->setTestProviderEnabled")
    public static void redir_android_location_LocationManager_setTestProviderEnabled2(Object _this, java.lang.String p0, boolean p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.location.LocationManager mthd: setTestProviderEnabled retCls: void params: java.lang.String "+convert(p0)+" boolean "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.location.LocationManager mthd: setTestProviderEnabled retCls: void params: java.lang.String "+convert(p0)+" boolean "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1);
    }

    @Redirect("android.location.LocationManager->setTestProviderLocation")
    public static void redir_android_location_LocationManager_setTestProviderLocation2(Object _this, java.lang.String p0, android.location.Location p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.location.LocationManager mthd: setTestProviderLocation retCls: void params: java.lang.String "+convert(p0)+" android.location.Location "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.location.LocationManager mthd: setTestProviderLocation retCls: void params: java.lang.String "+convert(p0)+" android.location.Location "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1);
    }

    @Redirect("android.location.LocationManager->setTestProviderStatus")
    public static void redir_android_location_LocationManager_setTestProviderStatus4(Object _this, java.lang.String p0, int p1, android.os.Bundle p2, long p3)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.location.LocationManager mthd: setTestProviderStatus retCls: void params: java.lang.String "+convert(p0)+" int "+convert(p1)+" android.os.Bundle "+convert(p2)+" long "+convert(p3)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.location.LocationManager mthd: setTestProviderStatus retCls: void params: java.lang.String "+convert(p0)+" int "+convert(p1)+" android.os.Bundle "+convert(p2)+" long "+convert(p3)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1, p2, p3);
    }

    @Redirect("android.media.AsyncPlayer->play")
    public static void redir_android_media_AsyncPlayer_play4(Object _this, android.content.Context p0, android.net.Uri p1, boolean p2, int p3)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.media.AsyncPlayer mthd: play retCls: void params: android.content.Context "+convert(p0)+" android.net.Uri "+convert(p1)+" boolean "+convert(p2)+" int "+convert(p3)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.media.AsyncPlayer mthd: play retCls: void params: android.content.Context "+convert(p0)+" android.net.Uri "+convert(p1)+" boolean "+convert(p2)+" int "+convert(p3)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1, p2, p3);
    }

    @Redirect("android.media.AsyncPlayer->stop")
    public static void redir_android_media_AsyncPlayer_stop0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.media.AsyncPlayer mthd: stop retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.media.AsyncPlayer mthd: stop retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.media.AudioManager->isBluetoothA2dpOn")
    public static boolean redir_android_media_AudioManager_isBluetoothA2dpOn0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.media.AudioManager mthd: isBluetoothA2dpOn retCls: boolean params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.media.AudioManager mthd: isBluetoothA2dpOn retCls: boolean params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this);
    }

    @Redirect("android.media.AudioManager->isWiredHeadsetOn")
    public static boolean redir_android_media_AudioManager_isWiredHeadsetOn0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.media.AudioManager mthd: isWiredHeadsetOn retCls: boolean params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.media.AudioManager mthd: isWiredHeadsetOn retCls: boolean params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this);
    }

    @Redirect("android.media.AudioManager->setBluetoothScoOn")
    public static void redir_android_media_AudioManager_setBluetoothScoOn1(Object _this, boolean p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.media.AudioManager mthd: setBluetoothScoOn retCls: void params: boolean "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.media.AudioManager mthd: setBluetoothScoOn retCls: void params: boolean "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0);
    }

    @Redirect("android.media.AudioManager->setMicrophoneMute")
    public static void redir_android_media_AudioManager_setMicrophoneMute1(Object _this, boolean p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.media.AudioManager mthd: setMicrophoneMute retCls: void params: boolean "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.media.AudioManager mthd: setMicrophoneMute retCls: void params: boolean "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0);
    }

    @Redirect("android.media.AudioManager->setMode")
    public static void redir_android_media_AudioManager_setMode1(Object _this, int p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.media.AudioManager mthd: setMode retCls: void params: int "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.media.AudioManager mthd: setMode retCls: void params: int "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0);
    }

    @Redirect("android.media.AudioManager->setParameter")
    public static void redir_android_media_AudioManager_setParameter2(Object _this, java.lang.String p0, java.lang.String p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.media.AudioManager mthd: setParameter retCls: void params: java.lang.String "+convert(p0)+" java.lang.String "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.media.AudioManager mthd: setParameter retCls: void params: java.lang.String "+convert(p0)+" java.lang.String "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1);
    }

    @Redirect("android.media.AudioManager->setParameters")
    public static void redir_android_media_AudioManager_setParameters1(Object _this, java.lang.String p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.media.AudioManager mthd: setParameters retCls: void params: java.lang.String "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.media.AudioManager mthd: setParameters retCls: void params: java.lang.String "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0);
    }

    @Redirect("android.media.AudioManager->setSpeakerphoneOn")
    public static void redir_android_media_AudioManager_setSpeakerphoneOn1(Object _this, boolean p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.media.AudioManager mthd: setSpeakerphoneOn retCls: void params: boolean "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.media.AudioManager mthd: setSpeakerphoneOn retCls: void params: boolean "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0);
    }

    @Redirect("android.media.AudioManager->startBluetoothSco")
    public static void redir_android_media_AudioManager_startBluetoothSco0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.media.AudioManager mthd: startBluetoothSco retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.media.AudioManager mthd: startBluetoothSco retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.media.AudioManager->stopBluetoothSco")
    public static void redir_android_media_AudioManager_stopBluetoothSco0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.media.AudioManager mthd: stopBluetoothSco retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.media.AudioManager mthd: stopBluetoothSco retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.media.MediaPlayer->pause")
    public static void redir_android_media_MediaPlayer_pause0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.media.MediaPlayer mthd: pause retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.media.MediaPlayer mthd: pause retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.media.MediaPlayer->release")
    public static void redir_android_media_MediaPlayer_release0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.media.MediaPlayer mthd: release retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.media.MediaPlayer mthd: release retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.media.MediaPlayer->reset")
    public static void redir_android_media_MediaPlayer_reset0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.media.MediaPlayer mthd: reset retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.media.MediaPlayer mthd: reset retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.media.MediaPlayer->setWakeMode")
    public static void redir_android_media_MediaPlayer_setWakeMode2(Object _this, android.content.Context p0, int p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.media.MediaPlayer mthd: setWakeMode retCls: void params: android.content.Context "+convert(p0)+" int "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.media.MediaPlayer mthd: setWakeMode retCls: void params: android.content.Context "+convert(p0)+" int "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1);
    }

    @Redirect("android.media.MediaPlayer->start")
    public static void redir_android_media_MediaPlayer_start0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.media.MediaPlayer mthd: start retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.media.MediaPlayer mthd: start retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.media.MediaPlayer->stop")
    public static void redir_android_media_MediaPlayer_stop0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.media.MediaPlayer mthd: stop retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.media.MediaPlayer mthd: stop retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.media.MediaRecorder->setAudioSource")
    public static void redir_android_media_MediaRecorder_setAudioSource1(Object _this, int p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.media.MediaRecorder mthd: setAudioSource retCls: void params: int "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.media.MediaRecorder mthd: setAudioSource retCls: void params: int "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0);
    }

    @Redirect("android.media.MediaRecorder->setVideoSource")
    public static void redir_android_media_MediaRecorder_setVideoSource1(Object _this, int p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.media.MediaRecorder mthd: setVideoSource retCls: void params: int "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.media.MediaRecorder mthd: setVideoSource retCls: void params: int "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0);
    }

    @Redirect("android.media.Ringtone->play")
    public static void redir_android_media_Ringtone_play0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.media.Ringtone mthd: play retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.media.Ringtone mthd: play retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.media.Ringtone->setStreamType")
    public static void redir_android_media_Ringtone_setStreamType1(Object _this, int p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.media.Ringtone mthd: setStreamType retCls: void params: int "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.media.Ringtone mthd: setStreamType retCls: void params: int "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0);
    }

    @Redirect("android.media.Ringtone->setUri")
    public static void redir_android_media_Ringtone_setUri1(Object _this, android.net.Uri p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.media.Ringtone mthd: setUri retCls: void params: android.net.Uri "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.media.Ringtone mthd: setUri retCls: void params: android.net.Uri "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0);
    }

    @Redirect("android.media.Ringtone->stop")
    public static void redir_android_media_Ringtone_stop0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.media.Ringtone mthd: stop retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.media.Ringtone mthd: stop retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.media.RingtoneManager->getRingtone")
    public static android.media.Ringtone redir_android_media_RingtoneManager_getRingtone1(Object _this, int p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.media.RingtoneManager mthd: getRingtone retCls: android.media.Ringtone params: int "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.media.RingtoneManager mthd: getRingtone retCls: android.media.Ringtone params: int "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.media.Ringtone) Instrumentation.callObjectMethod($.class, _this, p0);
    }

    @Redirect("android.media.RingtoneManager->getRingtone")
    public static android.media.Ringtone redir_android_media_RingtoneManager_getRingtone2(android.content.Context p0, android.net.Uri p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.media.RingtoneManager mthd: getRingtone retCls: android.media.Ringtone params: android.content.Context "+convert(p0)+" android.net.Uri "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.media.RingtoneManager mthd: getRingtone retCls: android.media.Ringtone params: android.content.Context "+convert(p0)+" android.net.Uri "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.media.Ringtone) Instrumentation.callStaticObjectMethod($.class, Object.class, p0, p1);
    }

    @Redirect("android.media.RingtoneManager->setActualDefaultRingtoneUri")
    public static void redir_android_media_RingtoneManager_setActualDefaultRingtoneUri3(android.content.Context p0, int p1, android.net.Uri p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.media.RingtoneManager mthd: setActualDefaultRingtoneUri retCls: void params: android.content.Context "+convert(p0)+" int "+convert(p1)+" android.net.Uri "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.media.RingtoneManager mthd: setActualDefaultRingtoneUri retCls: void params: android.content.Context "+convert(p0)+" int "+convert(p1)+" android.net.Uri "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callStaticVoidMethod($.class, Object.class, p0, p1, p2);
    }

    @Redirect("android.media.RingtoneManager->stopPreviousRingtone")
    public static void redir_android_media_RingtoneManager_stopPreviousRingtone0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.media.RingtoneManager mthd: stopPreviousRingtone retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.media.RingtoneManager mthd: stopPreviousRingtone retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.media.effect.EffectContext->release")
    public static void redir_android_media_effect_EffectContext_release0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.media.effect.EffectContext mthd: release retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.media.effect.EffectContext mthd: release retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.net.ConnectivityManager->getActiveNetworkInfo")
    public static android.net.NetworkInfo redir_android_net_ConnectivityManager_getActiveNetworkInfo0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.net.ConnectivityManager mthd: getActiveNetworkInfo retCls: android.net.NetworkInfo params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.net.ConnectivityManager mthd: getActiveNetworkInfo retCls: android.net.NetworkInfo params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (android.net.NetworkInfo) Instrumentation.callObjectMethod($.class, _this);
    }

    @Redirect("android.net.ConnectivityManager->getAllNetworkInfo")
    public static android.net.NetworkInfo[] redir_android_net_ConnectivityManager_getAllNetworkInfo0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.net.ConnectivityManager mthd: getAllNetworkInfo retCls: android.net.NetworkInfo[] params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.net.ConnectivityManager mthd: getAllNetworkInfo retCls: android.net.NetworkInfo[] params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (android.net.NetworkInfo[]) Instrumentation.callObjectMethod($.class, _this);
    }

    @Redirect("android.net.ConnectivityManager->getNetworkInfo")
    public static android.net.NetworkInfo redir_android_net_ConnectivityManager_getNetworkInfo1(Object _this, int p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.net.ConnectivityManager mthd: getNetworkInfo retCls: android.net.NetworkInfo params: int "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.net.ConnectivityManager mthd: getNetworkInfo retCls: android.net.NetworkInfo params: int "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.net.NetworkInfo) Instrumentation.callObjectMethod($.class, _this, p0);
    }

    @Redirect("android.net.ConnectivityManager->getNetworkPreference")
    public static int redir_android_net_ConnectivityManager_getNetworkPreference0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.net.ConnectivityManager mthd: getNetworkPreference retCls: int params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.net.ConnectivityManager mthd: getNetworkPreference retCls: int params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (int) Instrumentation.callIntMethod($.class, _this);
    }

    @Redirect("android.net.ConnectivityManager->isActiveNetworkMetered")
    public static boolean redir_android_net_ConnectivityManager_isActiveNetworkMetered0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.net.ConnectivityManager mthd: isActiveNetworkMetered retCls: boolean params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.net.ConnectivityManager mthd: isActiveNetworkMetered retCls: boolean params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this);
    }

    @Redirect("android.net.ConnectivityManager->requestRouteToHost")
    public static boolean redir_android_net_ConnectivityManager_requestRouteToHost2(Object _this, int p0, int p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.net.ConnectivityManager mthd: requestRouteToHost retCls: boolean params: int "+convert(p0)+" int "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.net.ConnectivityManager mthd: requestRouteToHost retCls: boolean params: int "+convert(p0)+" int "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this, p0, p1);
    }

    @Redirect("android.net.ConnectivityManager->setNetworkPreference")
    public static void redir_android_net_ConnectivityManager_setNetworkPreference1(Object _this, int p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.net.ConnectivityManager mthd: setNetworkPreference retCls: void params: int "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.net.ConnectivityManager mthd: setNetworkPreference retCls: void params: int "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0);
    }

    @Redirect("android.net.ConnectivityManager->startUsingNetworkFeature")
    public static int redir_android_net_ConnectivityManager_startUsingNetworkFeature2(Object _this, int p0, java.lang.String p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.net.ConnectivityManager mthd: startUsingNetworkFeature retCls: int params: int "+convert(p0)+" java.lang.String "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.net.ConnectivityManager mthd: startUsingNetworkFeature retCls: int params: int "+convert(p0)+" java.lang.String "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (int) Instrumentation.callIntMethod($.class, _this, p0, p1);
    }

    @Redirect("android.net.ConnectivityManager->stopUsingNetworkFeature")
    public static int redir_android_net_ConnectivityManager_stopUsingNetworkFeature2(Object _this, int p0, java.lang.String p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.net.ConnectivityManager mthd: stopUsingNetworkFeature retCls: int params: int "+convert(p0)+" java.lang.String "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.net.ConnectivityManager mthd: stopUsingNetworkFeature retCls: int params: int "+convert(p0)+" java.lang.String "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (int) Instrumentation.callIntMethod($.class, _this, p0, p1);
    }

    @Redirect("android.net.nsd.NsdManager->init")
    public static void redir_android_net_nsd_NsdManager_init0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.net.nsd.NsdManager mthd: init retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.net.nsd.NsdManager mthd: init retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.net.nsd.NsdManager->setEnabled")
    public static void redir_android_net_nsd_NsdManager_setEnabled1(Object _this, boolean p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.net.nsd.NsdManager mthd: setEnabled retCls: void params: boolean "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.net.nsd.NsdManager mthd: setEnabled retCls: void params: boolean "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0);
    }

    @Redirect("android.net.wifi.WifiManager->addNetwork")
    public static int redir_android_net_wifi_WifiManager_addNetwork1(Object _this, android.net.wifi.WifiConfiguration p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.net.wifi.WifiManager mthd: addNetwork retCls: int params: android.net.wifi.WifiConfiguration "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.net.wifi.WifiManager mthd: addNetwork retCls: int params: android.net.wifi.WifiConfiguration "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (int) Instrumentation.callIntMethod($.class, _this, p0);
    }

    @Redirect("android.net.wifi.WifiManager->disableNetwork")
    public static boolean redir_android_net_wifi_WifiManager_disableNetwork1(Object _this, int p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.net.wifi.WifiManager mthd: disableNetwork retCls: boolean params: int "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.net.wifi.WifiManager mthd: disableNetwork retCls: boolean params: int "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this, p0);
    }

    @Redirect("android.net.wifi.WifiManager->disconnect")
    public static boolean redir_android_net_wifi_WifiManager_disconnect0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.net.wifi.WifiManager mthd: disconnect retCls: boolean params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.net.wifi.WifiManager mthd: disconnect retCls: boolean params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this);
    }

    @Redirect("android.net.wifi.WifiManager->enableNetwork")
    public static boolean redir_android_net_wifi_WifiManager_enableNetwork2(Object _this, int p0, boolean p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.net.wifi.WifiManager mthd: enableNetwork retCls: boolean params: int "+convert(p0)+" boolean "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.net.wifi.WifiManager mthd: enableNetwork retCls: boolean params: int "+convert(p0)+" boolean "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this, p0, p1);
    }

    @Redirect("android.net.wifi.WifiManager->getConfiguredNetworks")
    public static java.util.List redir_android_net_wifi_WifiManager_getConfiguredNetworks0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.net.wifi.WifiManager mthd: getConfiguredNetworks retCls: java.util.List params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.net.wifi.WifiManager mthd: getConfiguredNetworks retCls: java.util.List params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (java.util.List) Instrumentation.callObjectMethod($.class, _this);
    }

    @Redirect("android.net.wifi.WifiManager->getConnectionInfo")
    public static android.net.wifi.WifiInfo redir_android_net_wifi_WifiManager_getConnectionInfo0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.net.wifi.WifiManager mthd: getConnectionInfo retCls: android.net.wifi.WifiInfo params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.net.wifi.WifiManager mthd: getConnectionInfo retCls: android.net.wifi.WifiInfo params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (android.net.wifi.WifiInfo) Instrumentation.callObjectMethod($.class, _this);
    }

    @Redirect("android.net.wifi.WifiManager->getDhcpInfo")
    public static android.net.DhcpInfo redir_android_net_wifi_WifiManager_getDhcpInfo0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.net.wifi.WifiManager mthd: getDhcpInfo retCls: android.net.DhcpInfo params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.net.wifi.WifiManager mthd: getDhcpInfo retCls: android.net.DhcpInfo params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (android.net.DhcpInfo) Instrumentation.callObjectMethod($.class, _this);
    }

    @Redirect("android.net.wifi.WifiManager->getScanResults")
    public static java.util.List redir_android_net_wifi_WifiManager_getScanResults0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.net.wifi.WifiManager mthd: getScanResults retCls: java.util.List params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.net.wifi.WifiManager mthd: getScanResults retCls: java.util.List params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (java.util.List) Instrumentation.callObjectMethod($.class, _this);
    }

    @Redirect("android.net.wifi.WifiManager->getWifiState")
    public static int redir_android_net_wifi_WifiManager_getWifiState0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.net.wifi.WifiManager mthd: getWifiState retCls: int params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.net.wifi.WifiManager mthd: getWifiState retCls: int params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (int) Instrumentation.callIntMethod($.class, _this);
    }

    @Redirect("android.net.wifi.WifiManager->pingSupplicant")
    public static boolean redir_android_net_wifi_WifiManager_pingSupplicant0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.net.wifi.WifiManager mthd: pingSupplicant retCls: boolean params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.net.wifi.WifiManager mthd: pingSupplicant retCls: boolean params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this);
    }

    @Redirect("android.net.wifi.WifiManager->reassociate")
    public static boolean redir_android_net_wifi_WifiManager_reassociate0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.net.wifi.WifiManager mthd: reassociate retCls: boolean params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.net.wifi.WifiManager mthd: reassociate retCls: boolean params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this);
    }

    @Redirect("android.net.wifi.WifiManager->reconnect")
    public static boolean redir_android_net_wifi_WifiManager_reconnect0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.net.wifi.WifiManager mthd: reconnect retCls: boolean params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.net.wifi.WifiManager mthd: reconnect retCls: boolean params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this);
    }

    @Redirect("android.net.wifi.WifiManager->removeNetwork")
    public static boolean redir_android_net_wifi_WifiManager_removeNetwork1(Object _this, int p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.net.wifi.WifiManager mthd: removeNetwork retCls: boolean params: int "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.net.wifi.WifiManager mthd: removeNetwork retCls: boolean params: int "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this, p0);
    }

    @Redirect("android.net.wifi.WifiManager->saveConfiguration")
    public static boolean redir_android_net_wifi_WifiManager_saveConfiguration0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.net.wifi.WifiManager mthd: saveConfiguration retCls: boolean params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.net.wifi.WifiManager mthd: saveConfiguration retCls: boolean params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this);
    }

    @Redirect("android.net.wifi.WifiManager->setCountryCode")
    public static void redir_android_net_wifi_WifiManager_setCountryCode2(Object _this, java.lang.String p0, boolean p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.net.wifi.WifiManager mthd: setCountryCode retCls: void params: java.lang.String "+convert(p0)+" boolean "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.net.wifi.WifiManager mthd: setCountryCode retCls: void params: java.lang.String "+convert(p0)+" boolean "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1);
    }

    @Redirect("android.net.wifi.WifiManager->setWifiEnabled")
    public static boolean redir_android_net_wifi_WifiManager_setWifiEnabled1(Object _this, boolean p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.net.wifi.WifiManager mthd: setWifiEnabled retCls: boolean params: boolean "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.net.wifi.WifiManager mthd: setWifiEnabled retCls: boolean params: boolean "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this, p0);
    }

    @Redirect("android.net.wifi.WifiManager->startScan")
    public static boolean redir_android_net_wifi_WifiManager_startScan0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.net.wifi.WifiManager mthd: startScan retCls: boolean params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.net.wifi.WifiManager mthd: startScan retCls: boolean params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this);
    }

    @Redirect("android.net.wifi.WifiManager->updateNetwork")
    public static int redir_android_net_wifi_WifiManager_updateNetwork1(Object _this, android.net.wifi.WifiConfiguration p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.net.wifi.WifiManager mthd: updateNetwork retCls: int params: android.net.wifi.WifiConfiguration "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.net.wifi.WifiManager mthd: updateNetwork retCls: int params: android.net.wifi.WifiConfiguration "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (int) Instrumentation.callIntMethod($.class, _this, p0);
    }

    @Redirect("android.net.wifi.WifiManager$MulticastLock->acquire")
    public static void redir_android_net_wifi_WifiManager_MulticastLock_acquire0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.net.wifi.WifiManager$MulticastLock mthd: acquire retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.net.wifi.WifiManager$MulticastLock mthd: acquire retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.net.wifi.WifiManager$MulticastLock->finalize")
    public static void redir_android_net_wifi_WifiManager_MulticastLock_finalize0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.net.wifi.WifiManager$MulticastLock mthd: finalize retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.net.wifi.WifiManager$MulticastLock mthd: finalize retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.net.wifi.WifiManager$MulticastLock->release")
    public static void redir_android_net_wifi_WifiManager_MulticastLock_release0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.net.wifi.WifiManager$MulticastLock mthd: release retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.net.wifi.WifiManager$MulticastLock mthd: release retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.net.wifi.WifiManager$WifiLock->acquire")
    public static void redir_android_net_wifi_WifiManager_WifiLock_acquire0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.net.wifi.WifiManager$WifiLock mthd: acquire retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.net.wifi.WifiManager$WifiLock mthd: acquire retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.net.wifi.WifiManager$WifiLock->finalize")
    public static void redir_android_net_wifi_WifiManager_WifiLock_finalize0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.net.wifi.WifiManager$WifiLock mthd: finalize retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.net.wifi.WifiManager$WifiLock mthd: finalize retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.net.wifi.WifiManager$WifiLock->release")
    public static void redir_android_net_wifi_WifiManager_WifiLock_release0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.net.wifi.WifiManager$WifiLock mthd: release retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.net.wifi.WifiManager$WifiLock mthd: release retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.net.wifi.p2p.WifiP2pManager->initialize")
    public static android.net.wifi.p2p.WifiP2pManager.Channel redir_android_net_wifi_p2p_WifiP2pManager_initialize3(Object _this, android.content.Context p0, android.os.Looper p1, android.net.wifi.p2p.WifiP2pManager.ChannelListener p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.net.wifi.p2p.WifiP2pManager mthd: initialize retCls: android.net.wifi.p2p.WifiP2pManager.Channel params: android.content.Context "+convert(p0)+" android.os.Looper "+convert(p1)+" android.net.wifi.p2p.WifiP2pManager.ChannelListener "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.net.wifi.p2p.WifiP2pManager mthd: initialize retCls: android.net.wifi.p2p.WifiP2pManager.Channel params: android.content.Context "+convert(p0)+" android.os.Looper "+convert(p1)+" android.net.wifi.p2p.WifiP2pManager.ChannelListener "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.net.wifi.p2p.WifiP2pManager.Channel) Instrumentation.callObjectMethod($.class, _this, p0, p1, p2);
    }

    @Redirect("android.nfc.NfcAdapter->disableForegroundDispatch")
    public static void redir_android_nfc_NfcAdapter_disableForegroundDispatch1(Object _this, android.app.Activity p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.NfcAdapter mthd: disableForegroundDispatch retCls: void params: android.app.Activity "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.NfcAdapter mthd: disableForegroundDispatch retCls: void params: android.app.Activity "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0);
    }

    @Redirect("android.nfc.NfcAdapter->disableForegroundNdefPush")
    public static void redir_android_nfc_NfcAdapter_disableForegroundNdefPush1(Object _this, android.app.Activity p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.NfcAdapter mthd: disableForegroundNdefPush retCls: void params: android.app.Activity "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.NfcAdapter mthd: disableForegroundNdefPush retCls: void params: android.app.Activity "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0);
    }

    @Redirect("android.nfc.NfcAdapter->dispatch")
    public static void redir_android_nfc_NfcAdapter_dispatch1(Object _this, android.nfc.Tag p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.NfcAdapter mthd: dispatch retCls: void params: android.nfc.Tag "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.NfcAdapter mthd: dispatch retCls: void params: android.nfc.Tag "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0);
    }

    @Redirect("android.nfc.NfcAdapter->enableForegroundDispatch")
    public static void redir_android_nfc_NfcAdapter_enableForegroundDispatch4(Object _this, android.app.Activity p0, android.app.PendingIntent p1, android.content.IntentFilter[] p2, java.lang.String[][] p3)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.NfcAdapter mthd: enableForegroundDispatch retCls: void params: android.app.Activity "+convert(p0)+" android.app.PendingIntent "+convert(p1)+" android.content.IntentFilter[] "+convert(p2)+" java.lang.String[][] "+convert(p3)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.NfcAdapter mthd: enableForegroundDispatch retCls: void params: android.app.Activity "+convert(p0)+" android.app.PendingIntent "+convert(p1)+" android.content.IntentFilter[] "+convert(p2)+" java.lang.String[][] "+convert(p3)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1, p2, p3);
    }

    @Redirect("android.nfc.NfcAdapter->enableForegroundNdefPush")
    public static void redir_android_nfc_NfcAdapter_enableForegroundNdefPush2(Object _this, android.app.Activity p0, android.nfc.NdefMessage p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.NfcAdapter mthd: enableForegroundNdefPush retCls: void params: android.app.Activity "+convert(p0)+" android.nfc.NdefMessage "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.NfcAdapter mthd: enableForegroundNdefPush retCls: void params: android.app.Activity "+convert(p0)+" android.nfc.NdefMessage "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1);
    }

    @Redirect("android.nfc.NfcAdapter->setBeamPushUris")
    public static void redir_android_nfc_NfcAdapter_setBeamPushUris2(Object _this, android.net.Uri[] p0, android.app.Activity p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.NfcAdapter mthd: setBeamPushUris retCls: void params: android.net.Uri[] "+convert(p0)+" android.app.Activity "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.NfcAdapter mthd: setBeamPushUris retCls: void params: android.net.Uri[] "+convert(p0)+" android.app.Activity "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1);
    }

    @Redirect("android.nfc.NfcAdapter->setBeamPushUrisCallback")
    public static void redir_android_nfc_NfcAdapter_setBeamPushUrisCallback2(Object _this, android.nfc.NfcAdapter.CreateBeamUrisCallback p0, android.app.Activity p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.NfcAdapter mthd: setBeamPushUrisCallback retCls: void params: android.nfc.NfcAdapter.CreateBeamUrisCallback "+convert(p0)+" android.app.Activity "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.NfcAdapter mthd: setBeamPushUrisCallback retCls: void params: android.nfc.NfcAdapter.CreateBeamUrisCallback "+convert(p0)+" android.app.Activity "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1);
    }

    @Redirect("android.nfc.NfcAdapter->setNdefPushMessage")
    public static void redir_android_nfc_NfcAdapter_setNdefPushMessage3(Object _this, android.nfc.NdefMessage p0, android.app.Activity p1, android.app.Activity[] p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.NfcAdapter mthd: setNdefPushMessage retCls: void params: android.nfc.NdefMessage "+convert(p0)+" android.app.Activity "+convert(p1)+" android.app.Activity[] "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.NfcAdapter mthd: setNdefPushMessage retCls: void params: android.nfc.NdefMessage "+convert(p0)+" android.app.Activity "+convert(p1)+" android.app.Activity[] "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1, p2);
    }

    @Redirect("android.nfc.NfcAdapter->setNdefPushMessageCallback")
    public static void redir_android_nfc_NfcAdapter_setNdefPushMessageCallback3(Object _this, android.nfc.NfcAdapter.CreateNdefMessageCallback p0, android.app.Activity p1, android.app.Activity[] p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.NfcAdapter mthd: setNdefPushMessageCallback retCls: void params: android.nfc.NfcAdapter.CreateNdefMessageCallback "+convert(p0)+" android.app.Activity "+convert(p1)+" android.app.Activity[] "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.NfcAdapter mthd: setNdefPushMessageCallback retCls: void params: android.nfc.NfcAdapter.CreateNdefMessageCallback "+convert(p0)+" android.app.Activity "+convert(p1)+" android.app.Activity[] "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1, p2);
    }

    @Redirect("android.nfc.NfcAdapter->setOnNdefPushCompleteCallback")
    public static void redir_android_nfc_NfcAdapter_setOnNdefPushCompleteCallback3(Object _this, android.nfc.NfcAdapter.OnNdefPushCompleteCallback p0, android.app.Activity p1, android.app.Activity[] p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.NfcAdapter mthd: setOnNdefPushCompleteCallback retCls: void params: android.nfc.NfcAdapter.OnNdefPushCompleteCallback "+convert(p0)+" android.app.Activity "+convert(p1)+" android.app.Activity[] "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.NfcAdapter mthd: setOnNdefPushCompleteCallback retCls: void params: android.nfc.NfcAdapter.OnNdefPushCompleteCallback "+convert(p0)+" android.app.Activity "+convert(p1)+" android.app.Activity[] "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1, p2);
    }

    @Redirect("android.nfc.tech.IsoDep->close")
    public static void redir_android_nfc_tech_IsoDep_close0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.IsoDep mthd: close retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.IsoDep mthd: close retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.nfc.tech.IsoDep->connect")
    public static void redir_android_nfc_tech_IsoDep_connect0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.IsoDep mthd: connect retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.IsoDep mthd: connect retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.nfc.tech.IsoDep->getTimeout")
    public static int redir_android_nfc_tech_IsoDep_getTimeout0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.IsoDep mthd: getTimeout retCls: int params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.IsoDep mthd: getTimeout retCls: int params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (int) Instrumentation.callIntMethod($.class, _this);
    }

    @Redirect("android.nfc.tech.IsoDep->reconnect")
    public static void redir_android_nfc_tech_IsoDep_reconnect0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.IsoDep mthd: reconnect retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.IsoDep mthd: reconnect retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.nfc.tech.IsoDep->setTimeout")
    public static void redir_android_nfc_tech_IsoDep_setTimeout1(Object _this, int p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.IsoDep mthd: setTimeout retCls: void params: int "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.IsoDep mthd: setTimeout retCls: void params: int "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0);
    }

    @Redirect("android.nfc.tech.IsoDep->transceive")
    public static byte[] redir_android_nfc_tech_IsoDep_transceive1(Object _this, byte[] p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.IsoDep mthd: transceive retCls: byte[] params: byte[] "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.IsoDep mthd: transceive retCls: byte[] params: byte[] "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (byte[]) Instrumentation.callObjectMethod($.class, _this, p0);
    }

    @Redirect("android.nfc.tech.MifareClassic->authenticate")
    public static boolean redir_android_nfc_tech_MifareClassic_authenticate3(Object _this, int p0, byte[] p1, boolean p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.MifareClassic mthd: authenticate retCls: boolean params: int "+convert(p0)+" byte[] "+convert(p1)+" boolean "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.MifareClassic mthd: authenticate retCls: boolean params: int "+convert(p0)+" byte[] "+convert(p1)+" boolean "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this, p0, p1, p2);
    }

    @Redirect("android.nfc.tech.MifareClassic->authenticateSectorWithKeyA")
    public static boolean redir_android_nfc_tech_MifareClassic_authenticateSectorWithKeyA2(Object _this, int p0, byte[] p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.MifareClassic mthd: authenticateSectorWithKeyA retCls: boolean params: int "+convert(p0)+" byte[] "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.MifareClassic mthd: authenticateSectorWithKeyA retCls: boolean params: int "+convert(p0)+" byte[] "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this, p0, p1);
    }

    @Redirect("android.nfc.tech.MifareClassic->authenticateSectorWithKeyB")
    public static boolean redir_android_nfc_tech_MifareClassic_authenticateSectorWithKeyB2(Object _this, int p0, byte[] p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.MifareClassic mthd: authenticateSectorWithKeyB retCls: boolean params: int "+convert(p0)+" byte[] "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.MifareClassic mthd: authenticateSectorWithKeyB retCls: boolean params: int "+convert(p0)+" byte[] "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this, p0, p1);
    }

    @Redirect("android.nfc.tech.MifareClassic->close")
    public static void redir_android_nfc_tech_MifareClassic_close0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.MifareClassic mthd: close retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.MifareClassic mthd: close retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.nfc.tech.MifareClassic->connect")
    public static void redir_android_nfc_tech_MifareClassic_connect0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.MifareClassic mthd: connect retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.MifareClassic mthd: connect retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.nfc.tech.MifareClassic->decrement")
    public static void redir_android_nfc_tech_MifareClassic_decrement2(Object _this, int p0, int p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.MifareClassic mthd: decrement retCls: void params: int "+convert(p0)+" int "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.MifareClassic mthd: decrement retCls: void params: int "+convert(p0)+" int "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1);
    }

    @Redirect("android.nfc.tech.MifareClassic->getTimeout")
    public static int redir_android_nfc_tech_MifareClassic_getTimeout0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.MifareClassic mthd: getTimeout retCls: int params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.MifareClassic mthd: getTimeout retCls: int params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (int) Instrumentation.callIntMethod($.class, _this);
    }

    @Redirect("android.nfc.tech.MifareClassic->increment")
    public static void redir_android_nfc_tech_MifareClassic_increment2(Object _this, int p0, int p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.MifareClassic mthd: increment retCls: void params: int "+convert(p0)+" int "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.MifareClassic mthd: increment retCls: void params: int "+convert(p0)+" int "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1);
    }

    @Redirect("android.nfc.tech.MifareClassic->readBlock")
    public static byte[] redir_android_nfc_tech_MifareClassic_readBlock1(Object _this, int p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.MifareClassic mthd: readBlock retCls: byte[] params: int "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.MifareClassic mthd: readBlock retCls: byte[] params: int "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (byte[]) Instrumentation.callObjectMethod($.class, _this, p0);
    }

    @Redirect("android.nfc.tech.MifareClassic->reconnect")
    public static void redir_android_nfc_tech_MifareClassic_reconnect0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.MifareClassic mthd: reconnect retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.MifareClassic mthd: reconnect retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.nfc.tech.MifareClassic->restore")
    public static void redir_android_nfc_tech_MifareClassic_restore1(Object _this, int p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.MifareClassic mthd: restore retCls: void params: int "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.MifareClassic mthd: restore retCls: void params: int "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0);
    }

    @Redirect("android.nfc.tech.MifareClassic->setTimeout")
    public static void redir_android_nfc_tech_MifareClassic_setTimeout1(Object _this, int p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.MifareClassic mthd: setTimeout retCls: void params: int "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.MifareClassic mthd: setTimeout retCls: void params: int "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0);
    }

    @Redirect("android.nfc.tech.MifareClassic->transceive")
    public static byte[] redir_android_nfc_tech_MifareClassic_transceive1(Object _this, byte[] p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.MifareClassic mthd: transceive retCls: byte[] params: byte[] "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.MifareClassic mthd: transceive retCls: byte[] params: byte[] "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (byte[]) Instrumentation.callObjectMethod($.class, _this, p0);
    }

    @Redirect("android.nfc.tech.MifareClassic->transfer")
    public static void redir_android_nfc_tech_MifareClassic_transfer1(Object _this, int p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.MifareClassic mthd: transfer retCls: void params: int "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.MifareClassic mthd: transfer retCls: void params: int "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0);
    }

    @Redirect("android.nfc.tech.MifareClassic->writeBlock")
    public static void redir_android_nfc_tech_MifareClassic_writeBlock2(Object _this, int p0, byte[] p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.MifareClassic mthd: writeBlock retCls: void params: int "+convert(p0)+" byte[] "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.MifareClassic mthd: writeBlock retCls: void params: int "+convert(p0)+" byte[] "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1);
    }

    @Redirect("android.nfc.tech.MifareUltralight->close")
    public static void redir_android_nfc_tech_MifareUltralight_close0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.MifareUltralight mthd: close retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.MifareUltralight mthd: close retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.nfc.tech.MifareUltralight->connect")
    public static void redir_android_nfc_tech_MifareUltralight_connect0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.MifareUltralight mthd: connect retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.MifareUltralight mthd: connect retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.nfc.tech.MifareUltralight->getTimeout")
    public static int redir_android_nfc_tech_MifareUltralight_getTimeout0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.MifareUltralight mthd: getTimeout retCls: int params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.MifareUltralight mthd: getTimeout retCls: int params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (int) Instrumentation.callIntMethod($.class, _this);
    }

    @Redirect("android.nfc.tech.MifareUltralight->readPages")
    public static byte[] redir_android_nfc_tech_MifareUltralight_readPages1(Object _this, int p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.MifareUltralight mthd: readPages retCls: byte[] params: int "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.MifareUltralight mthd: readPages retCls: byte[] params: int "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (byte[]) Instrumentation.callObjectMethod($.class, _this, p0);
    }

    @Redirect("android.nfc.tech.MifareUltralight->reconnect")
    public static void redir_android_nfc_tech_MifareUltralight_reconnect0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.MifareUltralight mthd: reconnect retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.MifareUltralight mthd: reconnect retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.nfc.tech.MifareUltralight->setTimeout")
    public static void redir_android_nfc_tech_MifareUltralight_setTimeout1(Object _this, int p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.MifareUltralight mthd: setTimeout retCls: void params: int "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.MifareUltralight mthd: setTimeout retCls: void params: int "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0);
    }

    @Redirect("android.nfc.tech.MifareUltralight->transceive")
    public static byte[] redir_android_nfc_tech_MifareUltralight_transceive1(Object _this, byte[] p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.MifareUltralight mthd: transceive retCls: byte[] params: byte[] "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.MifareUltralight mthd: transceive retCls: byte[] params: byte[] "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (byte[]) Instrumentation.callObjectMethod($.class, _this, p0);
    }

    @Redirect("android.nfc.tech.MifareUltralight->writePage")
    public static void redir_android_nfc_tech_MifareUltralight_writePage2(Object _this, int p0, byte[] p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.MifareUltralight mthd: writePage retCls: void params: int "+convert(p0)+" byte[] "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.MifareUltralight mthd: writePage retCls: void params: int "+convert(p0)+" byte[] "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1);
    }

    @Redirect("android.nfc.tech.Ndef->close")
    public static void redir_android_nfc_tech_Ndef_close0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.Ndef mthd: close retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.Ndef mthd: close retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.nfc.tech.Ndef->connect")
    public static void redir_android_nfc_tech_Ndef_connect0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.Ndef mthd: connect retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.Ndef mthd: connect retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.nfc.tech.Ndef->getNdefMessage")
    public static android.nfc.NdefMessage redir_android_nfc_tech_Ndef_getNdefMessage0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.Ndef mthd: getNdefMessage retCls: android.nfc.NdefMessage params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.Ndef mthd: getNdefMessage retCls: android.nfc.NdefMessage params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (android.nfc.NdefMessage) Instrumentation.callObjectMethod($.class, _this);
    }

    @Redirect("android.nfc.tech.Ndef->makeReadOnly")
    public static boolean redir_android_nfc_tech_Ndef_makeReadOnly0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.Ndef mthd: makeReadOnly retCls: boolean params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.Ndef mthd: makeReadOnly retCls: boolean params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this);
    }

    @Redirect("android.nfc.tech.Ndef->reconnect")
    public static void redir_android_nfc_tech_Ndef_reconnect0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.Ndef mthd: reconnect retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.Ndef mthd: reconnect retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.nfc.tech.Ndef->writeNdefMessage")
    public static void redir_android_nfc_tech_Ndef_writeNdefMessage1(Object _this, android.nfc.NdefMessage p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.Ndef mthd: writeNdefMessage retCls: void params: android.nfc.NdefMessage "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.Ndef mthd: writeNdefMessage retCls: void params: android.nfc.NdefMessage "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0);
    }

    @Redirect("android.nfc.tech.NdefFormatable->close")
    public static void redir_android_nfc_tech_NdefFormatable_close0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.NdefFormatable mthd: close retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.NdefFormatable mthd: close retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.nfc.tech.NdefFormatable->connect")
    public static void redir_android_nfc_tech_NdefFormatable_connect0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.NdefFormatable mthd: connect retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.NdefFormatable mthd: connect retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.nfc.tech.NdefFormatable->format")
    public static void redir_android_nfc_tech_NdefFormatable_format1(Object _this, android.nfc.NdefMessage p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.NdefFormatable mthd: format retCls: void params: android.nfc.NdefMessage "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.NdefFormatable mthd: format retCls: void params: android.nfc.NdefMessage "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0);
    }

    @Redirect("android.nfc.tech.NdefFormatable->format")
    public static void redir_android_nfc_tech_NdefFormatable_format2(Object _this, android.nfc.NdefMessage p0, boolean p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.NdefFormatable mthd: format retCls: void params: android.nfc.NdefMessage "+convert(p0)+" boolean "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.NdefFormatable mthd: format retCls: void params: android.nfc.NdefMessage "+convert(p0)+" boolean "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1);
    }

    @Redirect("android.nfc.tech.NdefFormatable->formatReadOnly")
    public static void redir_android_nfc_tech_NdefFormatable_formatReadOnly1(Object _this, android.nfc.NdefMessage p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.NdefFormatable mthd: formatReadOnly retCls: void params: android.nfc.NdefMessage "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.NdefFormatable mthd: formatReadOnly retCls: void params: android.nfc.NdefMessage "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0);
    }

    @Redirect("android.nfc.tech.NdefFormatable->reconnect")
    public static void redir_android_nfc_tech_NdefFormatable_reconnect0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.NdefFormatable mthd: reconnect retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.NdefFormatable mthd: reconnect retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.nfc.tech.NfcA->close")
    public static void redir_android_nfc_tech_NfcA_close0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.NfcA mthd: close retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.NfcA mthd: close retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.nfc.tech.NfcA->connect")
    public static void redir_android_nfc_tech_NfcA_connect0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.NfcA mthd: connect retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.NfcA mthd: connect retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.nfc.tech.NfcA->getTimeout")
    public static int redir_android_nfc_tech_NfcA_getTimeout0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.NfcA mthd: getTimeout retCls: int params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.NfcA mthd: getTimeout retCls: int params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (int) Instrumentation.callIntMethod($.class, _this);
    }

    @Redirect("android.nfc.tech.NfcA->reconnect")
    public static void redir_android_nfc_tech_NfcA_reconnect0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.NfcA mthd: reconnect retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.NfcA mthd: reconnect retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.nfc.tech.NfcA->setTimeout")
    public static void redir_android_nfc_tech_NfcA_setTimeout1(Object _this, int p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.NfcA mthd: setTimeout retCls: void params: int "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.NfcA mthd: setTimeout retCls: void params: int "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0);
    }

    @Redirect("android.nfc.tech.NfcA->transceive")
    public static byte[] redir_android_nfc_tech_NfcA_transceive1(Object _this, byte[] p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.NfcA mthd: transceive retCls: byte[] params: byte[] "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.NfcA mthd: transceive retCls: byte[] params: byte[] "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (byte[]) Instrumentation.callObjectMethod($.class, _this, p0);
    }

    @Redirect("android.nfc.tech.NfcB->close")
    public static void redir_android_nfc_tech_NfcB_close0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.NfcB mthd: close retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.NfcB mthd: close retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.nfc.tech.NfcB->connect")
    public static void redir_android_nfc_tech_NfcB_connect0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.NfcB mthd: connect retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.NfcB mthd: connect retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.nfc.tech.NfcB->reconnect")
    public static void redir_android_nfc_tech_NfcB_reconnect0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.NfcB mthd: reconnect retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.NfcB mthd: reconnect retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.nfc.tech.NfcB->transceive")
    public static byte[] redir_android_nfc_tech_NfcB_transceive1(Object _this, byte[] p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.NfcB mthd: transceive retCls: byte[] params: byte[] "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.NfcB mthd: transceive retCls: byte[] params: byte[] "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (byte[]) Instrumentation.callObjectMethod($.class, _this, p0);
    }

    @Redirect("android.nfc.tech.NfcF->close")
    public static void redir_android_nfc_tech_NfcF_close0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.NfcF mthd: close retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.NfcF mthd: close retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.nfc.tech.NfcF->connect")
    public static void redir_android_nfc_tech_NfcF_connect0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.NfcF mthd: connect retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.NfcF mthd: connect retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.nfc.tech.NfcF->getTimeout")
    public static int redir_android_nfc_tech_NfcF_getTimeout0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.NfcF mthd: getTimeout retCls: int params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.NfcF mthd: getTimeout retCls: int params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (int) Instrumentation.callIntMethod($.class, _this);
    }

    @Redirect("android.nfc.tech.NfcF->reconnect")
    public static void redir_android_nfc_tech_NfcF_reconnect0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.NfcF mthd: reconnect retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.NfcF mthd: reconnect retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.nfc.tech.NfcF->setTimeout")
    public static void redir_android_nfc_tech_NfcF_setTimeout1(Object _this, int p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.NfcF mthd: setTimeout retCls: void params: int "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.NfcF mthd: setTimeout retCls: void params: int "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0);
    }

    @Redirect("android.nfc.tech.NfcF->transceive")
    public static byte[] redir_android_nfc_tech_NfcF_transceive1(Object _this, byte[] p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.NfcF mthd: transceive retCls: byte[] params: byte[] "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.NfcF mthd: transceive retCls: byte[] params: byte[] "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (byte[]) Instrumentation.callObjectMethod($.class, _this, p0);
    }

    @Redirect("android.nfc.tech.NfcV->close")
    public static void redir_android_nfc_tech_NfcV_close0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.NfcV mthd: close retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.NfcV mthd: close retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.nfc.tech.NfcV->connect")
    public static void redir_android_nfc_tech_NfcV_connect0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.NfcV mthd: connect retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.NfcV mthd: connect retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.nfc.tech.NfcV->reconnect")
    public static void redir_android_nfc_tech_NfcV_reconnect0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.NfcV mthd: reconnect retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.NfcV mthd: reconnect retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.nfc.tech.NfcV->transceive")
    public static byte[] redir_android_nfc_tech_NfcV_transceive1(Object _this, byte[] p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.nfc.tech.NfcV mthd: transceive retCls: byte[] params: byte[] "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.nfc.tech.NfcV mthd: transceive retCls: byte[] params: byte[] "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (byte[]) Instrumentation.callObjectMethod($.class, _this, p0);
    }

    @Redirect("android.os.PowerManager$WakeLock->acquire")
    public static void redir_android_os_PowerManager_WakeLock_acquire0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.os.PowerManager$WakeLock mthd: acquire retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.os.PowerManager$WakeLock mthd: acquire retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.os.PowerManager$WakeLock->acquire")
    public static void redir_android_os_PowerManager_WakeLock_acquire1(Object _this, long p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.os.PowerManager$WakeLock mthd: acquire retCls: void params: long "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.os.PowerManager$WakeLock mthd: acquire retCls: void params: long "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0);
    }

    @Redirect("android.os.PowerManager$WakeLock->finalize")
    public static void redir_android_os_PowerManager_WakeLock_finalize0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.os.PowerManager$WakeLock mthd: finalize retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.os.PowerManager$WakeLock mthd: finalize retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.os.PowerManager$WakeLock->release")
    public static void redir_android_os_PowerManager_WakeLock_release1(Object _this, int p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.os.PowerManager$WakeLock mthd: release retCls: void params: int "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.os.PowerManager$WakeLock mthd: release retCls: void params: int "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0);
    }

    @Redirect("android.provider.Browser->addSearchUrl")
    public static void redir_android_provider_Browser_addSearchUrl2(android.content.ContentResolver p0, java.lang.String p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.Browser mthd: addSearchUrl retCls: void params: android.content.ContentResolver "+convert(p0)+" java.lang.String "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.Browser mthd: addSearchUrl retCls: void params: android.content.ContentResolver "+convert(p0)+" java.lang.String "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callStaticVoidMethod($.class, Object.class, p0, p1);
    }

    @Redirect("android.provider.Browser->canClearHistory")
    public static boolean redir_android_provider_Browser_canClearHistory1(android.content.ContentResolver p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.Browser mthd: canClearHistory retCls: boolean params: android.content.ContentResolver "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.Browser mthd: canClearHistory retCls: boolean params: android.content.ContentResolver "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callStaticBooleanMethod($.class, Object.class, p0);
    }

    @Redirect("android.provider.Browser->clearHistory")
    public static void redir_android_provider_Browser_clearHistory1(android.content.ContentResolver p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.Browser mthd: clearHistory retCls: void params: android.content.ContentResolver "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.Browser mthd: clearHistory retCls: void params: android.content.ContentResolver "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callStaticVoidMethod($.class, Object.class, p0);
    }

    @Redirect("android.provider.Browser->clearSearches")
    public static void redir_android_provider_Browser_clearSearches1(android.content.ContentResolver p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.Browser mthd: clearSearches retCls: void params: android.content.ContentResolver "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.Browser mthd: clearSearches retCls: void params: android.content.ContentResolver "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callStaticVoidMethod($.class, Object.class, p0);
    }

    @Redirect("android.provider.Browser->deleteFromHistory")
    public static void redir_android_provider_Browser_deleteFromHistory2(android.content.ContentResolver p0, java.lang.String p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.Browser mthd: deleteFromHistory retCls: void params: android.content.ContentResolver "+convert(p0)+" java.lang.String "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.Browser mthd: deleteFromHistory retCls: void params: android.content.ContentResolver "+convert(p0)+" java.lang.String "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callStaticVoidMethod($.class, Object.class, p0, p1);
    }

    @Redirect("android.provider.Browser->deleteHistoryTimeFrame")
    public static void redir_android_provider_Browser_deleteHistoryTimeFrame3(android.content.ContentResolver p0, long p1, long p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.Browser mthd: deleteHistoryTimeFrame retCls: void params: android.content.ContentResolver "+convert(p0)+" long "+convert(p1)+" long "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.Browser mthd: deleteHistoryTimeFrame retCls: void params: android.content.ContentResolver "+convert(p0)+" long "+convert(p1)+" long "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callStaticVoidMethod($.class, Object.class, p0, p1, p2);
    }

    @Redirect("android.provider.Browser->getAllBookmarks")
    public static android.database.Cursor redir_android_provider_Browser_getAllBookmarks1(android.content.ContentResolver p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.Browser mthd: getAllBookmarks retCls: android.database.Cursor params: android.content.ContentResolver "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.Browser mthd: getAllBookmarks retCls: android.database.Cursor params: android.content.ContentResolver "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.database.Cursor) Instrumentation.callStaticObjectMethod($.class, Object.class, p0);
    }

    @Redirect("android.provider.Browser->getAllVisitedUrls")
    public static android.database.Cursor redir_android_provider_Browser_getAllVisitedUrls1(android.content.ContentResolver p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.Browser mthd: getAllVisitedUrls retCls: android.database.Cursor params: android.content.ContentResolver "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.Browser mthd: getAllVisitedUrls retCls: android.database.Cursor params: android.content.ContentResolver "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.database.Cursor) Instrumentation.callStaticObjectMethod($.class, Object.class, p0);
    }

    @Redirect("android.provider.Browser->getVisitedHistory")
    public static java.lang.String[] redir_android_provider_Browser_getVisitedHistory1(android.content.ContentResolver p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.Browser mthd: getVisitedHistory retCls: java.lang.String[] params: android.content.ContentResolver "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.Browser mthd: getVisitedHistory retCls: java.lang.String[] params: android.content.ContentResolver "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (java.lang.String[]) Instrumentation.callStaticObjectMethod($.class, Object.class, p0);
    }

    @Redirect("android.provider.Browser->truncateHistory")
    public static void redir_android_provider_Browser_truncateHistory1(android.content.ContentResolver p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.Browser mthd: truncateHistory retCls: void params: android.content.ContentResolver "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.Browser mthd: truncateHistory retCls: void params: android.content.ContentResolver "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callStaticVoidMethod($.class, Object.class, p0);
    }

    @Redirect("android.provider.Browser->updateVisitedHistory")
    public static void redir_android_provider_Browser_updateVisitedHistory3(android.content.ContentResolver p0, java.lang.String p1, boolean p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.Browser mthd: updateVisitedHistory retCls: void params: android.content.ContentResolver "+convert(p0)+" java.lang.String "+convert(p1)+" boolean "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.Browser mthd: updateVisitedHistory retCls: void params: android.content.ContentResolver "+convert(p0)+" java.lang.String "+convert(p1)+" boolean "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callStaticVoidMethod($.class, Object.class, p0, p1, p2);
    }

    @Redirect("android.provider.CalendarContract$Attendees->query")
    public static android.database.Cursor redir_android_provider_CalendarContract_Attendees_query3(android.content.ContentResolver p0, long p1, java.lang.String[] p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.CalendarContract$Attendees mthd: query retCls: android.database.Cursor params: android.content.ContentResolver "+convert(p0)+" long "+convert(p1)+" java.lang.String[] "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.CalendarContract$Attendees mthd: query retCls: android.database.Cursor params: android.content.ContentResolver "+convert(p0)+" long "+convert(p1)+" java.lang.String[] "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.database.Cursor) Instrumentation.callStaticObjectMethod($.class, Object.class, p0, p1, p2);
    }

    @Redirect("android.provider.CalendarContract$CalendarAlerts->insert")
    public static android.net.Uri redir_android_provider_CalendarContract_CalendarAlerts_insert6(android.content.ContentResolver p0, long p1, long p2, long p3, long p4, int p5)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.CalendarContract$CalendarAlerts mthd: insert retCls: android.net.Uri params: android.content.ContentResolver "+convert(p0)+" long "+convert(p1)+" long "+convert(p2)+" long "+convert(p3)+" long "+convert(p4)+" int "+convert(p5)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.CalendarContract$CalendarAlerts mthd: insert retCls: android.net.Uri params: android.content.ContentResolver "+convert(p0)+" long "+convert(p1)+" long "+convert(p2)+" long "+convert(p3)+" long "+convert(p4)+" int "+convert(p5)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.net.Uri) Instrumentation.callStaticObjectMethod($.class, Object.class, p0, p1, p2, p3, p4, p5);
    }

    @Redirect("android.provider.CalendarContract$EventDays->query")
    public static android.database.Cursor redir_android_provider_CalendarContract_EventDays_query4(android.content.ContentResolver p0, int p1, int p2, java.lang.String[] p3)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.CalendarContract$EventDays mthd: query retCls: android.database.Cursor params: android.content.ContentResolver "+convert(p0)+" int "+convert(p1)+" int "+convert(p2)+" java.lang.String[] "+convert(p3)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.CalendarContract$EventDays mthd: query retCls: android.database.Cursor params: android.content.ContentResolver "+convert(p0)+" int "+convert(p1)+" int "+convert(p2)+" java.lang.String[] "+convert(p3)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.database.Cursor) Instrumentation.callStaticObjectMethod($.class, Object.class, p0, p1, p2, p3);
    }

    @Redirect("android.provider.CalendarContract$Instances->query")
    public static android.database.Cursor redir_android_provider_CalendarContract_Instances_query4(android.content.ContentResolver p0, java.lang.String[] p1, long p2, long p3)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.CalendarContract$Instances mthd: query retCls: android.database.Cursor params: android.content.ContentResolver "+convert(p0)+" java.lang.String[] "+convert(p1)+" long "+convert(p2)+" long "+convert(p3)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.CalendarContract$Instances mthd: query retCls: android.database.Cursor params: android.content.ContentResolver "+convert(p0)+" java.lang.String[] "+convert(p1)+" long "+convert(p2)+" long "+convert(p3)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.database.Cursor) Instrumentation.callStaticObjectMethod($.class, Object.class, p0, p1, p2, p3);
    }

    @Redirect("android.provider.CalendarContract$Instances->query")
    public static android.database.Cursor redir_android_provider_CalendarContract_Instances_query5(android.content.ContentResolver p0, java.lang.String[] p1, long p2, long p3, java.lang.String p4)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.CalendarContract$Instances mthd: query retCls: android.database.Cursor params: android.content.ContentResolver "+convert(p0)+" java.lang.String[] "+convert(p1)+" long "+convert(p2)+" long "+convert(p3)+" java.lang.String "+convert(p4)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.CalendarContract$Instances mthd: query retCls: android.database.Cursor params: android.content.ContentResolver "+convert(p0)+" java.lang.String[] "+convert(p1)+" long "+convert(p2)+" long "+convert(p3)+" java.lang.String "+convert(p4)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.database.Cursor) Instrumentation.callStaticObjectMethod($.class, Object.class, p0, p1, p2, p3, p4);
    }

    @Redirect("android.provider.CalendarContract$Reminders->query")
    public static android.database.Cursor redir_android_provider_CalendarContract_Reminders_query3(android.content.ContentResolver p0, long p1, java.lang.String[] p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.CalendarContract$Reminders mthd: query retCls: android.database.Cursor params: android.content.ContentResolver "+convert(p0)+" long "+convert(p1)+" java.lang.String[] "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.CalendarContract$Reminders mthd: query retCls: android.database.Cursor params: android.content.ContentResolver "+convert(p0)+" long "+convert(p1)+" java.lang.String[] "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.database.Cursor) Instrumentation.callStaticObjectMethod($.class, Object.class, p0, p1, p2);
    }

    @Redirect("android.provider.CallLog$Calls->getLastOutgoingCall")
    public static java.lang.String redir_android_provider_CallLog_Calls_getLastOutgoingCall1(android.content.Context p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.CallLog$Calls mthd: getLastOutgoingCall retCls: java.lang.String params: android.content.Context "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.CallLog$Calls mthd: getLastOutgoingCall retCls: java.lang.String params: android.content.Context "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (java.lang.String) Instrumentation.callStaticObjectMethod($.class, Object.class, p0);
    }

    @Redirect("android.provider.Contacts$ContactMethods->addPostalLocation")
    public static void redir_android_provider_Contacts_ContactMethods_addPostalLocation4(Object _this, android.content.Context p0, long p1, double p2, double p3)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.Contacts$ContactMethods mthd: addPostalLocation retCls: void params: android.content.Context "+convert(p0)+" long "+convert(p1)+" double "+convert(p2)+" double "+convert(p3)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.Contacts$ContactMethods mthd: addPostalLocation retCls: void params: android.content.Context "+convert(p0)+" long "+convert(p1)+" double "+convert(p2)+" double "+convert(p3)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1, p2, p3);
    }

    @Redirect("android.provider.Contacts$People->addToGroup")
    public static android.net.Uri redir_android_provider_Contacts_People_addToGroup3(android.content.ContentResolver p0, long p1, java.lang.String p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.Contacts$People mthd: addToGroup retCls: android.net.Uri params: android.content.ContentResolver "+convert(p0)+" long "+convert(p1)+" java.lang.String "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.Contacts$People mthd: addToGroup retCls: android.net.Uri params: android.content.ContentResolver "+convert(p0)+" long "+convert(p1)+" java.lang.String "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.net.Uri) Instrumentation.callStaticObjectMethod($.class, Object.class, p0, p1, p2);
    }

    @Redirect("android.provider.Contacts$People->addToGroup")
    public static android.net.Uri redir_android_provider_Contacts_People_addToGroup3(android.content.ContentResolver p0, long p1, long p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.Contacts$People mthd: addToGroup retCls: android.net.Uri params: android.content.ContentResolver "+convert(p0)+" long "+convert(p1)+" long "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.Contacts$People mthd: addToGroup retCls: android.net.Uri params: android.content.ContentResolver "+convert(p0)+" long "+convert(p1)+" long "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.net.Uri) Instrumentation.callStaticObjectMethod($.class, Object.class, p0, p1, p2);
    }

    @Redirect("android.provider.Contacts$People->addToMyContactsGroup")
    public static android.net.Uri redir_android_provider_Contacts_People_addToMyContactsGroup2(android.content.ContentResolver p0, long p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.Contacts$People mthd: addToMyContactsGroup retCls: android.net.Uri params: android.content.ContentResolver "+convert(p0)+" long "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.Contacts$People mthd: addToMyContactsGroup retCls: android.net.Uri params: android.content.ContentResolver "+convert(p0)+" long "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.net.Uri) Instrumentation.callStaticObjectMethod($.class, Object.class, p0, p1);
    }

    @Redirect("android.provider.Contacts$People->createPersonInMyContactsGroup")
    public static android.net.Uri redir_android_provider_Contacts_People_createPersonInMyContactsGroup2(android.content.ContentResolver p0, android.content.ContentValues p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.Contacts$People mthd: createPersonInMyContactsGroup retCls: android.net.Uri params: android.content.ContentResolver "+convert(p0)+" android.content.ContentValues "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.Contacts$People mthd: createPersonInMyContactsGroup retCls: android.net.Uri params: android.content.ContentResolver "+convert(p0)+" android.content.ContentValues "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.net.Uri) Instrumentation.callStaticObjectMethod($.class, Object.class, p0, p1);
    }

    @Redirect("android.provider.Contacts$People->markAsContacted")
    public static void redir_android_provider_Contacts_People_markAsContacted2(android.content.ContentResolver p0, long p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.Contacts$People mthd: markAsContacted retCls: void params: android.content.ContentResolver "+convert(p0)+" long "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.Contacts$People mthd: markAsContacted retCls: void params: android.content.ContentResolver "+convert(p0)+" long "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callStaticVoidMethod($.class, Object.class, p0, p1);
    }

    @Redirect("android.provider.Contacts$People->queryGroups")
    public static android.database.Cursor redir_android_provider_Contacts_People_queryGroups2(android.content.ContentResolver p0, long p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.Contacts$People mthd: queryGroups retCls: android.database.Cursor params: android.content.ContentResolver "+convert(p0)+" long "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.Contacts$People mthd: queryGroups retCls: android.database.Cursor params: android.content.ContentResolver "+convert(p0)+" long "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.database.Cursor) Instrumentation.callStaticObjectMethod($.class, Object.class, p0, p1);
    }

    @Redirect("android.provider.Contacts$Settings->getSetting")
    public static java.lang.String redir_android_provider_Contacts_Settings_getSetting3(android.content.ContentResolver p0, java.lang.String p1, java.lang.String p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.Contacts$Settings mthd: getSetting retCls: java.lang.String params: android.content.ContentResolver "+convert(p0)+" java.lang.String "+convert(p1)+" java.lang.String "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.Contacts$Settings mthd: getSetting retCls: java.lang.String params: android.content.ContentResolver "+convert(p0)+" java.lang.String "+convert(p1)+" java.lang.String "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (java.lang.String) Instrumentation.callStaticObjectMethod($.class, Object.class, p0, p1, p2);
    }

    @Redirect("android.provider.Contacts$Settings->setSetting")
    public static void redir_android_provider_Contacts_Settings_setSetting4(android.content.ContentResolver p0, java.lang.String p1, java.lang.String p2, java.lang.String p3)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.Contacts$Settings mthd: setSetting retCls: void params: android.content.ContentResolver "+convert(p0)+" java.lang.String "+convert(p1)+" java.lang.String "+convert(p2)+" java.lang.String "+convert(p3)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.Contacts$Settings mthd: setSetting retCls: void params: android.content.ContentResolver "+convert(p0)+" java.lang.String "+convert(p1)+" java.lang.String "+convert(p2)+" java.lang.String "+convert(p3)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callStaticVoidMethod($.class, Object.class, p0, p1, p2, p3);
    }

    @Redirect("android.provider.ContactsContract$Contacts->getLookupUri")
    public static android.net.Uri redir_android_provider_ContactsContract_Contacts_getLookupUri2(android.content.ContentResolver p0, android.net.Uri p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.ContactsContract$Contacts mthd: getLookupUri retCls: android.net.Uri params: android.content.ContentResolver "+convert(p0)+" android.net.Uri "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.ContactsContract$Contacts mthd: getLookupUri retCls: android.net.Uri params: android.content.ContentResolver "+convert(p0)+" android.net.Uri "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.net.Uri) Instrumentation.callStaticObjectMethod($.class, Object.class, p0, p1);
    }

    @Redirect("android.provider.ContactsContract$Contacts->getLookupUri")
    public static android.net.Uri redir_android_provider_ContactsContract_Contacts_getLookupUri2(long p0, java.lang.String p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.ContactsContract$Contacts mthd: getLookupUri retCls: android.net.Uri params: long "+convert(p0)+" java.lang.String "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.ContactsContract$Contacts mthd: getLookupUri retCls: android.net.Uri params: long "+convert(p0)+" java.lang.String "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.net.Uri) Instrumentation.callStaticObjectMethod($.class, Object.class, p0, p1);
    }

    @Redirect("android.provider.ContactsContract$Contacts->markAsContacted")
    public static void redir_android_provider_ContactsContract_Contacts_markAsContacted2(android.content.ContentResolver p0, long p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.ContactsContract$Contacts mthd: markAsContacted retCls: void params: android.content.ContentResolver "+convert(p0)+" long "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.ContactsContract$Contacts mthd: markAsContacted retCls: void params: android.content.ContentResolver "+convert(p0)+" long "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callStaticVoidMethod($.class, Object.class, p0, p1);
    }

    @Redirect("android.provider.ContactsContract$Data->getContactLookupUri")
    public static android.net.Uri redir_android_provider_ContactsContract_Data_getContactLookupUri2(android.content.ContentResolver p0, android.net.Uri p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.ContactsContract$Data mthd: getContactLookupUri retCls: android.net.Uri params: android.content.ContentResolver "+convert(p0)+" android.net.Uri "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.ContactsContract$Data mthd: getContactLookupUri retCls: android.net.Uri params: android.content.ContentResolver "+convert(p0)+" android.net.Uri "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.net.Uri) Instrumentation.callStaticObjectMethod($.class, Object.class, p0, p1);
    }

    @Redirect("android.provider.ContactsContract$Directory->notifyDirectoryChange")
    public static void redir_android_provider_ContactsContract_Directory_notifyDirectoryChange1(android.content.ContentResolver p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.ContactsContract$Directory mthd: notifyDirectoryChange retCls: void params: android.content.ContentResolver "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.ContactsContract$Directory mthd: notifyDirectoryChange retCls: void params: android.content.ContentResolver "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callStaticVoidMethod($.class, Object.class, p0);
    }

    @Redirect("android.provider.ContactsContract$ProfileSyncState->get")
    public static byte[] redir_android_provider_ContactsContract_ProfileSyncState_get2(android.content.ContentProviderClient p0, android.accounts.Account p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.ContactsContract$ProfileSyncState mthd: get retCls: byte[] params: android.content.ContentProviderClient "+convert(p0)+" android.accounts.Account "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.ContactsContract$ProfileSyncState mthd: get retCls: byte[] params: android.content.ContentProviderClient "+convert(p0)+" android.accounts.Account "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (byte[]) Instrumentation.callStaticObjectMethod($.class, Object.class, p0, p1);
    }

    @Redirect("android.provider.ContactsContract$ProfileSyncState->getWithUri")
    public static android.util.Pair redir_android_provider_ContactsContract_ProfileSyncState_getWithUri2(android.content.ContentProviderClient p0, android.accounts.Account p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.ContactsContract$ProfileSyncState mthd: getWithUri retCls: android.util.Pair params: android.content.ContentProviderClient "+convert(p0)+" android.accounts.Account "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.ContactsContract$ProfileSyncState mthd: getWithUri retCls: android.util.Pair params: android.content.ContentProviderClient "+convert(p0)+" android.accounts.Account "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.util.Pair) Instrumentation.callStaticObjectMethod($.class, Object.class, p0, p1);
    }

    @Redirect("android.provider.ContactsContract$ProfileSyncState->newSetOperation")
    public static android.content.ContentProviderOperation redir_android_provider_ContactsContract_ProfileSyncState_newSetOperation2(android.accounts.Account p0, byte[] p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.ContactsContract$ProfileSyncState mthd: newSetOperation retCls: android.content.ContentProviderOperation params: android.accounts.Account "+convert(p0)+" byte[] "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.ContactsContract$ProfileSyncState mthd: newSetOperation retCls: android.content.ContentProviderOperation params: android.accounts.Account "+convert(p0)+" byte[] "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.content.ContentProviderOperation) Instrumentation.callStaticObjectMethod($.class, Object.class, p0, p1);
    }

    @Redirect("android.provider.ContactsContract$ProfileSyncState->set")
    public static void redir_android_provider_ContactsContract_ProfileSyncState_set3(android.content.ContentProviderClient p0, android.accounts.Account p1, byte[] p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.ContactsContract$ProfileSyncState mthd: set retCls: void params: android.content.ContentProviderClient "+convert(p0)+" android.accounts.Account "+convert(p1)+" byte[] "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.ContactsContract$ProfileSyncState mthd: set retCls: void params: android.content.ContentProviderClient "+convert(p0)+" android.accounts.Account "+convert(p1)+" byte[] "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callStaticVoidMethod($.class, Object.class, p0, p1, p2);
    }

    @Redirect("android.provider.ContactsContract$RawContacts->getContactLookupUri")
    public static android.net.Uri redir_android_provider_ContactsContract_RawContacts_getContactLookupUri2(android.content.ContentResolver p0, android.net.Uri p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.ContactsContract$RawContacts mthd: getContactLookupUri retCls: android.net.Uri params: android.content.ContentResolver "+convert(p0)+" android.net.Uri "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.ContactsContract$RawContacts mthd: getContactLookupUri retCls: android.net.Uri params: android.content.ContentResolver "+convert(p0)+" android.net.Uri "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.net.Uri) Instrumentation.callStaticObjectMethod($.class, Object.class, p0, p1);
    }

    @Redirect("android.provider.ContactsContract$SyncState->get")
    public static byte[] redir_android_provider_ContactsContract_SyncState_get2(android.content.ContentProviderClient p0, android.accounts.Account p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.ContactsContract$SyncState mthd: get retCls: byte[] params: android.content.ContentProviderClient "+convert(p0)+" android.accounts.Account "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.ContactsContract$SyncState mthd: get retCls: byte[] params: android.content.ContentProviderClient "+convert(p0)+" android.accounts.Account "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (byte[]) Instrumentation.callStaticObjectMethod($.class, Object.class, p0, p1);
    }

    @Redirect("android.provider.ContactsContract$SyncState->getWithUri")
    public static android.util.Pair redir_android_provider_ContactsContract_SyncState_getWithUri2(android.content.ContentProviderClient p0, android.accounts.Account p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.ContactsContract$SyncState mthd: getWithUri retCls: android.util.Pair params: android.content.ContentProviderClient "+convert(p0)+" android.accounts.Account "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.ContactsContract$SyncState mthd: getWithUri retCls: android.util.Pair params: android.content.ContentProviderClient "+convert(p0)+" android.accounts.Account "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.util.Pair) Instrumentation.callStaticObjectMethod($.class, Object.class, p0, p1);
    }

    @Redirect("android.provider.ContactsContract$SyncState->newSetOperation")
    public static android.content.ContentProviderOperation redir_android_provider_ContactsContract_SyncState_newSetOperation2(android.accounts.Account p0, byte[] p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.ContactsContract$SyncState mthd: newSetOperation retCls: android.content.ContentProviderOperation params: android.accounts.Account "+convert(p0)+" byte[] "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.ContactsContract$SyncState mthd: newSetOperation retCls: android.content.ContentProviderOperation params: android.accounts.Account "+convert(p0)+" byte[] "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.content.ContentProviderOperation) Instrumentation.callStaticObjectMethod($.class, Object.class, p0, p1);
    }

    @Redirect("android.provider.ContactsContract$SyncState->set")
    public static void redir_android_provider_ContactsContract_SyncState_set3(android.content.ContentProviderClient p0, android.accounts.Account p1, byte[] p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.ContactsContract$SyncState mthd: set retCls: void params: android.content.ContentProviderClient "+convert(p0)+" android.accounts.Account "+convert(p1)+" byte[] "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.ContactsContract$SyncState mthd: set retCls: void params: android.content.ContentProviderClient "+convert(p0)+" android.accounts.Account "+convert(p1)+" byte[] "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callStaticVoidMethod($.class, Object.class, p0, p1, p2);
    }

    @Redirect("android.provider.Settings$Secure->getUriFor")
    public static android.net.Uri redir_android_provider_Settings_Secure_getUriFor1(java.lang.String p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.Settings$Secure mthd: getUriFor retCls: android.net.Uri params: java.lang.String "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.Settings$Secure mthd: getUriFor retCls: android.net.Uri params: java.lang.String "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.net.Uri) Instrumentation.callStaticObjectMethod($.class, Object.class, p0);
    }

    @Redirect("android.provider.Settings$Secure->putFloat")
    public static boolean redir_android_provider_Settings_Secure_putFloat3(android.content.ContentResolver p0, java.lang.String p1, float p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.Settings$Secure mthd: putFloat retCls: boolean params: android.content.ContentResolver "+convert(p0)+" java.lang.String "+convert(p1)+" float "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.Settings$Secure mthd: putFloat retCls: boolean params: android.content.ContentResolver "+convert(p0)+" java.lang.String "+convert(p1)+" float "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callStaticBooleanMethod($.class, Object.class, p0, p1, p2);
    }

    @Redirect("android.provider.Settings$Secure->putInt")
    public static boolean redir_android_provider_Settings_Secure_putInt3(android.content.ContentResolver p0, java.lang.String p1, int p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.Settings$Secure mthd: putInt retCls: boolean params: android.content.ContentResolver "+convert(p0)+" java.lang.String "+convert(p1)+" int "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.Settings$Secure mthd: putInt retCls: boolean params: android.content.ContentResolver "+convert(p0)+" java.lang.String "+convert(p1)+" int "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callStaticBooleanMethod($.class, Object.class, p0, p1, p2);
    }

    @Redirect("android.provider.Settings$Secure->putLong")
    public static boolean redir_android_provider_Settings_Secure_putLong3(android.content.ContentResolver p0, java.lang.String p1, long p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.Settings$Secure mthd: putLong retCls: boolean params: android.content.ContentResolver "+convert(p0)+" java.lang.String "+convert(p1)+" long "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.Settings$Secure mthd: putLong retCls: boolean params: android.content.ContentResolver "+convert(p0)+" java.lang.String "+convert(p1)+" long "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callStaticBooleanMethod($.class, Object.class, p0, p1, p2);
    }

    @Redirect("android.provider.Settings$Secure->putString")
    public static boolean redir_android_provider_Settings_Secure_putString3(android.content.ContentResolver p0, java.lang.String p1, java.lang.String p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.Settings$Secure mthd: putString retCls: boolean params: android.content.ContentResolver "+convert(p0)+" java.lang.String "+convert(p1)+" java.lang.String "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.Settings$Secure mthd: putString retCls: boolean params: android.content.ContentResolver "+convert(p0)+" java.lang.String "+convert(p1)+" java.lang.String "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callStaticBooleanMethod($.class, Object.class, p0, p1, p2);
    }

    @Redirect("android.provider.Settings$Secure->setLocationProviderEnabled")
    public static void redir_android_provider_Settings_Secure_setLocationProviderEnabled3(android.content.ContentResolver p0, java.lang.String p1, boolean p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.Settings$Secure mthd: setLocationProviderEnabled retCls: void params: android.content.ContentResolver "+convert(p0)+" java.lang.String "+convert(p1)+" boolean "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.Settings$Secure mthd: setLocationProviderEnabled retCls: void params: android.content.ContentResolver "+convert(p0)+" java.lang.String "+convert(p1)+" boolean "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callStaticVoidMethod($.class, Object.class, p0, p1, p2);
    }

    @Redirect("android.provider.Settings$System->getUriFor")
    public static android.net.Uri redir_android_provider_Settings_System_getUriFor1(java.lang.String p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.Settings$System mthd: getUriFor retCls: android.net.Uri params: java.lang.String "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.Settings$System mthd: getUriFor retCls: android.net.Uri params: java.lang.String "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.net.Uri) Instrumentation.callStaticObjectMethod($.class, Object.class, p0);
    }

    @Redirect("android.provider.Settings$System->putConfiguration")
    public static boolean redir_android_provider_Settings_System_putConfiguration2(android.content.ContentResolver p0, android.content.res.Configuration p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.Settings$System mthd: putConfiguration retCls: boolean params: android.content.ContentResolver "+convert(p0)+" android.content.res.Configuration "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.Settings$System mthd: putConfiguration retCls: boolean params: android.content.ContentResolver "+convert(p0)+" android.content.res.Configuration "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callStaticBooleanMethod($.class, Object.class, p0, p1);
    }

    @Redirect("android.provider.Settings$System->putFloat")
    public static boolean redir_android_provider_Settings_System_putFloat3(android.content.ContentResolver p0, java.lang.String p1, float p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.Settings$System mthd: putFloat retCls: boolean params: android.content.ContentResolver "+convert(p0)+" java.lang.String "+convert(p1)+" float "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.Settings$System mthd: putFloat retCls: boolean params: android.content.ContentResolver "+convert(p0)+" java.lang.String "+convert(p1)+" float "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callStaticBooleanMethod($.class, Object.class, p0, p1, p2);
    }

    @Redirect("android.provider.Settings$System->putInt")
    public static boolean redir_android_provider_Settings_System_putInt3(android.content.ContentResolver p0, java.lang.String p1, int p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.Settings$System mthd: putInt retCls: boolean params: android.content.ContentResolver "+convert(p0)+" java.lang.String "+convert(p1)+" int "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.Settings$System mthd: putInt retCls: boolean params: android.content.ContentResolver "+convert(p0)+" java.lang.String "+convert(p1)+" int "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callStaticBooleanMethod($.class, Object.class, p0, p1, p2);
    }

    @Redirect("android.provider.Settings$System->putLong")
    public static boolean redir_android_provider_Settings_System_putLong3(android.content.ContentResolver p0, java.lang.String p1, long p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.Settings$System mthd: putLong retCls: boolean params: android.content.ContentResolver "+convert(p0)+" java.lang.String "+convert(p1)+" long "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.Settings$System mthd: putLong retCls: boolean params: android.content.ContentResolver "+convert(p0)+" java.lang.String "+convert(p1)+" long "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callStaticBooleanMethod($.class, Object.class, p0, p1, p2);
    }

    @Redirect("android.provider.Settings$System->putString")
    public static boolean redir_android_provider_Settings_System_putString3(android.content.ContentResolver p0, java.lang.String p1, java.lang.String p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.Settings$System mthd: putString retCls: boolean params: android.content.ContentResolver "+convert(p0)+" java.lang.String "+convert(p1)+" java.lang.String "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.Settings$System mthd: putString retCls: boolean params: android.content.ContentResolver "+convert(p0)+" java.lang.String "+convert(p1)+" java.lang.String "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callStaticBooleanMethod($.class, Object.class, p0, p1, p2);
    }

    @Redirect("android.provider.Settings$System->setShowGTalkServiceStatus")
    public static void redir_android_provider_Settings_System_setShowGTalkServiceStatus2(android.content.ContentResolver p0, boolean p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.Settings$System mthd: setShowGTalkServiceStatus retCls: void params: android.content.ContentResolver "+convert(p0)+" boolean "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.Settings$System mthd: setShowGTalkServiceStatus retCls: void params: android.content.ContentResolver "+convert(p0)+" boolean "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callStaticVoidMethod($.class, Object.class, p0, p1);
    }

    @Redirect("android.provider.UserDictionary$Words->addWord")
    public static void redir_android_provider_UserDictionary_Words_addWord4(android.content.Context p0, java.lang.String p1, int p2, int p3)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.UserDictionary$Words mthd: addWord retCls: void params: android.content.Context "+convert(p0)+" java.lang.String "+convert(p1)+" int "+convert(p2)+" int "+convert(p3)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.UserDictionary$Words mthd: addWord retCls: void params: android.content.Context "+convert(p0)+" java.lang.String "+convert(p1)+" int "+convert(p2)+" int "+convert(p3)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callStaticVoidMethod($.class, Object.class, p0, p1, p2, p3);
    }

    @Redirect("android.provider.UserDictionary$Words->addWord")
    public static void redir_android_provider_UserDictionary_Words_addWord5(android.content.Context p0, java.lang.String p1, int p2, java.lang.String p3, java.util.Locale p4)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.UserDictionary$Words mthd: addWord retCls: void params: android.content.Context "+convert(p0)+" java.lang.String "+convert(p1)+" int "+convert(p2)+" java.lang.String "+convert(p3)+" java.util.Locale "+convert(p4)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.UserDictionary$Words mthd: addWord retCls: void params: android.content.Context "+convert(p0)+" java.lang.String "+convert(p1)+" int "+convert(p2)+" java.lang.String "+convert(p3)+" java.util.Locale "+convert(p4)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callStaticVoidMethod($.class, Object.class, p0, p1, p2, p3, p4);
    }

    @Redirect("android.provider.VoicemailContract$Status->buildSourceUri")
    public static android.net.Uri redir_android_provider_VoicemailContract_Status_buildSourceUri1(java.lang.String p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.VoicemailContract$Status mthd: buildSourceUri retCls: android.net.Uri params: java.lang.String "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.VoicemailContract$Status mthd: buildSourceUri retCls: android.net.Uri params: java.lang.String "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.net.Uri) Instrumentation.callStaticObjectMethod($.class, Object.class, p0);
    }

    @Redirect("android.provider.VoicemailContract$Voicemails->buildSourceUri")
    public static android.net.Uri redir_android_provider_VoicemailContract_Voicemails_buildSourceUri1(java.lang.String p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.provider.VoicemailContract$Voicemails mthd: buildSourceUri retCls: android.net.Uri params: java.lang.String "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.provider.VoicemailContract$Voicemails mthd: buildSourceUri retCls: android.net.Uri params: java.lang.String "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.net.Uri) Instrumentation.callStaticObjectMethod($.class, Object.class, p0);
    }

    @Redirect("android.speech.SpeechRecognizer->cancel")
    public static void redir_android_speech_SpeechRecognizer_cancel0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.speech.SpeechRecognizer mthd: cancel retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.speech.SpeechRecognizer mthd: cancel retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.speech.SpeechRecognizer->setRecognitionListener")
    public static void redir_android_speech_SpeechRecognizer_setRecognitionListener1(Object _this, android.speech.RecognitionListener p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.speech.SpeechRecognizer mthd: setRecognitionListener retCls: void params: android.speech.RecognitionListener "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.speech.SpeechRecognizer mthd: setRecognitionListener retCls: void params: android.speech.RecognitionListener "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0);
    }

    @Redirect("android.speech.SpeechRecognizer->startListening")
    public static void redir_android_speech_SpeechRecognizer_startListening1(Object _this, android.content.Intent p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.speech.SpeechRecognizer mthd: startListening retCls: void params: android.content.Intent "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.speech.SpeechRecognizer mthd: startListening retCls: void params: android.content.Intent "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0);
    }

    @Redirect("android.speech.SpeechRecognizer->stopListening")
    public static void redir_android_speech_SpeechRecognizer_stopListening0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.speech.SpeechRecognizer mthd: stopListening retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.speech.SpeechRecognizer mthd: stopListening retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.telephony.TelephonyManager->getCellLocation")
    public static android.telephony.CellLocation redir_android_telephony_TelephonyManager_getCellLocation0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.telephony.TelephonyManager mthd: getCellLocation retCls: android.telephony.CellLocation params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.telephony.TelephonyManager mthd: getCellLocation retCls: android.telephony.CellLocation params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (android.telephony.CellLocation) Instrumentation.callObjectMethod($.class, _this);
    }

    @Redirect("android.telephony.TelephonyManager->getDeviceId")
    public static java.lang.String redir_android_telephony_TelephonyManager_getDeviceId0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.telephony.TelephonyManager mthd: getDeviceId retCls: java.lang.String params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.telephony.TelephonyManager mthd: getDeviceId retCls: java.lang.String params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (java.lang.String) Instrumentation.callObjectMethod($.class, _this);
    }

    @Redirect("android.telephony.TelephonyManager->getDeviceSoftwareVersion")
    public static java.lang.String redir_android_telephony_TelephonyManager_getDeviceSoftwareVersion0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.telephony.TelephonyManager mthd: getDeviceSoftwareVersion retCls: java.lang.String params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.telephony.TelephonyManager mthd: getDeviceSoftwareVersion retCls: java.lang.String params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (java.lang.String) Instrumentation.callObjectMethod($.class, _this);
    }

    @Redirect("android.telephony.TelephonyManager->getLine1Number")
    public static java.lang.String redir_android_telephony_TelephonyManager_getLine1Number0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.telephony.TelephonyManager mthd: getLine1Number retCls: java.lang.String params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.telephony.TelephonyManager mthd: getLine1Number retCls: java.lang.String params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (java.lang.String) Instrumentation.callObjectMethod($.class, _this);
    }

    @Redirect("android.telephony.TelephonyManager->getNeighboringCellInfo")
    public static java.util.List redir_android_telephony_TelephonyManager_getNeighboringCellInfo0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.telephony.TelephonyManager mthd: getNeighboringCellInfo retCls: java.util.List params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.telephony.TelephonyManager mthd: getNeighboringCellInfo retCls: java.util.List params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (java.util.List) Instrumentation.callObjectMethod($.class, _this);
    }

    @Redirect("android.telephony.TelephonyManager->getSimSerialNumber")
    public static java.lang.String redir_android_telephony_TelephonyManager_getSimSerialNumber0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.telephony.TelephonyManager mthd: getSimSerialNumber retCls: java.lang.String params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.telephony.TelephonyManager mthd: getSimSerialNumber retCls: java.lang.String params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (java.lang.String) Instrumentation.callObjectMethod($.class, _this);
    }

    @Redirect("android.telephony.TelephonyManager->getSubscriberId")
    public static java.lang.String redir_android_telephony_TelephonyManager_getSubscriberId0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.telephony.TelephonyManager mthd: getSubscriberId retCls: java.lang.String params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.telephony.TelephonyManager mthd: getSubscriberId retCls: java.lang.String params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (java.lang.String) Instrumentation.callObjectMethod($.class, _this);
    }

    @Redirect("android.telephony.TelephonyManager->getVoiceMailAlphaTag")
    public static java.lang.String redir_android_telephony_TelephonyManager_getVoiceMailAlphaTag0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.telephony.TelephonyManager mthd: getVoiceMailAlphaTag retCls: java.lang.String params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.telephony.TelephonyManager mthd: getVoiceMailAlphaTag retCls: java.lang.String params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (java.lang.String) Instrumentation.callObjectMethod($.class, _this);
    }

    @Redirect("android.telephony.TelephonyManager->getVoiceMailNumber")
    public static java.lang.String redir_android_telephony_TelephonyManager_getVoiceMailNumber0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.telephony.TelephonyManager mthd: getVoiceMailNumber retCls: java.lang.String params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.telephony.TelephonyManager mthd: getVoiceMailNumber retCls: java.lang.String params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (java.lang.String) Instrumentation.callObjectMethod($.class, _this);
    }

    @Redirect("android.telephony.TelephonyManager->listen")
    public static void redir_android_telephony_TelephonyManager_listen2(Object _this, android.telephony.PhoneStateListener p0, int p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.telephony.TelephonyManager mthd: listen retCls: void params: android.telephony.PhoneStateListener "+convert(p0)+" int "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.telephony.TelephonyManager mthd: listen retCls: void params: android.telephony.PhoneStateListener "+convert(p0)+" int "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1);
    }

    @Redirect("android.view.View->startDrag")
    public static boolean redir_android_view_View_startDrag4(Object _this, android.content.ClipData p0, android.view.View.DragShadowBuilder p1, java.lang.Object p2, int p3)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.view.View mthd: startDrag retCls: boolean params: android.content.ClipData "+convert(p0)+" android.view.View.DragShadowBuilder "+convert(p1)+" java.lang.Object "+convert(p2)+" int "+convert(p3)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.view.View mthd: startDrag retCls: boolean params: android.content.ClipData "+convert(p0)+" android.view.View.DragShadowBuilder "+convert(p1)+" java.lang.Object "+convert(p2)+" int "+convert(p3)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this, p0, p1, p2, p3);
    }

    @Redirect("android.webkit.WebViewFragment->onCreateView")
    public static android.view.View redir_android_webkit_WebViewFragment_onCreateView3(Object _this, android.view.LayoutInflater p0, android.view.ViewGroup p1, android.os.Bundle p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.webkit.WebViewFragment mthd: onCreateView retCls: android.view.View params: android.view.LayoutInflater "+convert(p0)+" android.view.ViewGroup "+convert(p1)+" android.os.Bundle "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.webkit.WebViewFragment mthd: onCreateView retCls: android.view.View params: android.view.LayoutInflater "+convert(p0)+" android.view.ViewGroup "+convert(p1)+" android.os.Bundle "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (android.view.View) Instrumentation.callObjectMethod($.class, _this, p0, p1, p2);
    }

    @Redirect("android.widget.QuickContactBadge->assignContactFromEmail")
    public static void redir_android_widget_QuickContactBadge_assignContactFromEmail2(Object _this, java.lang.String p0, boolean p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.widget.QuickContactBadge mthd: assignContactFromEmail retCls: void params: java.lang.String "+convert(p0)+" boolean "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.widget.QuickContactBadge mthd: assignContactFromEmail retCls: void params: java.lang.String "+convert(p0)+" boolean "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1);
    }

    @Redirect("android.widget.QuickContactBadge->assignContactFromPhone")
    public static void redir_android_widget_QuickContactBadge_assignContactFromPhone2(Object _this, java.lang.String p0, boolean p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.widget.QuickContactBadge mthd: assignContactFromPhone retCls: void params: java.lang.String "+convert(p0)+" boolean "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.widget.QuickContactBadge mthd: assignContactFromPhone retCls: void params: java.lang.String "+convert(p0)+" boolean "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1);
    }

    @Redirect("android.widget.QuickContactBadge->onClick")
    public static void redir_android_widget_QuickContactBadge_onClick1(Object _this, android.view.View p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.widget.QuickContactBadge mthd: onClick retCls: void params: android.view.View "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.widget.QuickContactBadge mthd: onClick retCls: void params: android.view.View "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0);
    }

    @Redirect("android.widget.VideoView->onKeyDown")
    public static boolean redir_android_widget_VideoView_onKeyDown2(Object _this, int p0, android.view.KeyEvent p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.widget.VideoView mthd: onKeyDown retCls: boolean params: int "+convert(p0)+" android.view.KeyEvent "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.widget.VideoView mthd: onKeyDown retCls: boolean params: int "+convert(p0)+" android.view.KeyEvent "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (boolean) Instrumentation.callBooleanMethod($.class, _this, p0, p1);
    }

    @Redirect("android.widget.VideoView->pause")
    public static void redir_android_widget_VideoView_pause0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.widget.VideoView mthd: pause retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.widget.VideoView mthd: pause retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.widget.VideoView->resume")
    public static void redir_android_widget_VideoView_resume0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.widget.VideoView mthd: resume retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.widget.VideoView mthd: resume retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("android.widget.VideoView->setVideoPath")
    public static void redir_android_widget_VideoView_setVideoPath1(Object _this, java.lang.String p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.widget.VideoView mthd: setVideoPath retCls: void params: java.lang.String "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.widget.VideoView mthd: setVideoPath retCls: void params: java.lang.String "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0);
    }

    @Redirect("android.widget.VideoView->setVideoURI")
    public static void redir_android_widget_VideoView_setVideoURI2(Object _this, android.net.Uri p0, java.util.Map p1)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.widget.VideoView mthd: setVideoURI retCls: void params: android.net.Uri "+convert(p0)+" java.util.Map "+convert(p1)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.widget.VideoView mthd: setVideoURI retCls: void params: android.net.Uri "+convert(p0)+" java.util.Map "+convert(p1)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0, p1);
    }

    @Redirect("android.widget.VideoView->suspend")
    public static void redir_android_widget_VideoView_suspend0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: android.widget.VideoView mthd: suspend retCls: void params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: android.widget.VideoView mthd: suspend retCls: void params:  stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this);
    }

    @Redirect("java.net.ServerSocket->bind")
    public static void redir_java_net_ServerSocket_bind1(Object _this, java.net.SocketAddress p0)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: java.net.ServerSocket mthd: bind retCls: void params: java.net.SocketAddress "+convert(p0)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: java.net.ServerSocket mthd: bind retCls: void params: java.net.SocketAddress "+convert(p0)+" stacktrace: "+stackTrace+"");
        class $ {}
        Instrumentation.callVoidMethod($.class, _this, p0);
    }

    @Redirect("java.net.URL->openConnection")
    public static java.net.URLConnection redir_java_net_URL_openConnection0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: java.net.URL mthd: openConnection retCls: java.net.URLConnection params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: java.net.URL mthd: openConnection retCls: java.net.URLConnection params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (java.net.URLConnection) Instrumentation.callObjectMethod($.class, _this);
    }

    @Redirect("java.net.URLConnection->getInputStream")
    public static java.io.InputStream redir_java_net_URLConnection_getInputStream0(Object _this)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: java.net.URLConnection mthd: getInputStream retCls: java.io.InputStream params:  stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: java.net.URLConnection mthd: getInputStream retCls: java.io.InputStream params:  stacktrace: "+stackTrace+"");
        class $ {}
        return (java.io.InputStream) Instrumentation.callObjectMethod($.class, _this);
    }

    @Redirect("org.apache.http.impl.client.AbstractHttpClient->execute")
    public static org.apache.http.HttpResponse redir_org_apache_http_impl_client_AbstractHttpClient_execute3(Object _this, org.apache.http.HttpHost p0, org.apache.http.HttpRequest p1, org.apache.http.protocol.HttpContext p2)
    {
        String stackTrace = getStackTrace();
        long threadId = getThreadId();
        Log.i(TAG_MONITOR_API, "TId: "+threadId+" objCls: org.apache.http.impl.client.AbstractHttpClient mthd: execute retCls: org.apache.http.HttpResponse params: org.apache.http.HttpHost "+convert(p0)+" org.apache.http.HttpRequest "+convert(p1)+" org.apache.http.protocol.HttpContext "+convert(p2)+" stacktrace: "+stackTrace+"");
        addCurrentLogs("TId: "+threadId+" objCls: org.apache.http.impl.client.AbstractHttpClient mthd: execute retCls: org.apache.http.HttpResponse params: org.apache.http.HttpHost "+convert(p0)+" org.apache.http.HttpRequest "+convert(p1)+" org.apache.http.protocol.HttpContext "+convert(p2)+" stacktrace: "+stackTrace+"");
        class $ {}
        return (org.apache.http.HttpResponse) Instrumentation.callObjectMethod($.class, _this, p0, p1, p2);
    }



  //endregion


}
