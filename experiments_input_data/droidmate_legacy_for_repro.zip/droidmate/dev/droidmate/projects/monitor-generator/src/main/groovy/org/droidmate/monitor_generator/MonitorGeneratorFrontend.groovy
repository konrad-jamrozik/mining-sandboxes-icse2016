// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org

package org.droidmate.monitor_generator

import groovy.util.logging.Slf4j

import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.Paths

import static java.nio.file.Files.readAllLines

@Slf4j
public class MonitorGeneratorFrontend
{

  public static void main(String[] args)
  {
    try
    {
      MonitorGeneratorResources res = new MonitorGeneratorResources()
      List<String> jellybeanPublishedApiMapping = readAllLines(res.jellybeanPublishedApiMapping)
      List<String> jellybeanStaticMethods = readAllLines(res.jellybeanStaticMethods)
      List<String> appguardMonitoredApis = readAllLines(res.appguardMonitoredApis)

      if (!computeAndPrintApiListsStats(args, jellybeanPublishedApiMapping, jellybeanStaticMethods, appguardMonitoredApis))
        generateMonitorSrc(res, jellybeanPublishedApiMapping, jellybeanStaticMethods, appguardMonitoredApis)

    } catch (Exception e)
    {
      handleException(e)
    }
  }

  private static boolean computeAndPrintApiListsStats(String[] args,
                                                      List<String> jellybeanPublishedApiMapping,
                                                      List<String> jellybeanStaticMethods,
                                                      List<String> appguardMonitoredApis)
  {
    def apiListsStatsArg = "apiListsStats"
    if (args.any {it.startsWith(apiListsStatsArg)})
    {
      def stats = new ApiListsStats(jellybeanPublishedApiMapping, jellybeanStaticMethods, appguardMonitoredApis)

      String outFilePath = args.find {it.startsWith(apiListsStatsArg + "=")}
      if (outFilePath == null)
        stats.print()
      else
      {
        Path apiListOutFile = Paths.get(outFilePath - (apiListsStatsArg + "="))
        assert Files.isWritable(apiListOutFile)
        stats.print(apiListOutFile)
      }

      return true

    } else
      return false
  }

  private static void generateMonitorSrc(MonitorGeneratorResources res,
                                         List<String> jellybeanPublishedApiMapping,
                                         List<String> jellybeanStaticMethods,
                                         List<String> appguardMonitoredApis)
  {
    def monitorGenerator = new MonitorGenerator(
      new RedirectionsGenerator(),
      new MonitorSrcTemplate(res.monitorSrcTemplatePath.newReader())
    )

    String monitorSrc = monitorGenerator.generate(jellybeanPublishedApiMapping, jellybeanStaticMethods, appguardMonitoredApis)
    MonitorSrcFile.create(monitorSrc, res.monitorSrcOutPath)
  }

  static handleException = {Exception e ->
    log.error("Exception was thrown and propagated to the frontend.", e)
    System.exit(1)
  }


}