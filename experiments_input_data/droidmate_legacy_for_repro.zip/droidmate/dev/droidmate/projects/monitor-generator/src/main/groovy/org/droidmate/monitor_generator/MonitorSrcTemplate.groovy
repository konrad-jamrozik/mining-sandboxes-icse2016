// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org

package org.droidmate.monitor_generator

class MonitorSrcTemplate
{

  private final static String injectionPoint_ctorCalls      = "GENERATED_CODE_INJECTION_POINT:CTOR_REDIR_CALLS"
  private final static String injectionPoint_ctorTargets    = "GENERATED_CODE_INJECTION_POINT:CTOR_REDIR_TARGETS"
  private final static String injectionPoints_methodTargets = "GENERATED_CODE_INJECTION_POINT:METHOD_REDIR_TARGETS"

  private final BufferedReader monitorSrcTemplate

  MonitorSrcTemplate(BufferedReader monitorSrcTemplate)
  {
    this.monitorSrcTemplate = monitorSrcTemplate
  }


  String injectGeneratedCode(String genCtorRedirCalls, String genCtorTargets, String genMethodsTargets)
  {
    return monitorSrcTemplate
      .readLines().collect {
      it.contains(injectionPoint_ctorCalls) ? genCtorRedirCalls
        : it.contains(injectionPoint_ctorTargets) ? genCtorTargets
        : it.contains(injectionPoints_methodTargets) ? genMethodsTargets : it
    }
    .join(System.lineSeparator())
  }
}
