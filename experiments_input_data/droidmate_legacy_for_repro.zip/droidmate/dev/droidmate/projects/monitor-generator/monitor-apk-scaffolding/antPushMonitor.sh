#!/bin/sh

# This command is here for interactive manual debugging convenience.
# To be run from current dir after "ant debug".
adb push "bin/monitor-generator-apk-scaffolding-debug.apk" data/data/com.worldwritabledir/app_files/monitor.apk