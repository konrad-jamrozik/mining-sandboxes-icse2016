// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org

package org.droidmate.test

import ch.qos.logback.classic.Level
import groovy.transform.TypeChecked
import org.droidmate.logging.LogbackAppenders
import org.droidmate.logging.LogbackUtilsRequiringLogbackLog
import org.junit.Before

@TypeChecked
class DroidmateGroovyTestCase extends GroovyTestCase
{
  /*
    Used for profiling the JUnit test runs with VisualVM. Uncomment, run the tests with -Xverify:none JVM option and make sure
    that in those 5 seconds you will select the process in VisualVM, click the "profiler" tab and start CPU profiling.
    For more, see Konrad's OneNote / Reference / Technical / Java / Profiling.

   */
//  static {
//    println "Waiting for profiler for 5 seconds"
//    Thread.sleep(5000)
//    println "Done waiting!"
//  }

  // !!! DUPLICATION WARNING !!!
  // These values have to be the same as the ones of the apk fixture file represented by apkName_simple variable
  // (search the source code for the variable name to find its defining class).
  public static String apkFixture_simple_packageName                     = "org.droidmate.fixtures.apks.simple"
  public static String apkFixture_simple_launchableActivityComponentName =
    "org.droidmate.fixtures.apks.simple/org.droidmate.fixtures.apks.simple.MainActivity"
  // end of DUPLICATION WARNING

  public static Level                  stdoutAppendersLogLevelForTesting = Level.ERROR
  public static FilesystemTestFixtures fixtures
  static {
    LogbackAppenders.setThresholdLevelOfStdStreamsAppenders(stdoutAppendersLogLevelForTesting)
    fixtures = new FilesystemTestFixtures()
  }

  @Before
  void setUp()
  {
    LogbackUtilsRequiringLogbackLog.cleanLogsDir()
  }
}
