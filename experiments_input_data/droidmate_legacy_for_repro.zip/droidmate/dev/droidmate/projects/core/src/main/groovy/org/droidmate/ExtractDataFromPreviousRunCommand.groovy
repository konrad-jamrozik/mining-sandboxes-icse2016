// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org
package org.droidmate

import groovy.util.logging.Slf4j
import org.droidmate.exploration.datatypes.ExplorationOutput
import org.droidmate.exploration.output.IExplorationOutputDataPersister
import org.droidmate.frontend.configuration.Configuration
import org.droidmate.lowlevel.filesystem.IStorage

@Slf4j
class ExtractDataFromPreviousRunCommand extends DroidmateCommand
{

  final IStorage                        storage
  final IExplorationOutputDataPersister persister

  ExtractDataFromPreviousRunCommand(IStorage storage, IExplorationOutputDataPersister persister)
  {
    this.storage = storage
    this.persister = persister
  }

  @Override
  void execute(Configuration cfg)
  {
    log.info("Deserializing and extracting data from previous apk exploration outputs.")
    ExplorationOutput explorationOutput = storage.deserializeAll()
    explorationOutput.sort {it.appPackageName}

    persister.persist(explorationOutput)
  }
}
