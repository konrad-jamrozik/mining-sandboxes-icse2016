// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org

package org.droidmate.lowlevel.apk

import groovy.transform.TypeChecked
import groovy.util.logging.Slf4j
import org.droidmate.common.Assert
import org.droidmate.device.IAndroidDeviceDeployment
import org.droidmate.exceptions.ApkDeploymentException
import org.droidmate.exceptions.ApkUndeploymentException
import org.droidmate.exceptions.DroidmateException
import org.droidmate.frontend.configuration.Configuration

/**
 * @see IApkDeployer#withDeployedApk(org.droidmate.device.IAndroidDeviceDeployment, Apk, groovy.lang.Closure)
 */
@Slf4j

@TypeChecked
public class ApkDeployer implements IApkDeployer
{

  private final Configuration cfg


  ApkDeployer(Configuration cfg)
  {
    this.cfg = cfg
  }

  /**
   * <p>
   * Deploys the {@code apk} on a {@code device} A(V)D, executes the {@code closure} and undeploys the apk from
   * the {@code device}
   * </p>
   */
  @Override
  public void withDeployedApk(IAndroidDeviceDeployment device, Apk apk, Closure computation) throws
    ApkDeploymentException, ApkUndeploymentException
  {
    log.trace("Deploying apk {}.", apk.fileName);

    assert device != null
    Assert.checkClosureFirstParameterSignature(computation, Apk)

    // Deployment of apk on device will read some information from logcat, so it has to be cleared to ensure the
    // anticipated commands are not matched against logcat messages from previous deployments.
    device.clearLogcat()

    log.info("Installing {}", apk.fileName)

    // KJA2 clean up this exception handling mess

    try
    {
      /* The apk is uninstalled before installation to ensure:
         - any cache will be purged.
         - a different version of the same app can be installed, if necessary (without uninstall, an error will be issued about
         certificates not matching or something like that)
      */
      device.uninstallApk(apk.packageName, /* warnAboutFailure  = */ false)
      device.installApk(apk)
    }
    catch (DroidmateException e)
    {
      throw new ApkDeploymentException(e)
    }

    try
    {
      computation(apk)
    } catch (Exception e)
    {
      log.error("The closure operating on android device with deployed apk threw ${e.class.simpleName}. " +
        "The exception will be now rethrown and in the 'finally' block the apk will be uninstalled.")
      throw e

    } finally
    {
      try
      {
        device.clearLogcat() // Do so, so the logcat messages sent from the uninstalled apk won't interfere with the next one.

        if (cfg.uninstallApk)
        {
          log.info("Uninstalling $apk.fileName")
          device.clearPackage(apk.packageName)
          device.uninstallApk(apk.packageName, /* warnAboutFailure = */ true)
        }
        else
        {
          // If the apk is not uninstalled, some of its monitored services might remain, interfering with monitored
          // logcat messages expectations for next explored apk, making DroidMate throw an assertion error.
        }

      } catch (DroidmateException e)
      {
        throw new ApkUndeploymentException("Failed undeploying apk. " +
          "Be warned: this exception suppresses exception from executing the closure operating on the device with deployed apk, " +
          "if such exception occurred. Appropriate error message was logged if such exception indeed occurred.", e)
      }
    }

    log.trace("Undeployed apk {}", apk.fileName)
  }

}
