// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org
package org.droidmate.exploration

import org.droidmate.common.LabeledEdge
import org.droidmate.exploration.datatypes.ExplorationAction
import org.droidmate.exploration.datatypes.GuiState
import org.droidmate.exploration.datatypes.IGuiState
import org.graphstream.graph.Graph
import org.graphstream.graph.implementations.MultiGraph
import org.graphstream.stream.file.FileSinkDOT

class DeviceGuiModelGraph
{

  final IGuiState                                                 homeGuiState
  final IGuiState                                                 launchGuiState
  final Set<IGuiState>                                            guiStates
  final Set<LabeledEdge<IGuiState, ExplorationAction, IGuiState>> stateTransitions

  DeviceGuiModelGraph(DeviceGuiModel model)
  {
    this.homeGuiState = model.homeGuiState
    this.launchGuiState = model.launchGuiState
    this.guiStates = model.guiStates
    this.stateTransitions = model.stateTransitions
  }

  public String toDOTString()
  {
    List<IGuiState> guiStatesOrderedByBreadth = buildGuiStatesOrderedByBreadth()

    MultiGraph graph = buildGraph(guiStatesOrderedByBreadth)

    def sink = new FileSinkDOT(true)
    def outWriter = new StringWriter()
    sink.writeAll(graph, outWriter)
    return outWriter.toString()
  }

  private List<IGuiState> buildGuiStatesOrderedByBreadth()
  {
    List<IGuiState> guiStatesOrderedByBreadth = [homeGuiState, launchGuiState]
    Set<LabeledEdge<IGuiState, ExplorationAction, IGuiState>> yetNotIncludedTransitions = stateTransitions.collect()

    int stateIdCounter = 2
    while (!yetNotIncludedTransitions.empty)
    {
      def nextEvaluatedTransition = yetNotIncludedTransitions.find {it.source in guiStatesOrderedByBreadth}
      assert nextEvaluatedTransition != null
      yetNotIncludedTransitions.remove(nextEvaluatedTransition)
      if (!(nextEvaluatedTransition.target in guiStatesOrderedByBreadth))
      {
        guiStatesOrderedByBreadth << new GuiState(nextEvaluatedTransition.target, "S" + stateIdCounter)
        stateIdCounter++
      }
    }
    return guiStatesOrderedByBreadth
  }

  private MultiGraph buildGraph(List<IGuiState> guiStatesOrderedByBreadth)
  {
    Graph graph = new MultiGraph("GUI model", true, false, guiStates.size(), stateTransitions.size())

    guiStatesOrderedByBreadth.each {IGuiState guiState -> graph.addNode(guiState.id)}
    graph.addEdge("reset", "home", "S1", true)

    addEdgesToGraph(guiStatesOrderedByBreadth, graph)
    return graph
  }

  private Map<IGuiState, List<LabeledEdge<IGuiState, ExplorationAction, IGuiState>>> addEdgesToGraph(List<IGuiState> guiStatesOrderedByBreadth, Graph graph)
  {
    return stateTransitions.groupBy {it.source}.each {
      Map.Entry<IGuiState, List<LabeledEdge<IGuiState, ExplorationAction, IGuiState>>> group ->
        int edgeIndex = 1
        String sourceId = guiStatesOrderedByBreadth.find {it == group.key}.id
        group.value.each {LabeledEdge<IGuiState, ExplorationAction, IGuiState> edge ->
          String targetId = guiStatesOrderedByBreadth.find {it == edge.target}.id
          graph.addEdge("$sourceId-E$edgeIndex-$targetId", sourceId, targetId, true)
          edgeIndex++
        }
    }
  }
}
