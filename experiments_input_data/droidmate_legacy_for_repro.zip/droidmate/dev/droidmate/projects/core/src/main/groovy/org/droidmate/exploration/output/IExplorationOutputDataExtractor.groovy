// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org

package org.droidmate.exploration.output

import org.droidmate.exploration.datatypes.ExplorationOutput

public interface IExplorationOutputDataExtractor
{

  public void pgfplotsChartInputData(Map cfgMap, ExplorationOutput explorationOutput, Writer writer)

  void stackTraces(ExplorationOutput output, Writer writer)

  void apiManifest(ExplorationOutput output, Writer writer)

  void summary(ExplorationOutput output, Writer writer)

  void actions(ExplorationOutput output, Writer writer)

  void possiblyRedundantApiCalls(ExplorationOutput output, Writer writer)
}
