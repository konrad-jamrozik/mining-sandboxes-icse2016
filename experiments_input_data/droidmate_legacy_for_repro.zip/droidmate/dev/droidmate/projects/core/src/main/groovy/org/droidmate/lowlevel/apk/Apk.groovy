// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org
package org.droidmate.lowlevel.apk

import groovy.transform.Canonical
import org.droidmate.lowlevel.androidsdk.IAaptWrapper

import java.nio.file.Files
import java.nio.file.Path

// Suppresses warnings incorrectly caused by assertion checks in ctor.
@SuppressWarnings("GrFinalVariableAccess")
@Canonical
class Apk implements IApk
{

  final String fileName
  final String absolutePath
  final String packageName
  final String launchableActivityName
  final String launchableActivityComponentName

  public static Apk build(IAaptWrapper aapt, Path path)
  {
    assert aapt != null
    assert path != null
    assert Files.isRegularFile(path)

    def (String packageName, String launchableActivityName, String launchableActivityComponentName) = aapt.getMetadata(path)

    String fileName = path.fileName.toString()
    String absolutePath = path.toAbsolutePath().toString()

    return new Apk(fileName, absolutePath, packageName, launchableActivityName, launchableActivityComponentName)
  }

  Apk(String fileName, String absolutePath, String packageName, String launchableActivityName, String launchableActivityComponentName)
  {
    assert fileName?.size() > 0
    assert fileName.endsWith(".apk")
    assert absolutePath?.size() > 0
    assert packageName?.size() > 0
    assert launchableActivityName?.size() > 0
    assert launchableActivityComponentName?.size() > 0

    this.fileName = fileName
    this.absolutePath = absolutePath
    this.packageName = packageName
    this.launchableActivityName = launchableActivityName
    this.launchableActivityComponentName = launchableActivityComponentName
  }

}

