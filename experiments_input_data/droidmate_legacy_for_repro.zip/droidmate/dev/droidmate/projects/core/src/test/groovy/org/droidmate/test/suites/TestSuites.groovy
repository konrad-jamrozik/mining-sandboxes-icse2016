// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org

package org.droidmate.test.suites

import org.droidmate.DroidmateFrontendTest
import org.droidmate.logging.LogbackAppendersTest
import org.droidmate.test.thirdPartyAPIs.GroovyTest
import org.droidmate.test.thirdPartyAPIs.JavaTest
import org.droidmate.test.thirdPartyAPIs.LogbackTest
import org.junit.runner.RunWith
import org.junit.runners.Suite

/*
  N00b Reference:

  How test suites work:
  https://github.com/junit-team/junit/wiki/Aggregating-tests-in-suites
*/


@RunWith(Suite)
@Suite.SuiteClasses([
  UnsolvedThirdPartyBugsTestSuite,
  ThirdPartyAPIsTestSuite,
  RegressionTestSuite
])
class AllTestSuites
{
}


@RunWith(Suite)
@Suite.SuiteClasses([
])
class UnsolvedThirdPartyBugsTestSuite
{
}


@RunWith(Suite)
@Suite.SuiteClasses([
  JavaTest,
  GroovyTest,
  LogbackTest,
])
class ThirdPartyAPIsTestSuite
{
}

@RunWith(Suite)
@Suite.SuiteClasses([
  TestCodeTestSuite,
  UnitTestSuite,
  IntegrationTestSuite,
])
class RegressionTestSuite
{
}

@RunWith(Suite)
@Suite.SuiteClasses([
  LogbackAppendersTest,
])
class TestCodeTestSuite
{
}


@RunWith(Suite)
@Suite.SuiteClasses([
  DroidmateFrontendTest,
])
class IntegrationTestSuite
{
}














