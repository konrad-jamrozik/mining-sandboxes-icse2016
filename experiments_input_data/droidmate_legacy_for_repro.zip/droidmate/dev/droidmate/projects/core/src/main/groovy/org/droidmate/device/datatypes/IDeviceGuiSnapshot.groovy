// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org

package org.droidmate.device.datatypes

import org.droidmate.exploration.datatypes.GuiState

public interface IDeviceGuiSnapshot extends Serializable
{

  String getWindowHierarchyDump()

  String getPackageName()

  GuiState getGuiState()

  // WISH ung! Implementation dependence. Move the ValidationResult enum to correct place.
  UiautomatorWindowDump.ValidationResult validate()
}

