// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org

package org.droidmate.exploration

import groovy.transform.TypeChecked
import org.droidmate.device.IAndroidDevice
import org.droidmate.exploration.datatypes.IApkExplorationOutput
import org.droidmate.frontend.configuration.Configuration
import org.droidmate.frontend.configuration.ConfigurationBuilder
import org.droidmate.init.InitConstants
import org.droidmate.logcat.IApiLogcatMessage
import org.droidmate.lowlevel.apk.Apk
import org.droidmate.lowlevel.apk.ApksProvider
import org.droidmate.lowlevel.filesystem.Storage
import org.droidmate.test.DroidmateGroovyTestCase
import org.droidmate.test.suites.RequiresDevice
import org.junit.FixMethodOrder
import org.junit.Test
import org.junit.experimental.categories.Category
import org.junit.runner.RunWith
import org.junit.runners.JUnit4
import org.junit.runners.MethodSorters

@SuppressWarnings("GroovyAssignabilityCheck")
@TypeChecked
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(JUnit4)
class ExplorationExecutorTest extends DroidmateGroovyTestCase
{

  @Category(RequiresDevice)
  @Test
  void "Collects monitored API calls logs during device exploration"()
  {
    String[] args = [
      //@formatter:off
      Configuration.pn_useApkFixturesDir  , true,
      Configuration.pn_apksNames          , "[$InitConstants.monitored_inlined_apk_fixture_name]",
      Configuration.pn_widgetIndexes      , [0],
      Configuration.pn_droidmateOutputDir , InitConstants.test_temp_dir_name,
      Configuration.pn_uiautomatorDaemonWaitForWindowUpdateTimeout  , "50",
      Configuration.pn_delayBetweenAttemptsToObtainValidGuiSnapshot , "0",
      Configuration.pn_delayAfterLaunchingActivity                  , "0"
      //@formatter:on
    ]
    Configuration cfg = new ConfigurationBuilder().build(args)
    DeviceTools deviceTools = new DeviceTools(cfg)

    ApksProvider apksProvider = new ApksProvider(deviceTools.aapt)
    Apk apk = apksProvider.getApks(cfg.apksDirFuncPath, cfg.apksLimit, cfg.apksNames).first()

    ExplorationExecutor explorationExecutor = ExplorationExecutor.build(cfg, new Storage(cfg.droidmateOutputDirPath))

    IApkExplorationOutput out = null
    deviceTools.deviceDeployer.withSetupDevice(0) {IAndroidDevice device ->
      deviceTools.apkDeployer.withDeployedApk(device, apk) {Apk deployedApk ->

        // Act
        out = explorationExecutor.explore(deployedApk.packageName, deployedApk.launchableActivityComponentName, device)
      }
    }

    List<List<IApiLogcatMessage>> apiLogs = out?.apiLogs

    assert apiLogs.size() == 3

    //noinspection GroovyUnusedAssignment
    def resetAppApiLogs = apiLogs[0]
    def clickApiLogs = apiLogs[1]
    def terminateAppApiLogs = apiLogs[2]

    assert clickApiLogs.size() == 2
    assert clickApiLogs*.methodName == ["openConnection", "<init>"]

    assert terminateAppApiLogs.size() == 0
  }
}

