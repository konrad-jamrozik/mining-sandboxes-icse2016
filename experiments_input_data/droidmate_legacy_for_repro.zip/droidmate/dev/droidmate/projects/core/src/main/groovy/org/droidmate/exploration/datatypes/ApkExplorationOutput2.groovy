// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org
package org.droidmate.exploration.datatypes

import java.time.LocalDateTime


/* KJA2 update apk expl output

  - add "instanceName" to distinguish multiple instances of the same app
  - add "pid" to API logs
  - add "staticness" to API logs

  Java serialization refs:
  - compatible changes see: See http://docs.oracle.com/javase/8/docs/platform/serialization/spec/version.html
  - see also: http://stackoverflow.com/questions/5005330/upgrading-a-java-serializable-class

 */
class ApkExplorationOutput2 implements IApkExplorationOutput2
{
  ApkExplorationOutput2(String packageName, String launchableActivityComponentName, String instanceName)
  {
  }

  @Override
  void add(IRunnableExplorationAction action, IExplorationActionRunResult result)
  {
    // KJA2 current work
    assert false: "Not yet implemented!"
  }

  @Override
  String getAppPackageName()
  {
    // KJA2 current work
    assert false: "Not yet implemented!"
  }

  @Override
  void setExplorationEndTime(LocalDateTime time)
  {
    // KJA2 current work
    assert false: "Not yet implemented!"
  }

  @Override
  void assertCorrect()
  {
    // KJA2 current work
    assert false: "Not yet implemented!"
  }
}
