// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org

package org.droidmate.test.suites

import org.droidmate.device.AndroidDeviceTest
import org.droidmate.device.datatypes.UiautomatorWindowDumpTest
import org.droidmate.exploration.ExplorationActionTranslatorTest
import org.droidmate.exploration.ExplorationExecutorTest
import org.droidmate.exploration.ExplorationStrategyTest
import org.droidmate.exploration.datatypes.ApkExplorationOutputTest
import org.droidmate.exploration.datatypes.TimeFormattedLogcatMessageTest
import org.droidmate.exploration.output.DataExtractorTest
import org.droidmate.frontend.configuration.ConfigurationBuilderTest
import org.droidmate.lowlevel.androidsdk.AaptWrapperTest
import org.droidmate.lowlevel.androidsdk.AdbWrapperTest
import org.droidmate.utils.UiaTestCaseLogsProcessorTest
import org.junit.runner.RunWith
import org.junit.runners.Suite

/*
  N00b Reference:

  How test suites work:
  https://github.com/junit-team/junit/wiki/Aggregating-tests-in-suites
*/

@RunWith(Suite)
@Suite.SuiteClasses([
  ConfigurationBuilderTest,
  UiaTestCaseLogsProcessorTest,
  AaptWrapperTest,
  AdbWrapperTest,
  AndroidDeviceTest,
  ExplorationTestSuite,
])
class UnitTestSuite
{
}

@RunWith(Suite)
@Suite.SuiteClasses([
  TimeFormattedLogcatMessageTest,
  UiautomatorWindowDumpTest,
  ExplorationActionTranslatorTest,
  ExplorationStrategyTest,
  ExplorationExecutorTest,
  ApkExplorationOutputTest,
  DataExtractorTest,
])
class ExplorationTestSuite
{
}

