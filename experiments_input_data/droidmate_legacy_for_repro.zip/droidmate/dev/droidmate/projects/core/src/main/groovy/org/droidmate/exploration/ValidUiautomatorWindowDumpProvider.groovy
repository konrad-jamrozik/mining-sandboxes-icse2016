// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org

package org.droidmate.exploration

import groovy.transform.TypeChecked
import groovy.util.logging.Slf4j
import org.droidmate.common.logging.LogbackConstants
import org.droidmate.common.logging.Markers
import org.droidmate.device.IAndroidDeviceExploration
import org.droidmate.device.datatypes.IDeviceGuiSnapshot
import org.droidmate.device.datatypes.MissingGuiSnapshot
import org.droidmate.device.datatypes.UiautomatorWindowDump
import org.droidmate.exceptions.UiautomatorWindowDumpValidationException

@TypeChecked
@Slf4j
class ValidUiautomatorWindowDumpProvider implements IValidDeviceGuiSnapshotProvider
{

  private int attemptsToObtainValidWindowDump
  private int delayBetweenAttemptsToObtainValidGuiSnapshot // ms

  private int attemptsLeft


  ValidUiautomatorWindowDumpProvider(
    int attemptsToObtainValidWindowDump,
    int delayBetweenAttemptsToObtainValidGuiSnapshot)
  {
    this.attemptsToObtainValidWindowDump = attemptsToObtainValidWindowDump
    this.delayBetweenAttemptsToObtainValidGuiSnapshot = delayBetweenAttemptsToObtainValidGuiSnapshot
    assert this.attemptsToObtainValidWindowDump >= 1
    assert this.delayBetweenAttemptsToObtainValidGuiSnapshot >= 0
  }

  @Override
  IDeviceGuiSnapshot getValidGuiSnapshot(IAndroidDeviceExploration device) throws UiautomatorWindowDumpValidationException
  {
    // log.debug("Getting valid GUI snapshot")
    attemptsLeft = attemptsToObtainValidWindowDump
    attemptsLeft--
    assert attemptsLeft >= 0


    IDeviceGuiSnapshot snapshot = device.getGuiSnapshot() // KJA2 handle device exception
    UiautomatorWindowDump.ValidationResult vres = snapshot.validate()

    while (!vres.valid && attemptsLeft > 0)
    {
      log.debug("Failed to obtain a valid GUI snapshot. Validation failure reason: ${vres.description}. " +
        "Making next attempt out of remaining $attemptsLeft.")

      attemptsLeft--
      waitForNextValidGuiSnapshotAttempt()
      snapshot = device.getGuiSnapshot() // KJA2 handle device exception
      vres = snapshot.validate()
    }
    assert attemptsLeft >= 0

    if (!vres.valid)
    {
      assert attemptsLeft == 0

      log.warn("Failed to obtain a valid GUI snapshot. Exhausted all attempts. Validation failure reason: ${vres.description}. " +
        "Returning synthetic 'missing GUI snapshot'. $LogbackConstants.err_log_msg")
      log.error(Markers.exceptions, "Exhausted all attempts at getting valid GUI snapshot:\n", new UiautomatorWindowDumpValidationException(snapshot.windowHierarchyDump, vres.description))

      return new MissingGuiSnapshot()
    }

    assert snapshot?.validate()?.valid
    return snapshot
  }

  private void waitForNextValidGuiSnapshotAttempt()
  {
    Thread.sleep(delayBetweenAttemptsToObtainValidGuiSnapshot)
  }

  private static void logValidationErrorAndThrowException(String windowHierarchyDump, String exceptionMessage)
  {
    def ex = new UiautomatorWindowDumpValidationException(windowHierarchyDump, exceptionMessage)
    log.error("Throwing $ex")
    throw ex
  }
}
