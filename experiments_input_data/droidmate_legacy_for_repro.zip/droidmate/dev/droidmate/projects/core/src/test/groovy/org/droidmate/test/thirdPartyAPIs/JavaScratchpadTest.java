// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org

package org.droidmate.test.thirdPartyAPIs;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

import java.util.ArrayList;
import java.util.List;


@RunWith(JUnit4.class)
public class JavaScratchpadTest
{
  /**
   * {@code Alice has a cat}<br/>
   * {@code A lice has a cat}<br/>
   * long text long text long text long text long text long text long text long text long text long text long text long text
   */
  @Test
  public void test()
  {
    List<Integer> x = new ArrayList<>();
    int y = x.get(0);
   // int x = 1/Integer.valueOf("0");
  }
}

