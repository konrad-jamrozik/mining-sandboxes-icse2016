// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org

package org.droidmate.exploration

import org.droidmate.ITimeGenerator
import org.droidmate.TimeGenerator
import org.droidmate.common.LabeledEdge
import org.droidmate.common.Pair
import org.droidmate.common.exploration.datatypes.Widget
import org.droidmate.common.logcat.TimeFormattedLogcatMessage
import org.droidmate.common_android.Constants
import org.droidmate.common_android.guimodel.GuiAction
import org.droidmate.device.datatypes.*
import org.droidmate.exceptions.UnexpectedIfElseFallthroughError
import org.droidmate.exploration.datatypes.*
import org.droidmate.logcat.ITimeFormattedLogcatMessage
import org.droidmate.logcat.MonitorConstants

import java.util.regex.Matcher

import static org.droidmate.device.datatypes.UiautomatorWindowDumpTestHelper.newHomeScreenWindowDump
import static org.droidmate.exploration.datatypes.ExplorationAction.newResetAppExplorationAction
import static org.droidmate.exploration.datatypes.ExplorationAction.newWidgetExplorationAction

/**
 * <p>
 * A wrapper around GUI model that adds two features:
 *
 * </p><p>
 * 1. GUI snapshots representing GUI states of the GUI model screens<br/>
 * 2. "currently active" GUI state.
 *
 * </p><p>
 * This class is used by {@link org.droidmate.device.AndroidDeviceSimulator} to simulate the device. As the simulator mimics an android device,
 * the GUI snapshots of this class allow it to mimic asking the device for current GUI snapshot. The "currently active" GUI state
 * in turn allows this class to keep track of the current state of the simulated device. This is necessary if the simulated device
 * is instructed to do something that would change the displayed simulated screen, e.g. a widget-click that starts another
 * activity.
 *
 * </p>
 *
 */
class SimulatedDeviceGuiModel
{

  @Delegate
  IDeviceGuiModel guiModel

  GuiState initialGuiState
  GuiState currentGuiState

  /**
   * The underlying {@link #guiModel} is represented by {@link GuiState} instances, but the simulator needs to return actual
   * {@link IDeviceGuiSnapshot}, as it mimics the {@link org.droidmate.device.IAndroidDeviceExploration} interface. Thus, this mapping maps each of the
   * states in the {@code guiModel} to a corresponding {@code IDeviceGuiSnapshot}, returned when a call to
   * {@link #transition(org.droidmate.device.datatypes.IAndroidDeviceAction)} is made.
   */
  Map<GuiState, IDeviceGuiSnapshot> guiStateToSnapshotMap = [:]

  /**
   * When {@code action} supplied to {@link #transition(org.droidmate.device.datatypes.IAndroidDeviceAction)} is an action that
   * clicks on a widget, the call will return simulated monitored API calls occurring when the widget living on
   * {@link #currentGuiState}, is clicked. This field contains a mapping from (guiState, widget on the guiState) to the list
   * of simulated monitored API calls. It is read by the {@code transition} method.
   */
  Map<Pair<GuiState, Widget>, List<ITimeFormattedLogcatMessage>> widgetToLogsMap = [:]

  private static enum SpecialGuiStateNames {

    home

    public static List<String> strs()
    {
      this.collect {it.toString()}
    }

  }

  /**
   * <p>
   * The simulator spec is composed of multiple strings of form: s1->w1->s2
   * Where s1, s2 denote arbitrary {@link GuiState}s and w1 denotes arbitrary Widget.
   * Each such string denotes a transition. Each such transition has a label of {@link WidgetExplorationAction}.
   *
   * </p><p>
   * In addition to the specified transitions the built {@link IDeviceGuiModel} will also contain:<br/>
   * - special "home" GuiState<br/>
   * - transition from "home" GuiState to the first GuiState listed in the spec. The transition will be labeled with
   * {@link ResetAppExplorationAction}<br/>
   *
   * </p>
   *
   * @param packageName
   * @param spec
   * @return
   */
  static SimulatedDeviceGuiModel buildFromSpec(String packageName, String spec)
  {
    ArrayList<LabeledEdge<String, String, String>> specEdges = parseSpecEdges(spec)

    List<GuiState> nonemptyGuiStates = buildNonemptyGuiStates(specEdges, packageName)
    List<GuiState> emptyGuiStates = buildEmptyGuiStates(specEdges, packageName)

    // The GUI state in which the app ends up after being reset.
    GuiState launchGuiState = nonemptyGuiStates[0]
    assert launchGuiState.id == specEdges.first().source

    // Merge all the GUI states created so far into one list.
    List<GuiState> guiStates = emptyGuiStates + nonemptyGuiStates

    // Create special GUI snapshots (for now only 'home')
    IDeviceGuiSnapshot homeSnapshot = newHomeScreenWindowDump()

    Map<GuiState, UiautomatorWindowDump> guiStateToSnapshotMap = mapGuiStatesToSnapshots(homeSnapshot, guiStates)

    // Construct transitions between all the just-constructed GUI states, according to the spec given as input.
    Set<LabeledEdge<GuiState, ExplorationAction, GuiState>> stateTransitions =
      specEdges.collect {def edge -> buildTransition(edge, guiStates, homeSnapshot.guiState)}

    return new SimulatedDeviceGuiModel(
      DeviceGuiModel.build(
        homeSnapshot.guiState,
        launchGuiState,
        guiStates - launchGuiState,
        stateTransitions),
      guiStateToSnapshotMap,
      [:],
      homeSnapshot.guiState
    )
  }

  /**
   * Builds the mapping between GUI states and GUI snapshots. All the GUI snapshots are automatically generated from the
   * GUI states, except the snapshot from home screen, which is a fixture.
   */
  private static Map<GuiState, UiautomatorWindowDump> mapGuiStatesToSnapshots(
    UiautomatorWindowDump homeSnapshot,
    List<GuiState> guiStates)
  {

    Map<GuiState, IDeviceGuiSnapshot> guiStateToSnapshotMap =

      [(homeSnapshot.guiState): homeSnapshot] +
        [guiStates, guiStates.collect {UiautomatorWindowDumpTestHelper.fromGuiState(it)}]
          .transpose().collectEntries()
    return guiStateToSnapshotMap
  }

  private
  static LabeledEdge buildTransition(LabeledEdge<String, String, String> edge, List<GuiState> guiStates, GuiState home)
  {
    // Map the edge spec made of strings into the objects.
    GuiState src_gs = guiStates.find {it.id == edge.source}
    ExplorationAction labelAction = newWidgetExplorationAction(src_gs.widgets.find {it.id == edge.label})
    GuiState target_gs = guiStates.find {it.id == edge.target}

    // Because special GUI states are obtained from GUI snapshots, they do not have their id, i.e. it is null.
    // Thus, any edge targeting any of these special GUI states, won't map to them in the mapping done above and has to be
    // resolved with help of SpecialGuiStateNames.
    if (target_gs == null)
    {
      assert edge.target in SpecialGuiStateNames.strs()
      assert edge.target == SpecialGuiStateNames.home.toString(): "Special GUI states other than 'home' are not supported."
      target_gs = home
    }
    return new LabeledEdge<>(src_gs, labelAction, target_gs)
  }

  /**
   * <p>
   * Builds from a set of {@code specEdges} obtained from {@link #parseSpecEdges(java.lang.String)} {@link GuiState}s that have
   * no widgets defined in the spec, i.e. they are never a source of a transition. The built GuiStates will actually contain
   * a one artificial "top-level" widget which is necessary to carry package name information when a {@link IDeviceGuiSnapshot}
   * based on given GuiState is requested.
   *
   * </p>
   */
  private static List<GuiState> buildEmptyGuiStates(ArrayList<LabeledEdge<String, String, String>> specEdges, String packageName)
  {
    return specEdges
      .collect {it.target}
      .findAll {!(it in specEdges.collect {it.source}) && !(it in SpecialGuiStateNames.strs())}
      .collect {return GuiStateTestHelper.newGuiStateWithTopLevelNodeOnly(packageName, it)}
  }

  /**
   * <p>
   * Builds from a set of {@code specEdges} obtained from {@link #parseSpecEdges(java.lang.String)} {@link GuiState}s that have
   * at least one widget on them, i.e. serve as an source state in at least one of the edges in the spec.
   *
   * </p><p>
   * Each such state will contain all the widgets defined in the spec. For example, spec of
   * <pre><code>
   * A-w1->B
   * A-w2->C
   * D-w3->E</code></pre>
   * will create here:<br/>
   * - GUI state {@code A} with widgets {@code w1 ,w2} and <br/>
   * - GUI state {@code D} with widget {@code w3}.
   *
   * </p>
   */
  private
  static List<GuiState> buildNonemptyGuiStates(ArrayList<LabeledEdge<String, String, String>> specEdges, String packageName)
  {
    List<GuiState> sourceGuiStates = specEdges.groupBy {it.source}.collect {
      Map.Entry<String, List<LabeledEdge<String, String, String>>> group ->
        String guiStateId = group.key
        List<String> widgetIds = group.value.collect {it.label}.unique(false)

        return GuiStateTestHelper.newGuiStateWithWidgets(widgetIds.size(), packageName, /* enabled */ true, guiStateId, widgetIds)
    }
    return sourceGuiStates
  }

  private static ArrayList<LabeledEdge<String, String, String>> parseSpecEdges(String spec)
  {
    List<LabeledEdge<String, String, String>> specEdges = []

    Matcher m = spec =~ /(\w+)-(\w+)->(\w+) ?/

    while (m.find())
      specEdges << new LabeledEdge<String, String, String>(m.group(1), m.group(2), m.group(3))

    assert specEdges.size() > 0: "Expected to have at least one spec edge defined."
    return specEdges
  }

  SimulatedDeviceGuiModel(
    IDeviceGuiModel guiModel,
    Map<GuiState, IDeviceGuiSnapshot> guiStateToSnapshotMap,
    Map<Pair<GuiState, Widget>, List<ITimeFormattedLogcatMessage>> widgetToLogsMap,
    GuiState initialGuiState)
  {
    assert guiModel != null
    assert guiStateToSnapshotMap != null
    assert widgetToLogsMap != null
    assert initialGuiState != null

    this.guiModel = guiModel
    this.guiStateToSnapshotMap = guiStateToSnapshotMap
    this.widgetToLogsMap = widgetToLogsMap
    this.initialGuiState = initialGuiState
    this.currentGuiState = this.initialGuiState
  }
/**
 * <p>
 * The time generator provides successive timestamps to the time logs returned by the simulated device from call to
 * {@link #transition(org.droidmate.device.datatypes.IAndroidDeviceAction)}.
 *
 * </p>
 */
  private ITimeGenerator timeGenerator = new TimeGenerator()

  /**
   * Returns the GUI snapshot representing the GUI state in which the simulated device was after it was just constructed.
   */
  IDeviceGuiSnapshot getInitialGuiSnapshot()
  {
    return guiStateToSnapshotMap[initialGuiState]
  }

  /**
   * <p>
   * Simulates executing the {@code deviceAction} on the simulated device. This call will do the following:
   *
   * </p><p>
   * 1. Update the {@link #currentGuiState}. If, for example, the {@code deviceAction} clicked on a
   * widget that according to the underlying {@link #guiModel} would result in the simulated device displaying a different GUI
   * screen, then this is reflected in the {@code currentGuiState} being updated to the one representing the newly displayed GUI
   * screen.
   *
   * </p><p>
   * 2. Return the GUI snapshot associated with {@code currentGuiState}, whether it changed or not.
   *
   * </p><p>
   * 3. Return any logcat messages associated with the {@code deviceAction}, given the {@code currentGuiState} (before update).
   * For example, API logs that ought to be monitored when the {@code deviceAction} clicked some widget on
   * {@code currentGuiState}, or monitor init logs if the {@code deviceAction} launched main activity of the app.
   *
   * </p>
   */
  Pair<IDeviceGuiSnapshot, List<ITimeFormattedLogcatMessage>> transition(IAndroidDeviceAction deviceAction)
  {
    ExplorationAction explorationAction = toExplorationAction(currentGuiState, deviceAction)

    GuiState targetGuiState = currentGuiState
    if (explorationAction.class != NoneExplorationAction)
      targetGuiState = guiModel.getTargetGuiState(currentGuiState, explorationAction)

    IDeviceGuiSnapshot snapshotOfTargetState = guiStateToSnapshotMap[targetGuiState]

    List<ITimeFormattedLogcatMessage> simulatedLogs = getSimulatedLogs(explorationAction, currentGuiState)

    currentGuiState = targetGuiState

    return new Pair(snapshotOfTargetState, simulatedLogs)
  }

  static ExplorationAction toExplorationAction(GuiState guiState, IAndroidDeviceAction deviceAction)
  {
    ExplorationAction returnedAction
    switch (deviceAction.class)
    {
      case ClickGuiAction:
        GuiAction guiAction = (deviceAction as ClickGuiAction).guiAction
        if (guiAction.guiActionCommand != null)
        {
          switch (guiAction.guiActionCommand)
          {
            case Constants.guiActionCommand_pressHome:
              returnedAction = new ExitAppExplorationAction()
              break
            case Constants.guiActionCommand_turnWifiOn:
              returnedAction = new NoneExplorationAction()
              break
            case Constants.guiActionCommand_pressBack:
              assert false: "Not yet implemented!"
              break
            default:
              throw new UnexpectedIfElseFallthroughError()
          }
        } else
        {
          assert guiAction.clickXCoor != null
          assert guiAction.clickYCoor != null
          Widget widget = getTargetWidget(guiState, guiAction)
          returnedAction = newWidgetExplorationAction(widget, guiAction.longClick)

        }
        break

      case LaunchMainActivityDeviceAction:
        returnedAction = newResetAppExplorationAction()
        break

      case AdbClearPackageAction:
        returnedAction = new ExitAppExplorationAction()
        break

      default:
        throw new UnexpectedIfElseFallthroughError()
    }

    assert returnedAction != null
    return returnedAction
  }

  private List<ITimeFormattedLogcatMessage> getSimulatedLogs(ExplorationAction action, GuiState guiState)
  {
    List<ITimeFormattedLogcatMessage> returnedLogs
    switch (action.class)
    {
      case WidgetExplorationAction:
        // There is an implicit assumption here that the returned logs are the same whether the widget is longClick-ed or not.
        Widget widget = (action as WidgetExplorationAction).widget
        returnedLogs = widgetToLogsMap.getOrDefault(new Pair(guiState, widget), [])
        break
      case ResetAppExplorationAction:
        returnedLogs = buildMonitorMessages(timeGenerator)
        break
      case ExitAppExplorationAction:
        returnedLogs = []
        break
      case NoneExplorationAction:
        returnedLogs = []
        break
      default:
        throw new UnexpectedIfElseFallthroughError()
    }
    assert returnedLogs != null
    return returnedLogs
  }

  static Widget getTargetWidget(GuiState gs, GuiAction guiAction)
  {
    int x = guiAction.clickXCoor
    int y = guiAction.clickYCoor

    List<Widget> matchedWidgets = gs.widgets.findAll {it.bounds.contains(x, y)}

    assert matchedWidgets.size() >= 1: "Expected to match at least one widget to coordinates $x $y."
    assert matchedWidgets.size() <= 1: "Expected to match at most one widget to coordinates $x $y. " +
      "Instead matched ${matchedWidgets.size()} widgets. " +
      "The matched widgets bounds:\n" +
      matchedWidgets.collect {it.boundsString}.join("\n")

    return matchedWidgets[0]
  }

  static List<ITimeFormattedLogcatMessage> buildMonitorMessages(ITimeGenerator timeGenerator)
  {
    return [
      TimeFormattedLogcatMessage.from(
        timeGenerator.shiftAndGet(milliseconds: 1500),
        MonitorConstants.log_level,
        MonitorConstants.tag_monitor_init,
        "4224", // arbitrary process ID
        MonitorConstants.message_monitor_constructed),
      TimeFormattedLogcatMessage.from(
        timeGenerator.shiftAndGet(milliseconds: 1810),
        MonitorConstants.log_level,
        MonitorConstants.tag_monitor_init,
        "4224", // arbitrary process ID
        MonitorConstants.message_prefix_monitor_initialized)
    ]
  }

}
