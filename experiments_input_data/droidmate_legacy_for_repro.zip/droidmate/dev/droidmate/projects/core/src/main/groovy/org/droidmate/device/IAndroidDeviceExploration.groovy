// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org

package org.droidmate.device

import org.droidmate.device.datatypes.IAndroidDeviceAction
import org.droidmate.device.datatypes.IDeviceGuiSnapshot
import org.droidmate.exceptions.DeviceException
import org.droidmate.exceptions.DroidmateException
import org.droidmate.exceptions.TcpServerUnreachableException
import org.droidmate.logcat.ITimeFormattedLogcatMessage

import java.time.LocalDateTime

public interface IAndroidDeviceExploration
{
  boolean hasPackageInstalled(String packageName) throws DeviceException

  IDeviceGuiSnapshot getGuiSnapshot() throws DeviceException

  void perform(IAndroidDeviceAction action)

  List<ITimeFormattedLogcatMessage> readLogcatMessages(String messageTag) throws DeviceException

  void clearLogcat() throws DroidmateException

  boolean readMonitorServerStartMsg()

  List<List<String>> readMonitorTcpMessages() throws TcpServerUnreachableException, DeviceException

  LocalDateTime getCurrentTime() throws TcpServerUnreachableException, DeviceException
}

