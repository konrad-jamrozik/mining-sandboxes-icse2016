// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org

package org.droidmate.exploration

import groovy.transform.TypeChecked
import groovy.util.logging.Slf4j
import org.droidmate.device.IDeviceResult
import org.droidmate.device.IRobustAndroidDevice
import org.droidmate.device.datatypes.IDeviceGuiSnapshot
import org.droidmate.exceptions.DroidmateException
import org.droidmate.exploration.datatypes.*
import org.droidmate.frontend.configuration.Configuration
import org.droidmate.lowlevel.ITimeProvider
import org.droidmate.lowlevel.TimeProvider
import org.droidmate.lowlevel.apk.IApk

import static org.droidmate.exploration.datatypes.ExplorationAction.newResetAppExplorationAction

@TypeChecked
@Slf4j
class Exploration implements IExploration
{

  private final Configuration cfg
  private final ITimeProvider timeProvider

  Exploration(Configuration cfg, ITimeProvider timeProvider)
  {
    this.timeProvider = timeProvider
    this.cfg = cfg
  }

  public static Exploration build(Configuration cfg)
  {
    TimeProvider timeProvider = new TimeProvider()
    return new Exploration(cfg, timeProvider)
  }

  // KJA2 check the exceptions thrown from this method will be correctly handled by device deployer and apk deployer finalize
  @Override
  IApkExplorationOutput2 run(IApk app, IRobustAndroidDevice device) throws DroidmateException
  {
    assert app != null
    assert device != null

    log.info("Exploring ${app.packageName}")

    tryAssertDeviceHasPackageInstalled(device, app.packageName)
    tryWarnDeviceDisplaysHomeScreen(device, app.fileName)

    IExplorationStrategy strategy = ExplorationStrategy.build(app.packageName, cfg)
    IApkExplorationOutput2 output = new ApkExplorationOutput2(app.packageName, app.launchableActivityComponentName, app.fileName)

    IRunnableExplorationAction action = RunnableExplorationAction.from(newResetAppExplorationAction(), timeProvider.now)
    log.info("Initial exploration action: $action")
    IExplorationActionRunResult result = action.run(app, device)
    output.add(action, result)

    if (result.successful)
    {
      while (!(action instanceof TerminateExplorationAction))
      {
        action = RunnableExplorationAction.from(strategy.decide(result), timeProvider.now)
        result = action.run(app, device)
        output.add(action, result)
      }
    }

    output.explorationEndTime = timeProvider.now
    log.info("Finished exploration of " + output.appPackageName)
    output.assertCorrect()
    return output
  }

  private void tryAssertDeviceHasPackageInstalled(IRobustAndroidDevice device, String packageName) throws DroidmateException
  {
    IDeviceResult<Boolean> packageInstalled = device.hasPackageInstalled(packageName)

    if (!packageInstalled.success)
      throw new DroidmateException("!packageInstalled.success", packageInstalled.exception)

    assert packageInstalled.result
  }

  private void tryWarnDeviceDisplaysHomeScreen(IRobustAndroidDevice device, String fileName) throws DroidmateException
  {
    IDeviceResult<IDeviceGuiSnapshot> initialGuiSnapshot = device?.guiSnapshot

    if (!initialGuiSnapshot.success)
      throw new DroidmateException("!initialGuiSnapshot.success", initialGuiSnapshot.exception)

    if (!initialGuiSnapshot.result.guiState.isHomeScreen())
      log.warn("An exploration process for $fileName is about to start but the device doesn't display home screen. " +
        "Instead, its GUI state is: $initialGuiSnapshot.result.guiState. " +
        "Continuing the exploration nevertheless, hoping that the first \"reset app\" " +
        "exploration action will force the device into the home screen.")
  }


}
