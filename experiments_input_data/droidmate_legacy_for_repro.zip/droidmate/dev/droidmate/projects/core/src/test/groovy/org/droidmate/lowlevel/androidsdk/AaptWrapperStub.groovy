// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org
package org.droidmate.lowlevel.androidsdk

import org.droidmate.exceptions.DroidmateException

import java.nio.file.Path

class AaptWrapperStub implements IAaptWrapper
{

  final List<String> metadata

  AaptWrapperStub(List<String> metadata)
  {
    this.metadata = metadata

    assert metadata?.size() == 3
    metadata.each {assert it.length() > 0}
  }

  @Override
  String getPackageName(Path apk) throws DroidmateException
  {
    assert false: "Not yet implemented!"
  }

  @Override
  String getLaunchableActivityName(Path apk) throws DroidmateException
  {
    assert false: "Not yet implemented!"
  }

  @Override
  String getLaunchableActivityComponentName(Path apk) throws DroidmateException
  {
    assert false: "Not yet implemented!"
  }

  @Override
  List<String> getMetadata(Path apk) throws DroidmateException
  {
    return metadata
  }
}
