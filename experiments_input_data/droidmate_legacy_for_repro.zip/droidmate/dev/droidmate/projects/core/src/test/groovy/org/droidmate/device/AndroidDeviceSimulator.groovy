// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org

package org.droidmate.device

import groovy.util.logging.Slf4j
import org.droidmate.common.Pair
import org.droidmate.device.datatypes.*
import org.droidmate.exceptions.DeviceException
import org.droidmate.exceptions.DroidmateException
import org.droidmate.exploration.SimulatedDeviceGuiModel
import org.droidmate.exploration.datatypes.WidgetExplorationAction
import org.droidmate.logcat.ITimeFormattedLogcatMessage
import org.droidmate.lowlevel.apk.IApk

import java.time.LocalDateTime

@Slf4j
public class AndroidDeviceSimulator implements IAndroidDevice
{

  final SimulatedDeviceGuiModel simulatedGuiModel
  final String                  packageName

  private IDeviceGuiSnapshot                currentGuiSnapshot
  private List<ITimeFormattedLogcatMessage> logcatMessagesToBeReadNext = []


  AndroidDeviceSimulator(String packageName, String spec)
  {
    this.simulatedGuiModel = SimulatedDeviceGuiModel.buildFromSpec(packageName, spec)
    this.packageName = packageName
    this.currentGuiSnapshot = simulatedGuiModel.initialGuiSnapshot
  }

  @Override
  boolean hasPackageInstalled(String packageName)
  {
    return this.packageName == packageName
  }

  @Override
  IDeviceGuiSnapshot getGuiSnapshot() throws DeviceException
  {
    log.trace("getGuiSnapshot")

    return currentGuiSnapshot
  }

  @Override
  void perform(IAndroidDeviceAction action)
  {
    log.trace("perform $action")

    switch (action.class)
    {
      case LaunchMainActivityDeviceAction:
      case ClickGuiAction:
      case AdbClearPackageAction:
        updateSimulatorState(action)
        break

      default:
        assert false: "Not yet implemented! Action: $action"
    }
  }

  void updateSimulatorState(IAndroidDeviceAction action)
  {
    if (action instanceof WidgetExplorationAction)
      println "action widget id: ${(action as WidgetExplorationAction).widget.id}"

    Pair<IDeviceGuiSnapshot, List<ITimeFormattedLogcatMessage>> transitionResult = simulatedGuiModel.transition(action)
    currentGuiSnapshot = transitionResult.first
    logcatMessagesToBeReadNext.addAll(transitionResult.second)
  }

  @Override
  void clearLogcat() throws DroidmateException
  {
    logcatMessagesToBeReadNext.clear()
  }

  @Override
  List<ITimeFormattedLogcatMessage> readLogcatMessages(String messageTag)
  {
    def returnedMessages = logcatMessagesToBeReadNext.findResults {it.tag == messageTag ? it : null}
    return returnedMessages
  }

  @Override
  LocalDateTime getCurrentTime()
  {
    return LocalDateTime.now()
  }

  @Override
  void forwardPort(int port) throws DroidmateException
  {
  }

  @Override
  void reverseForwardPort(int port) throws DroidmateException
  {
  }

  @Override
  void pushJar(File jar) throws DroidmateException
  {
  }

  @Override
  void removeJar(File jar) throws DroidmateException
  {
  }

  @Override
  void installApk(IApk apk) throws DroidmateException
  {
  }

  @Override
  void uninstallApk(String apkPackageName, boolean warnAboutFailure) throws DroidmateException
  {
  }

  @Override
  void clearPackage(String apkPackageName) throws DroidmateException
  {
  }

  @Override
  void startUiaDaemon() throws DroidmateException
  {
  }

  @Override
  void stopUiaDaemon() throws DroidmateException
  {
  }

  @Override
  boolean readMonitorServerStartMsg()
  {
    return true
  }

  @Override
  List<List<String>> readMonitorTcpMessages()
  {
    return []
  }
}
