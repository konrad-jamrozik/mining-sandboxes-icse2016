// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org

package org.droidmate.logging

import groovy.util.logging.Slf4j
import org.droidmate.common.logging.LogbackConstants

import static groovy.io.FileType.FILES

@Slf4j
class LogbackUtilsRequiringLogbackLog
{

  public static void cleanLogsDir()
  {
    File logsDir = new File(LogbackConstants.LOGS_DIR_PATH)
    if (!logsDir.directory)
      logsDir.mkdirs()

    logsDir.eachFile(FILES) {File logFile ->

      if (logFile.name in LogbackConstants.fileAppendersUsedBeforeCleanLogsDir)
        return

      log.trace("Deleting, in logs directory, a file named: $logFile")
      if (!logFile.delete())
      {
        log.trace("Failed to delete $logFile. Erasing its contents.")
        logFile.write("")
      }
    }


  }
}
