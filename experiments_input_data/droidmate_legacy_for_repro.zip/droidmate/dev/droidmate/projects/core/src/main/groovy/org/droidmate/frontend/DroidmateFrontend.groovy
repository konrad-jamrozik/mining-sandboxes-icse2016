// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org

package org.droidmate.frontend

import groovy.time.TimeCategory
import groovy.time.TimeDuration
import groovy.util.logging.Slf4j
import org.droidmate.DroidmateCommand
import org.droidmate.common.logging.LogbackConstants
import org.droidmate.exceptions.DroidmateException
import org.droidmate.exploration.DeviceTools
import org.droidmate.frontend.configuration.Configuration
import org.droidmate.frontend.configuration.ConfigurationBuilder
import org.droidmate.logging.LogbackUtilsRequiringLogbackLog

import java.nio.file.FileSystem
import java.nio.file.FileSystems
import java.time.LocalDate

import static LogbackConstants.system_prop_stdout_loglevel
import static org.droidmate.common.logging.Markers.exceptions
import static org.droidmate.common.logging.Markers.runData

/**
 * <p>
 * Entry class of DroidMate. This class should be supplied to the JVM on the command line as the entry class
 * (i.e. the class containing the {@code main} method).
 * </p>
 */
// KJA read java vm options into config dump: http://stackoverflow.com/questions/1490869/how-to-get-vm-arguments-from-inside-of-java-application
// KJA read working dir into config dump.
@Slf4j
public class DroidmateFrontend
{
  /**
   * Substitutable dependency: if null, default value will be used. For tests, set to your own value before calling main().
   * After one usage it will be again set to null, to avoid interference with other tests. Thus, for each test, you have to set
   * this field anew.
   */
  public static FileSystem fs = null

  @SuppressWarnings("GroovyUnusedDeclaration")
  public static def getFs()
  {assert false: "fs is write-only"}

  /**
   * @see #fs
   */
  static DeviceTools deviceTools = null

  @SuppressWarnings("GroovyUnusedDeclaration")
  public static def getDeviceTools()
  {assert false: "deviceTools is write-only"}

  /**
   * @see DroidmateFrontend
   */
  public static void main(String[] args)
  {
    println "DroidMate"
    println "Copyright (c) 2012 - ${LocalDate.now().year} Saarland University Software Engineering Chair."
    println "All rights reserved."

    boolean exceptionWasThrown = false
    Date runStart = new Date()
    try
    {
      validateStdoutLoglevel()
      LogbackUtilsRequiringLogbackLog.cleanLogsDir()

      log.info("Bootstrapping DroidMate: configuring from command line & injecting dependencies.")
      log.info("IMPORTANT: for detailed logs from DroidMate run, please see ${LogbackConstants.LOGS_DIR_PATH}.")

      fs = fs ?: FileSystems.getDefault()
      Configuration cfg = new ConfigurationBuilder().build(args, fs)
      fs = null

      deviceTools = deviceTools ?: new DeviceTools(cfg)
      DroidmateCommand cmd = DroidmateCommand.build(cfg.processUiaTestCasesLogs, cfg.extractData, cfg, deviceTools)
      deviceTools = null

      log.info("Welcome to DroidMate. Lie back, relax and enjoy.")
      log.info("Run start timestamp: " + runStart)

      cmd.execute(cfg)

    } catch (Exception e)
    {
      exceptionWasThrown = true
      logException(e)
      logDroidmateRunEnd(runStart, exceptionWasThrown)

    } catch (AssertionError e)
    {
      logAssertionError(e)
      logDroidmateRunEnd(runStart, /* error was thrown */ true)
      System.exit(2)
    }

    if (exceptionWasThrown)
      systemExitWithErrorCode1()
    else
    {
      logDroidmateRunEnd(runStart, false)
    }
  }

  private static void validateStdoutLoglevel()
  {
    if (!System.hasProperty(system_prop_stdout_loglevel))
      return

    if (!(System.getProperty(system_prop_stdout_loglevel).toUpperCase() in ["TRACE", "DEBUG", "INFO"]))
      throw new DroidmateException("The $system_prop_stdout_loglevel environment variable has to be set to TRACE, " +
        "DEBUG or INFO. Instead, it is set to ${System.getProperty(system_prop_stdout_loglevel)}.")
  }


  private static void logDroidmateRunEnd(Date runStart, boolean runFinishedWithThrowablePropagatedToMain)
  {
    Date runEnd = new Date()
    TimeDuration runDuration = TimeCategory.minus(runEnd, runStart)
    String timestampFormat = "yyyy MMM dd HH:mm:ss"

    if (runFinishedWithThrowablePropagatedToMain)
      log.warn("DroidMate run finished, possibly prematurely, because an Exception or AssertionError " +
        "was propagated to main method. See previous logs for details on the Throwable.")
    else
      log.info("DroidMate run finished successfully.")

    log.info("Run finish timestamp: ${runEnd.format(timestampFormat)}. DroidMate ran for ${runDuration}.")
    log.info("By default, the results from the run can be found in ${Configuration.defaultDroidmateOutputDir}.")
    log.info("By default, for detailed diagnostics logs from the run, see $LogbackConstants.LOGS_DIR_PATH directory.")

    log.info(runData, "Run start  timestamp: ${runStart.format(timestampFormat)}")
    log.info(runData, "Run finish timestamp: ${runEnd.format(timestampFormat)}")
    log.info(runData, "DroidMate ran for: $runDuration")
  }

  private static void logException(Exception e)
  {
    log.error("Exception was thrown and propagated to the entry method (main).\n" +
      "The exception: $e\n$LogbackConstants.err_log_msg")

    log.error(exceptions, "Exception was thrown and propagated to the 'main' (program entry) method :\n", e)
  }

  private static void logAssertionError(AssertionError e)
  {
    log.error("AssertionError was thrown and propagated to the entry method (main). " +
      "Please contact the DroidMate developer, Konrad Jamrozik, at jamrozik@st.cs.uni-saarland.de. " +
      "Please include the output dir (by default set to ${Configuration.defaultDroidmateOutputDir}). " +
      "A cookie for you, brave human.\n" +
      "The error:\n$e")

    log.error(exceptions, "AssertionError was thrown and propagated to the 'main' (program entry) method :\n", e)
  }

  /**
   This method exists instead of being inlined to enable mocking in tests. It has to be mocked in tests that expect for
   this code to exit with failure code. Such tests should pass, but the abrupt termination caused by this method would
   cause them to fail.
   */
  protected static void systemExitWithErrorCode1()
  {
    System.exit(1)
  }


}
