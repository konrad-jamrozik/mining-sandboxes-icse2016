// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org
package org.droidmate.exploration

import groovy.util.logging.Slf4j
import org.droidmate.device.IAndroidDeviceExploration
import org.droidmate.exceptions.DeviceException
import org.droidmate.exceptions.TcpServerUnreachableException
import org.droidmate.logcat.MonitorConstants

import java.time.Duration
import java.time.LocalDateTime

/**
 * <p>
 * The device has different internal clock than the host machine. This class represents the time diff between the clocks.
 *
 * </p><p>
 * Use {@link DeviceTimeDiff#sync} on a device clock time to make it in sync with the host machine clock time.
 *
 * </p><p>
 * For example, if the device clock is 3 seconds into the future as compared to the host machine clock,
 * 3 seconds will be subtracted from the input {@code deviceTime}.
 *
 * </p>
 * @see DeviceMessagesReader
 */
@Slf4j
public class DeviceTimeDiff
{

  private final IAndroidDeviceExploration device

  Duration diff = null

  DeviceTimeDiff(IAndroidDeviceExploration device)
  {
    this.device = device
  }

  private void computeDiff(IAndroidDeviceExploration device) throws TcpServerUnreachableException, DeviceException
  {
    LocalDateTime deviceTime = device.getCurrentTime()
    LocalDateTime now = LocalDateTime.now()
    diff = Duration.between(now, deviceTime)
    log.trace(
      "Computed device time diff.\n" +
        "Current time   : ${now.format(MonitorConstants.monitorTimeFormatter)}\n" +
        "Device time    : ${deviceTime.format(MonitorConstants.monitorTimeFormatter)}\n" +
        "Resulting diff : ${diff.toString()}")
  }

  public LocalDateTime sync(LocalDateTime deviceTime) throws TcpServerUnreachableException, DeviceException
  {
    assert deviceTime != null

    if (diff == null)
      computeDiff(device)

    return safeSync(deviceTime)
  }

  public LocalDateTime safeSync(LocalDateTime deviceTime)
  {
    assert deviceTime != null
    assert diff != null

    return deviceTime.minus(diff)
  }
}
