// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org

package org.droidmate.exploration.datatypes

import groovy.transform.Canonical

import java.time.LocalDateTime

@Canonical
class TimestampedExplorationAction implements Serializable
{

  private static final long serialVersionUID = 1

  @Delegate
  ExplorationAction explorationAction

  LocalDateTime     timestamp

  static TimestampedExplorationAction from(ExplorationAction explorationAction, LocalDateTime timestamp)
  {
    return new TimestampedExplorationAction(explorationAction, timestamp)
  }


}

