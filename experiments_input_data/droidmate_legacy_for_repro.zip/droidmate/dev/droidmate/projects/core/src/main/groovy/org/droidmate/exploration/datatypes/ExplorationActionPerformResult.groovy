// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org
package org.droidmate.exploration.datatypes

import org.droidmate.device.datatypes.IDeviceGuiSnapshot
import org.droidmate.device.datatypes.MissingGuiSnapshot
import org.droidmate.exceptions.DroidmateException

class ExplorationActionPerformResult implements IExplorationActionPerformResult
{
  final boolean success
  final IDeviceGuiSnapshot snapshot
  final List<DroidmateException> exceptions

  ExplorationActionPerformResult(boolean success, List<DroidmateException> exceptions)
  {
    this(success, new MissingGuiSnapshot(), exceptions)
  }

  ExplorationActionPerformResult(boolean success, IDeviceGuiSnapshot snapshot, List<DroidmateException> exceptions)
  {
    this.success = success
    this.snapshot = snapshot
    this.exceptions = exceptions

    assert snapshot != null
    assert exceptions != null
  }

  @Override
  GuiState getGuiState()
  {
    if (!success)
      throw new UnsupportedOperationException()

    return snapshot.guiState
  }
}
