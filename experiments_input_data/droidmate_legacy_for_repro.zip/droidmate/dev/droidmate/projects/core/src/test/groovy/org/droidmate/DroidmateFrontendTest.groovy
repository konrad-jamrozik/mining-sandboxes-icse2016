// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org
package org.droidmate

import org.droidmate.device.DeviceGuiModelTestHelper
import org.droidmate.exploration.IDeviceGuiModel
import org.droidmate.exploration.datatypes.IApkExplorationOutput
import org.droidmate.frontend.DroidmateFrontend
import org.droidmate.frontend.configuration.Configuration
import org.droidmate.frontend.configuration.ConfigurationBuilder
import org.droidmate.init.InitConstants
import org.droidmate.logcat.IApiLogcatMessage
import org.droidmate.test.DroidmateOutputDir
import org.droidmate.test.MockDeviceToolsWithApkMetadataAndSimulator
import org.droidmate.test.MockFileSystemWithOneApk
import org.droidmate.test.suites.RequiresDevice
import org.junit.FixMethodOrder
import org.junit.Test
import org.junit.experimental.categories.Category
import org.junit.runner.RunWith
import org.junit.runners.JUnit4
import org.junit.runners.MethodSorters

import java.nio.file.FileSystem

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(JUnit4)
public class DroidmateFrontendTest extends GroovyTestCase
{

  /**
   * <p>
   * This test runs DroidMate against a device simulator. Because a device simulator is used, this test doesn't require a
   * device (real or emulated) to be available. Because no device is used, also no apk is necessary. Thus, the in-memory file
   * system is used with an apk stub, and an AaptWrapper mock is used to provide the apk stub metadata.
   * Also, the Storage is rewired to use the in-memory file system to prevent the exploration output from being
   * written out to file system.
   *
   * </p><p>
   * In summary, following classes are mocked:<br/>
   * - AaptWrapper, to return the apk stub metadata, like package name. Normally aapt would be called trying to access
   * non-existing apk (because there is only its stub, and in the in-memory file system);<br/>
   * - AdbWrapper, to prevent starting real adb server during device setup. It is not necessary: the test uses device
   * simulator;<br/>
   * - IAndroidDeviceFactory, to just return the device simulator;<br/>
   * - IAndroidDevice, which is replaced with the simulator.<br/>
   * </p>
   *
   */
  @Test
  public void "Explores a device simulator"()
  {
    def mockedFs = new MockFileSystemWithOneApk().fs
    def mocks = new MockDeviceToolsWithApkMetadataAndSimulator()
    def mockedDeviceTools = mocks.deviceTools
    def mockedSimulator = mocks.simulator

    DroidmateFrontend.fs = mockedFs
    DroidmateFrontend.deviceTools = mockedDeviceTools

    // Act
    DroidmateFrontend.main([Configuration.pn_randomSeed, 0] as String[])

    IDeviceGuiModel expectedGuiModel = mockedSimulator.simulatedGuiModel.guiModel
    IDeviceGuiModel actualGuiModel = getGuiModel(mockedFs)
    DeviceGuiModelTestHelper.assertEqual(actualGuiModel, expectedGuiModel)
  }

  private IDeviceGuiModel getGuiModel(FileSystem fs)
  {
    def outputDirPath = Configuration.getDefault(fs).droidmateOutputDirPath
    IApkExplorationOutput apkOut = new DroidmateOutputDir(outputDirPath).readOutput()
    def actualGuiModel = DeviceGuiModelTestHelper.from(apkOut)
    return actualGuiModel
  }

  /**
   * <p>
   * This tests runs DroidMate against a device (real or emulator) and deploys on it a monitored apk fixture. It assumes the apk
   * fixture with appropriate name will be present in the read apks dirs.
   *
   * </p><p>
   * This test also assumes the fixture will have two widgets to be clicked, and it will first click the first one,
   * then the second one, then terminate the exploration.
   *
   * </p><p>
   * The test will make DroidMate output results to {@code InitConstants.test_temp_dir_name}.
   * To ensure logs are also output there, run this test with VM arg of {@code -DlogsDir="temp_dir_for_tests/logs"}.
   * Note that {@code logsDir} is defined in {@code org.droidmate.common.logging.LogbackConstants.getLogsDirPath}.
   */
  @Category(RequiresDevice)
  @Test
  public void "Explores monitored apk on a real device"()
  {
    String[] args = [
      //@formatter:off
      Configuration.pn_useApkFixturesDir  , true,
      Configuration.pn_apksNames          , "[$InitConstants.monitored_inlined_apk_fixture_name]",
      Configuration.pn_widgetIndexes      , [0, 1],
      Configuration.pn_droidmateOutputDir , InitConstants.test_temp_dir_name,
      Configuration.pn_uiautomatorDaemonWaitForWindowUpdateTimeout  , "50",
      Configuration.pn_delayBetweenAttemptsToObtainValidGuiSnapshot , "0",
      Configuration.pn_delayAfterLaunchingActivity                  , "0"
      //@formatter:on
    ]

    DroidmateOutputDir outputDir = new DroidmateOutputDir(new ConfigurationBuilder().build(args).droidmateOutputDirPath)
    outputDir.clearContents()

    // Act
    DroidmateFrontend.main(args)

    IApkExplorationOutput apkOut = outputDir.readOutput()

    List<List<IApiLogcatMessage>> apiLogs = apkOut?.apiLogs

    assert apiLogs.size() == 4

    def resetAppApiLogs = apiLogs[0]
    def clickApiLogs = apiLogs[1]
    def launchActivity2Logs = apiLogs[2]
    def terminateAppApiLogs = apiLogs[3]

    assert resetAppApiLogs.empty
    assert clickApiLogs*.methodName == ["openConnection", "<init>"]
    assert launchActivity2Logs*.methodName == ["startActivityForResult"]
    assert terminateAppApiLogs.empty

  }

}
