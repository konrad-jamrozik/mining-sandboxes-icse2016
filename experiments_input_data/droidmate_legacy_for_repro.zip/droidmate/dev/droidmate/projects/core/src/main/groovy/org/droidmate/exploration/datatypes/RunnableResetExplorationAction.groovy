// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org
package org.droidmate.exploration.datatypes

import org.droidmate.device.IDeviceResult
import org.droidmate.device.IRobustAndroidDevice
import org.droidmate.device.datatypes.IDeviceGuiSnapshot
import org.droidmate.exceptions.DroidmateException
import org.droidmate.lowlevel.apk.IApk

import java.time.LocalDateTime

import static org.droidmate.device.datatypes.AndroidDeviceAction.*

class RunnableResetExplorationAction extends RunnableExplorationAction
{

  private static final long serialVersionUID = 1

  RunnableResetExplorationAction(ExplorationAction explorationAction, LocalDateTime timestamp)
  {
    super(explorationAction, timestamp)
  }

  @Override
  protected IExplorationActionPerformResult perform(IApk app, IRobustAndroidDevice device)
  {
    List<DroidmateException> exceptions = []

    IDeviceResult<Void> reset = device.perform(newResetPackageDeviceAction(app.packageName))
    if (!reset.success)
    {
      exceptions << new DroidmateException("!reset.success", reset.exception)
      return new ExplorationActionPerformResult(false, exceptions)
    }

    IDeviceResult<Void> turnWifiOn = device.perform(newTurnWifiOnDeviceAction())
    if (!turnWifiOn.success)
    {
      exceptions << new DroidmateException("!turnWifiOn.success", turnWifiOn.exception)
      return new ExplorationActionPerformResult(false, exceptions)
    }

    IDeviceResult<Void> launchActivity = device.perform(newLaunchActivityDeviceAction(app.launchableActivityComponentName))
    if (!launchActivity.success)
    {
      exceptions << new DroidmateException("!launchActivity.success", launchActivity.exception)
      return new ExplorationActionPerformResult(false, exceptions)
    }

    IDeviceResult<IDeviceGuiSnapshot> guiSnapshot = device.guiSnapshot
    if (!guiSnapshot.success)
    {
      exceptions << new DroidmateException("!guiSnapshot.success", guiSnapshot.exception)
      return new ExplorationActionPerformResult(false, exceptions)
    }

    return new ExplorationActionPerformResult(true, guiSnapshot.result, exceptions)
  }
}
