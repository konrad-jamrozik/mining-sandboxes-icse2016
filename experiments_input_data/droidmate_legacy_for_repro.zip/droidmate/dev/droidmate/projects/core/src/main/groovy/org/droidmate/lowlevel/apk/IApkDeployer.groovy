// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org

package org.droidmate.lowlevel.apk

import org.droidmate.device.IAndroidDeviceDeployment
import org.droidmate.exceptions.ApkDeploymentException
import org.droidmate.exceptions.ApkUndeploymentException

/**
 * @see ApkDeployer
 */
public interface IApkDeployer
{

  public void withDeployedApk(IAndroidDeviceDeployment device, Apk apk, Closure closure)
    throws ApkDeploymentException, ApkUndeploymentException
}
