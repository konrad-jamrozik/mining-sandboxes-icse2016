// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org

package org.droidmate.exceptions;

/** <p>
 * <i> --- This doc was last reviewed on 18 Dec 2013.</i>
 * </p><p>
 * Thrown when an attempt to communicate with A(V)D fails, NOT when the apk merely fails to be uninstalled!
 *
 * </p>
 * */
public class ApkUndeploymentException extends DroidmateException
{
  private static final long serialVersionUID = 1;

  public ApkUndeploymentException(Throwable cause)
  {
    super(cause);
  }
  public ApkUndeploymentException(String message, Throwable cause)
  {
    super(message, cause);
  }
}


