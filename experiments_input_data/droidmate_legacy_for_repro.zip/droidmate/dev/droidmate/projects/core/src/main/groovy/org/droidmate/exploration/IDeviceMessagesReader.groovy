// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org
package org.droidmate.exploration

import org.droidmate.exceptions.DeviceException
import org.droidmate.logcat.IApiLogcatMessage
import org.droidmate.logcat.ITimeFormattedLogcatMessage

import java.time.LocalDateTime

interface IDeviceMessagesReader
{

  LocalDateTime readMonitorMessages()

  List<ITimeFormattedLogcatMessage> readInstrumentationMessages()

  @SuppressWarnings("GroovyUnusedDeclaration") // Old implementation, left for reference as of 7 Aug 2015.
  List<IApiLogcatMessage> getCurrentApiLogsFromLogcat() throws DeviceException

  List<IApiLogcatMessage> getCurrentApiLogsFromMonitorTcpServer() throws DeviceException

}