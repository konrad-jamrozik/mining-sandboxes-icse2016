// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org
package org.droidmate.test

import org.droidmate.device.AndroidDeviceSimulator
import org.droidmate.device.AndroidDeviceSimulatorFuncTestHelper
import org.droidmate.exploration.DeviceTools
import org.droidmate.exploration.DeviceToolsTestHelper
import org.droidmate.frontend.configuration.Configuration

class MockDeviceToolsWithApkMetadataAndSimulator
{

  final DeviceTools            deviceTools
  final AndroidDeviceSimulator simulator

  MockDeviceToolsWithApkMetadataAndSimulator()
  {
    //noinspection GroovyAssignabilityCheck
    def (DeviceTools deviceTools, AndroidDeviceSimulator simulator) = build()
    this.deviceTools = deviceTools
    this.simulator = simulator

  }

  List build()
  {
    Configuration cfg = Configuration.default
    cfg.randomSeed = 0

    def pkgName = "mock_pkgname"
    List<String> aaptWrapperMetadata = [pkgName, "mock_launchActName", "mock_launchActCompName"]

    AndroidDeviceSimulator simulator = AndroidDeviceSimulatorFuncTestHelper.buildFromSpec(pkgName,
      // @formatter:off
      "s1-w12->s2 " +
      "s1-w13->s3 " +
      "s2-w22->s2 " +
      "s2-w2h->home")
      // @formatter:on

    return [DeviceToolsTestHelper.buildForTesting(cfg, aaptWrapperMetadata, simulator), simulator]
  }
}
