// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org

package org.droidmate.device

import groovy.transform.TypeChecked
import groovy.transform.TypeCheckingMode
import groovy.util.logging.Slf4j
import org.droidmate.common.logcat.TimeFormattedLogcatMessage
import org.droidmate.common.logging.LogbackConstants
import org.droidmate.common.logging.Markers
import org.droidmate.common_android.DeviceCommand
import org.droidmate.common_android.DeviceResponse
import org.droidmate.common_android.UiautomatorWindowHierarchyDumpDeviceResponse
import org.droidmate.device.datatypes.*
import org.droidmate.exceptions.DeviceException
import org.droidmate.exceptions.DroidmateException
import org.droidmate.exceptions.TcpServerUnreachableException
import org.droidmate.frontend.configuration.Configuration
import org.droidmate.logcat.ITimeFormattedLogcatMessage
import org.droidmate.logcat.MonitorConstants
import org.droidmate.lowlevel.androidsdk.IAdbWrapper
import org.droidmate.lowlevel.apk.IApk

import java.awt.*
import java.time.LocalDateTime
import java.util.List

import static org.droidmate.common.Utils.attempt
import static org.droidmate.common_android.Constants.*
import static org.droidmate.common_android.NoDeviceResponse.getNoDeviceResponse

/**
 * <p>
 * <i> --- This doc was last reviewed on 21 Dec 2013.</i>
 * </p><p>
 * Provides programmatic access to Android (Virtual) Device. The instance of this class should be available only as a parameter
 * in {@code closure} passed to
 * {@link org.droidmate.device.IAndroidDeviceDeployer#withSetupDevice(int, Closure)
 * AndroidDeviceDeployer.withSetupDevice(closure)}, thus guaranteeing invariant of this class:
 *
 * </p><p>
 * CLASS INVARIANT: the A(V)D accessed by a instance of this class is setup and available for duration of the instance existence.
 *
 * </p>
 */
@Slf4j
public class AndroidDevice implements IAndroidDevice
{

  private final String serialNumber

  private final Configuration                                         cfg
  private final ISerializableTCPClient<DeviceCommand, DeviceResponse> client
  private final IAdbWrapper                                           adbWrapper



  AndroidDevice(
    String serialNumber,
    Configuration cfg,
    ISerializableTCPClient<DeviceCommand, DeviceResponse> client,
    IAdbWrapper adbWrapper)
  {
    this.serialNumber = serialNumber
    this.cfg = cfg
    this.client = client
    this.adbWrapper = adbWrapper
  }

  @Override
  void forwardPort(int port)
  {
    log.trace("Forwarding port: ${port}")
    adbWrapper.forwardPort(serialNumber, port)
  }

  @Override
  void reverseForwardPort(int port) throws DroidmateException
  {
    log.trace("Reverse-forwarding port: ${port}")
    adbWrapper.reverseForwardPort(serialNumber, port)
  }

  @Override
  void pushJar(File jar)
  {
    log.trace("Pushing jar: ${jar.path}")
    adbWrapper.pushJar(serialNumber, jar)
  }

  @Override
  boolean hasPackageInstalled(String packageName) throws DeviceException
  {
    // KJA2 current work
    assert false: "Not yet implemented!"
  }

  @Override
  public IDeviceGuiSnapshot getGuiSnapshot() throws DeviceException
  {
    log.trace("Getting GUI snapshot")

    DeviceResponse response
    try
    {
      response = this.issueCommand(
        new DeviceCommand(DEVICE_COMMAND_GET_UIAUTOMATOR_WINDOW_HIERARCHY_DUMP)) as UiautomatorWindowHierarchyDumpDeviceResponse
    } catch (DeviceException e)
    {
      log.warn("Android device threw an exception instead of returning a GUI snapshot. Returning synthetic 'missing GUI snapshot'. $LogbackConstants.err_log_msg")
      log.error(Markers.exceptions, "Got exception instead of GUI snapshot:\n", e)

      return new MissingGuiSnapshot()
    }

    def outSnapshot = new UiautomatorWindowDump(response.windowHierarchyDump, new Dimension(response.displayWidth, response.displayHeight))
    // log.trace("Got GUI snapshot: $outSnapshot")
    return outSnapshot
  }

  @TypeChecked(TypeCheckingMode.SKIP)
  @Override
  void perform(IAndroidDeviceAction action) throws DeviceException
  {
    // log.trace("Performing action: $action")
    //noinspection GroovyInArgumentCheck
    assert action?.class in [ClickGuiAction, AdbClearPackageAction, LaunchMainActivityDeviceAction]

    //noinspection GroovyAssignabilityCheck
    internalPerform(action)
  }

  DeviceResponse internalPerform(LaunchMainActivityDeviceAction action) throws DeviceException
  {
    launchMainActivity(action.launchableActivityComponentName)
    return noDeviceResponse
  }

  DeviceResponse internalPerform(AdbClearPackageAction action) throws DeviceException
  {
    clearPackage(action.packageName)
    return noDeviceResponse
  }

  DeviceResponse internalPerform(ClickGuiAction action) throws DeviceException
  {
    return issueCommand(new DeviceCommand(DEVICE_COMMAND_PERFORM_ACTION, action.guiAction));
  }

  public DeviceResponse getIsDeviceOrientationLandscape() throws DroidmateException
  {
    return this.issueCommand(new DeviceCommand(DEVICE_COMMAND_GET_IS_ORIENTATION_LANDSCAPE));
  }

  /**
   * <p>
   * Issues given {@code deviceCommand} to the A(V)D, obtains the device answer, checks for errors and return the
   * device response, unless there were errors along the way. If there were errors, it throws an exception.
   * </p><p>
   * The issued command can be potentially handled either by aut-addon or uiautomator-daemon. This method resolves
   * who should be the recipient and sends the command using {@link #client}.
   *
   * </p><p>
   * <i>This doc was last reviewed on 14 Sep '13.</i>
   * </p>
   */
  private DeviceResponse issueCommand(DeviceCommand deviceCommand) throws DeviceException
  {
    DeviceResponse deviceResponse = null;

    boolean uiaDaemonHandlesCommand = uiaDaemonHandlesCommand(deviceCommand);

    if (!uiaDaemonHandlesCommand)
      throw new DeviceException(String.format("Unhandled command of %s", deviceCommand.command))

    deviceResponse = client.queryServer(deviceCommand, cfg.uiautomatorDaemonTcpPort)

    assert deviceResponse != null

    throwDeviceResponseThrowableIfAny(deviceResponse)

    assert deviceResponse.throwable == null

    return deviceResponse
  }

  private static void throwDeviceResponseThrowableIfAny(DeviceResponse deviceResponse) throws DeviceException
  {
    if (deviceResponse.throwable != null)
      throw new DeviceException(String.format(
        "Device returned DeviceResponse with non-null throwable, indicating something exploded on the A(V)D. The exception is " +
          "given as a cause of this one. If it doesn't have enough information, try inspecting the logcat output of the A(V)D.",
      ), deviceResponse.throwable)
  }

  @Override
  public void stopUiaDaemon() throws DeviceException
  {
    log.trace("Stopping uiautomator-daemon...")
    this.issueCommand(new DeviceCommand(DEVICE_COMMAND_STOP_UIADAEMON))
    adbWrapper.waitForUiaDaemonToClose()
    log.trace("DONE stopping uiautomator-daemon.")

  }

  @Override
  List<ITimeFormattedLogcatMessage> readLogcatMessages(String messageTag) throws DeviceException
  {
    def messages = adbWrapper.readMessagesFromLogcat(this.serialNumber, messageTag)
    return messages.collect {TimeFormattedLogcatMessage.from(it)}
  }

  private final ISerializableTCPClient<String, ArrayList<ArrayList<String>>> apiLogsClient = new SerializableTCPClient<>()

  @Override
  List<List<String>> readMonitorTcpMessages() throws TcpServerUnreachableException, DeviceException
  {

    // !!! DUPLICATION WARNING !!! of constant string with org.droidmate.lib_android.MonitorJavaTemplate.MonitorTCPServer.OnServerRequest
    ArrayList<ArrayList<String>> msgs = apiLogsClient.queryServer(MonitorConstants.MONITOR_SRV_COMMAND_GET_LOGS, cfg.monitorTcpPort)

    msgs.each {ArrayList<String> msg ->
      assert msg.size() == 3
      assert !(msg[0]?.empty)
      assert !(msg[1]?.empty)
      assert !(msg[2]?.empty)
    }

    return msgs
  }

  @Override
  LocalDateTime getCurrentTime() throws TcpServerUnreachableException, DeviceException
  {
    List<List<String>> msgs = apiLogsClient.queryServer(MonitorConstants.MONITOR_SRV_COMMAND_GET_TIME, cfg.monitorTcpPort)

    assert msgs.size() == 1
    assert msgs[0].size() == 3
    assert !(msgs[0][0]?.empty)
    assert msgs[0][1] == null
    assert msgs[0][2] == null

    return LocalDateTime.parse(msgs[0][0], MonitorConstants.monitorTimeFormatter)

  }

  @Override
  void startUiaDaemon() throws DeviceException
  {
    adbWrapper.startUiaDaemon(serialNumber)
  }

  @Override
  void clearLogcat() throws DeviceException
  {
    adbWrapper.clearLogcat(serialNumber)
  }

  @Override
  boolean readMonitorServerStartMsg()
  {
    return adbWrapper.waitForMessageOnLogcat(
      serialNumber,
      MONITOR_SERVER_START_TAG,
      MONITOR_SERVER_START_MSG,
      cfg.monitorServerStartTimeout,
      cfg.monitorServerStartQueryInterval
    )
  }

  @Override
  void installApk(IApk apk) throws DeviceException
  {
    adbWrapper.installApk(serialNumber, apk)
  }

  @Override
  void uninstallApk(String apkPackageName, boolean warnAboutFailure) throws DeviceException
  {
    adbWrapper.uninstallApk(serialNumber, apkPackageName, /* warnAboutFailure  = */ false)
  }

  void launchMainActivity(String launchableActivityComponentName) throws DeviceException
  {
    adbWrapper.launchMainActivity(serialNumber, launchableActivityComponentName)
    sleep(cfg.delayAfterLaunchingActivity)
  }

  @Override
  void clearPackage(String apkPackageName) throws DeviceException
  {
    // KJA2 the attempts should be moved to RobustAndroidDevice
    attempt(5, log, "adbWrapper.clearPackage()", {
      adbWrapper.clearPackage(serialNumber, apkPackageName)
    })
  }

  @Override
  void removeJar(File jar) throws DeviceException
  {
    adbWrapper.removeJar(serialNumber, cfg.uiautomatorDaemonJar)

  }

  private static boolean uiaDaemonHandlesCommand(DeviceCommand deviceCommand)
  {
    return deviceCommand.command in [
      DEVICE_COMMAND_PERFORM_ACTION,
      DEVICE_COMMAND_STOP_UIADAEMON,
      DEVICE_COMMAND_GET_UIAUTOMATOR_WINDOW_HIERARCHY_DUMP,
      DEVICE_COMMAND_GET_IS_ORIENTATION_LANDSCAPE
    ]
  }


  @Override
  public String toString()
  {
    return "AndroidDevice{" +
      "serialNumber='" + serialNumber + '\'' +
      '}'
  }

}
