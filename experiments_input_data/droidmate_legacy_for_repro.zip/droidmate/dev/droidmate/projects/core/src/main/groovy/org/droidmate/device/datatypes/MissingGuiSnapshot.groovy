// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org

package org.droidmate.device.datatypes

import org.droidmate.exploration.datatypes.GuiState

// WISH throw UnuspportedOperationException everywhere
class MissingGuiSnapshot implements IDeviceGuiSnapshot, Serializable
{
  private static final long serialVersionUID = 1

  public static final String pkgNameMissingGuiSnapshot = "missing.gui.snapshot.pkgname"

  MissingGuiSnapshot()
  {
  }

  @Override
  String getWindowHierarchyDump()
  {
    return "missing-gui-snapshot/get-window-hierarchy-dump"
  }

  @Override
  String getPackageName()
  {
    pkgNameMissingGuiSnapshot
  }

  @Override
  GuiState getGuiState()
  {
    new GuiState(pkgNameMissingGuiSnapshot, [])
  }

  @Override
  UiautomatorWindowDump.ValidationResult validate()
  {
    UiautomatorWindowDump.ValidationResult.OK
  }


  @Override
  public String toString()
  {
    return "missing-gui-snapshot/to-string"
  }
}
