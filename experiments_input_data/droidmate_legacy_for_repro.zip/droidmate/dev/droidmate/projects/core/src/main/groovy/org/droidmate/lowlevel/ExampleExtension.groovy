// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org

package org.droidmate.lowlevel
/**
 * This class is not used in DroidMate. I didn't deleted it because configuring gradle and IntelliJ to work with
 * groovy extension classes is nontrivial, and this class codifies that knowledge.
 *
 * -----
 *
 * For this to be recognizable by IDEA, following has to be setup:
 * In IDEA: project structure -> modules -> <this module> -> dependencies
 * -> Add a "folder" entry with name "groovyExtension" having in it:
 *
 *   ./META-INF/services/org.codehaus.groovy.runtime.ExtensionModule
 * whose contents are:
 *
 *   moduleName = example-module
 *   moduleVersion = 1.0
 *   extensionClasses = org.droidmate.services.utils.ExampleExtensions
 *
 * Reference: http://docs.codehaus.org/display/GROOVY/Creating+an+extension+module
 *
 * -----
 *
 * For this to be recognizable by gradle:
 *
 *   project(":projects:core") {
 *     dependencies {
 *        runtime files(new File(sourceSets.main.resources.srcDirs.find(), "groovyExtensions"));
 *
 * This will ensure the above mentioned folder is copied to the build folder and thus, available by the application at
 * runtime.
 * Reference: http://java.dzone.com/articles/groovy-goodness-adding-extra
 *
 */
@SuppressWarnings("GroovyUnusedDeclaration")
class ExampleExtensions
{
  static String likeAPirate(final String self) {
    // List of pirate language translations.
    def translations = [
      ["hello", "ahoy"], ["Hi", "Yo-ho-ho"],
      ['are', 'be'], ['am', 'be'], ['is', 'be'],
      ['the', "th'"], ['you', 'ye'], ['your', 'yer'],
      ['of', "o'"]
    ]

    // Translate the original String to a
    // pirate language String.
    String result = self
    translations.each { translate ->
      result = result.replaceAll(translate[0], translate[1])
    }
    result
  }
}