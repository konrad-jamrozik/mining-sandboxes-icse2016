// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org

package org.droidmate.device

import groovy.util.logging.Slf4j
import org.droidmate.common.Assert
import org.droidmate.common_android.Constants
import org.droidmate.exceptions.AndroidDeviceException
import org.droidmate.exceptions.DeviceException
import org.droidmate.exceptions.DroidmateException
import org.droidmate.frontend.configuration.Configuration
import org.droidmate.lowlevel.androidsdk.AndroidDeviceDescriptor
import org.droidmate.lowlevel.androidsdk.IAdbWrapper

@Slf4j

public class AndroidDeviceDeployer implements IAndroidDeviceDeployer
{

  private final Configuration         cfg
  private final IAdbWrapper           adbWrapper
  private final IAndroidDeviceFactory deviceFactory

  /**
   * <p>
   * <i> --- This doc was last reviewed on 21 Dec 2013.</i>
   * </p><p>
   * Determines if the device accessed through this class is currently setup. The value of this field is modified
   * by {@link #setUp(IAndroidDeviceDeployment)}  and {@link #tearDown(IAndroidDeviceDeployment)}.
   *
   * </p><p>
   * Useful to be tested for in preconditions requiring for the device to be set-up.
   *
   */
  private boolean deviceIsSetup

  // To make DroidMate work with multiple A(V)D, this list will have to be one for all AndroidDeviceDeployer-s, not one per inst.
  private List<String> usedSerialNumbers = [] as List<String>


  public AndroidDeviceDeployer(Configuration cfg, IAdbWrapper adbWrapper, IAndroidDeviceFactory deviceFactory)
  {
    this.cfg = cfg
    this.adbWrapper = adbWrapper
    this.deviceFactory = deviceFactory
  }

/**
 * <p>
 * <i> --- This doc was last reviewed on 21 Dec 2013.</i>
 * </p><p>
 *
 * Setups the A(V)D to be usable by DroidMate. Should be called only from {@link org.droidmate.device.IAndroidDeviceDeployer#withSetupDevice(int, Closure)}.
 * </p><p>
 *
 * The setup encompasses following steps, all conducted using {@link #adbWrapper},
 * in order:<br/>
 * - the adb server is started, if necessary;<br/>
 * - the A(V)D to be used is chosen from  all the available A(V)Ds;<br/>
 * - ports for aut-addon and uiautomator-daemon TCP servers are forwarded, to enable communication between the A(V)D and
 * DroidMate;<br/>
 * - uiautomator-daemon jar is pushed to the device and started.<br/>
 *
 * </p><p>
 * As a last step, the method sets {@link #deviceIsSetup} to {@code true}.
 *
 * </p>
 *
 * @see #tearDown(IAndroidDeviceDeployment)
 */
  protected void setUp(IAndroidDeviceDeployment device) throws DroidmateException
  {

    adbWrapper.startAdbServer()

    // WISH update docs based on observation: WorldWritableDir unnecessary, just push monitor.apk to /data/local/tmp

    device.forwardPort(cfg.uiautomatorDaemonTcpPort)
    device.forwardPort(Constants.MONITOR_SERVER_PORT)

    log.info("Pushing ui-automator daemon .jar to the device.")
    device.pushJar(cfg.uiautomatorDaemonJar)

    log.info("Pushing monitor.jar to the device.")
    device.pushJar(cfg.monitorApk)

    device.startUiaDaemon()

    deviceIsSetup = true
  }

  /**
   * <p>
   * <i> --- This doc was last reviewed on 21 Dec 2013.</i>
   * </p><p>
   * Stops the uiautomator-daemon and removes its jar from the A(V)D. Should be called only from
   * {@link org.droidmate.device.IAndroidDeviceDeployer#withSetupDevice(int, Closure)}.
   *
   * </p><p>
   * As a first step, the method sets {@link #deviceIsSetup} to {@code true}.
   *
   * </p>
   *
   * @see #setUp(IAndroidDeviceDeployment)
   */
  protected void tearDown(IAndroidDeviceDeployment device) throws DroidmateException
  {
    assert device != null

    deviceIsSetup = false
    device.stopUiaDaemon()
    device.removeJar(cfg.uiautomatorDaemonJar)
    device.removeJar(cfg.monitorApk)
  }

  /**
   * <p>
   * <i> --- This doc was last reviewed on 21 Dec 2013.</i>
   * </p><p>
   * Setups the A(V)D, executes the {@code closure} and tears down the device.
   * </p>
   *
   * @see #setUp(IAndroidDeviceDeployment)
   * @see #tearDown(IAndroidDeviceDeployment)
   */
  @Override
  public void withSetupDevice(int deviceIndex, Closure computation) throws DeviceException
  {
    log.info("Setting up Android (Virtual) Device.");

    Assert.checkClosureFirstParameterSignature(computation, IAndroidDevice)

    String serialNumber = resolveSerialNumber(adbWrapper, usedSerialNumbers, deviceIndex)

    usedSerialNumbers << serialNumber

    IAndroidDevice device = deviceFactory.create(serialNumber)

    // KJA2 clean up this exception handling mess
    try
    {
      setUp(device)
    } catch (Exception e)
    {
      throw new DeviceException("Failed setting up A(V)D.", e);
    }

    try
    {
      computation(device)
    } catch (Exception e)
    {
      log.error("The closure operating on android device threw ${e.class.simpleName}. The exception will be now rethrown and " +
        "in the 'finally' block the device will be torn down.")
      throw e

    } finally
    {
      try
      {
        tearDown(device)
        usedSerialNumbers -= serialNumber
      } catch (Exception e)
      {
        throw new AndroidDeviceException("Failed tearing down A(V)D. " +
          "Be warned: this exception suppresses exception from executing the closure operating on the device, " +
          "if such exception occurred. Appropriate error message was logged if such exception indeed occurred.", e);
      }
    }
  }

  private static String resolveSerialNumber(IAdbWrapper adbWrapper, List<String> usedSerialNumbers, int deviceIndex)
  {
    List<AndroidDeviceDescriptor> devicesDescriptors = adbWrapper.getAndroidDevicesDescriptors()
    String serialNumber = getSerialNumber(devicesDescriptors, usedSerialNumbers, deviceIndex)
    return serialNumber

  }

  static String getSerialNumber(List<AndroidDeviceDescriptor> deviceDescriptors, List<String> usedSerialNumbers, int deviceIndex)
  {
    log.trace("Serial numbers of found android devices:")
    assert deviceDescriptors?.size() > 0
    deviceDescriptors.each {AndroidDeviceDescriptor add -> log.trace(add.deviceSerialNumber)}

    List<String> unrecognizedNumbers = usedSerialNumbers.minus(deviceDescriptors*.deviceSerialNumber)
    if (unrecognizedNumbers.size() > 0)
      throw new DroidmateException("While obtaining new A(V)D serial number, DroidMate detected that one or more of the " +
        "already used serial numbers do not appear on the list of serial numbers returned by the 'adb devices' command. " +
        "This indicates the device(s) with these number most likely have been disconnected. Thus, DroidMate throws exception. " +
        "List of the offending serial numbers: $unrecognizedNumbers");

    def unusedDescriptors = deviceDescriptors.findAll {AndroidDeviceDescriptor add ->
      !(add.deviceSerialNumber in usedSerialNumbers)
    }

    if (unusedDescriptors.size() == 0)
      throw new DroidmateException("No unused A(V)D serial numbers have been found. List of all already used serial numbers: " +
        "$usedSerialNumbers")

    if (unusedDescriptors.size() < deviceIndex + 1)
      throw new DroidmateException("Requested device with device no. ${deviceIndex + 1} but the no. of available devices is ${unusedDescriptors.size()}.")

    String serialNumber;
    serialNumber = unusedDescriptors.findAll {AndroidDeviceDescriptor add -> !add.isEmulator}[deviceIndex]?.deviceSerialNumber
    if (serialNumber == null)
      serialNumber = unusedDescriptors.findAll {AndroidDeviceDescriptor add -> add.isEmulator}[deviceIndex]?.deviceSerialNumber

    assert serialNumber != null
    return serialNumber
  }

}
