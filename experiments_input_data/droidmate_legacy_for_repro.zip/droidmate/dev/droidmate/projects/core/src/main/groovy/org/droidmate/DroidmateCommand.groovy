// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org
package org.droidmate

import groovy.util.logging.Slf4j
import org.droidmate.exploration.DeviceTools
import org.droidmate.exploration.ExplorationExecutor
import org.droidmate.exploration.ExplorationOutputCollectorFactory
import org.droidmate.exploration.output.ExplorationOutputDataExtractor
import org.droidmate.exploration.output.ExplorationOutputDataPersister
import org.droidmate.frontend.configuration.Configuration
import org.droidmate.lowlevel.TimeProvider
import org.droidmate.lowlevel.apk.ApksProvider
import org.droidmate.lowlevel.filesystem.Storage
import org.droidmate.utils.UiaTestCaseLogsProcessor

@Slf4j
abstract class DroidmateCommand
{

  abstract void execute(Configuration cfg)

  public static DroidmateCommand build(
    boolean processUiaTestCasesLogs, boolean extractDataFromPreviousRun, Configuration cfg, DeviceTools deviceTools)
  {
    assert !(processUiaTestCasesLogs && extractDataFromPreviousRun)

    if (processUiaTestCasesLogs)
      return buildProcessUiaTestCasesLogsCommand(cfg)
    else if (extractDataFromPreviousRun)
      return buildExtractDataFromPreviousRunsCommand(cfg)
    else
      return buildExploreCommand(cfg, deviceTools)
  }

  static ProcessUiaTestCasesLogsCommand buildProcessUiaTestCasesLogsCommand(Configuration cfg)
  {
    def timeProvider = new TimeProvider()
    def storage = new Storage(cfg.droidmateOutputDirPath)
    def processor = new UiaTestCaseLogsProcessor(new ExplorationOutputCollectorFactory(timeProvider, storage))

    def extractor = new ExplorationOutputDataExtractor(cfg.compareRuns, cfg)
    def persister = new ExplorationOutputDataPersister(cfg, extractor, storage)

    return new ProcessUiaTestCasesLogsCommand(processor, storage, persister)
  }

  static ExtractDataFromPreviousRunCommand buildExtractDataFromPreviousRunsCommand(Configuration cfg)
  {
    def storage = new Storage(cfg.droidmateOutputDirPath)

    def extractor = new ExplorationOutputDataExtractor(cfg.compareRuns, cfg)
    def persister = new ExplorationOutputDataPersister(cfg, extractor, storage)

    return new ExtractDataFromPreviousRunCommand(storage, persister)
  }

  private static ExploreCommand buildExploreCommand(Configuration cfg, DeviceTools deviceTools)
  {
    def storage = new Storage(cfg.droidmateOutputDirPath)
    ExplorationExecutor executor = ExplorationExecutor.build(cfg, storage)

    def apksProvider = new ApksProvider(deviceTools.aapt)
    def extractor = new ExplorationOutputDataExtractor(cfg.compareRuns, cfg)
    def persister = new ExplorationOutputDataPersister(cfg, extractor, storage)

    return new ExploreCommand(apksProvider, deviceTools.deviceDeployer, deviceTools.apkDeployer, executor, persister)
  }

}
