// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org

package org.droidmate.exploration

import groovy.transform.TypeChecked
import groovy.util.logging.Slf4j
import org.droidmate.common.logcat.ApiLogcatMessage
import org.droidmate.common.logcat.TimeFormattedLogcatMessage
import org.droidmate.common.logging.LogbackConstants
import org.droidmate.common_android.Constants
import org.droidmate.device.IAndroidDeviceExploration
import org.droidmate.exceptions.DeviceException
import org.droidmate.exceptions.TcpServerUnreachableException
import org.droidmate.logcat.IApiLogcatMessage
import org.droidmate.logcat.ITimeFormattedLogcatMessage
import org.droidmate.logcat.MonitorConstants
import org.slf4j.Logger
import org.slf4j.LoggerFactory

import java.time.LocalDateTime

/**
 * See {@link DeviceMessagesReader}
 */

@TypeChecked
@Slf4j
class ApiLogsReader implements IApiLogsReader
{

  private final boolean                   deployRawApks
  private final IAndroidDeviceExploration device


  ApiLogsReader(boolean deployRawApks,
                IAndroidDeviceExploration device)
  {
    this.deployRawApks = deployRawApks
    this.device = device
  }

  private Logger monitorLogger = LoggerFactory.getLogger(LogbackConstants.logger_name_monitor)

  @Override
  List<IApiLogcatMessage> getCurrentApiLogsFromLogcat(DeviceTimeDiff deviceTimeDiff) throws DeviceException
  {
    return readApiLogcatMessages(this.&getMessagesFromLogcat.curry(deviceTimeDiff))
  }

  @Override
  List<IApiLogcatMessage> getCurrentApiLogsFromMonitorTcpServer(DeviceTimeDiff deviceTimeDiff) throws TcpServerUnreachableException, DeviceException
  {
    return readApiLogcatMessages(this.&getMessagesFromMonitorTcpServer.curry(deviceTimeDiff))
  }

  List<IApiLogcatMessage> readApiLogcatMessages(Closure<List<ITimeFormattedLogcatMessage>> messagesProvider) throws DeviceException
  {
    List<ITimeFormattedLogcatMessage> messages = messagesProvider.call()

    messages.each {monitorLogger.trace("${it.toLogcatMessage()}")}

    List<ApiLogcatMessage> apiLogs = messages.collect {ApiLogcatMessage.from(it)}

    if (apiLogs.size() > 0 && deployRawApks)
    // WISH this should throw "stop exploration of all apks" exception
      throw new DeviceException("API logs have been obtained from logcat, even though DroidMate was instructed to deploy raw (non-monitored) apks.")

    assert apiLogs == apiLogs.collect().sort {it.time}

    log.debug("Current API logs read count: ${apiLogs.size()}")

    return apiLogs
  }

  List<ITimeFormattedLogcatMessage> getMessagesFromLogcat(DeviceTimeDiff deviceTimeDiff) throws DeviceException
  {
    def messages = device.readLogcatMessages(Constants.instrumentation_apiMethodCallLogcatTag)

    messages = messages.collect {
      TimeFormattedLogcatMessage.from(
        deviceTimeDiff.safeSync(it.time),
        it.level, it.tag, it.pidString, it.messagePayload)
    }
    return messages
  }

  List<ITimeFormattedLogcatMessage> getMessagesFromMonitorTcpServer(DeviceTimeDiff deviceTimeDiff) throws TcpServerUnreachableException, DeviceException
  {
    List<List<String>> messages = []
    try
    {
      messages = device.readMonitorTcpMessages()

    } catch (TcpServerUnreachableException ignored)
    {
      log.trace("Read no API logs: monitor TCP server unreachable. Returning empty list.")
    }

    return extractLogcatMessagesFromTcpMessages(messages, deviceTimeDiff)
  }

  private List<ITimeFormattedLogcatMessage> extractLogcatMessagesFromTcpMessages(List<List<String>> messages, DeviceTimeDiff deviceTimeDiff)
  {
    return messages.collect {List<String> msg ->

      String pid = msg[0]
      // KNOWN BUG: got in msg[1] '2015-0008-05 09:24:12.163' resulting in: java.time.format.DateTimeParseException: Text '2015-0008-05 09:24:12.163' could not be parsed at index 7
      LocalDateTime deviceTime = LocalDateTime.parse(msg[1], MonitorConstants.monitorTimeFormatter)
      LocalDateTime deviceTimeSyncedToHostTime = deviceTimeDiff.safeSync(deviceTime)
      String payload = msg[2]

      TimeFormattedLogcatMessage.from(
        deviceTimeSyncedToHostTime,
        MonitorConstants.log_level,
        "Adapted_" + MonitorConstants.tag_monitor_api,
        pid,
        payload)
    }
  }
}
