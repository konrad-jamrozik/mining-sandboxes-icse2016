// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org

package org.droidmate.lowlevel.filesystem

import org.droidmate.exploration.datatypes.ExplorationOutput
import org.droidmate.exploration.datatypes.IApkExplorationOutput

import java.nio.file.Path

/**
 * See {@link Storage}
 */
public interface IStorage
{
  Writer getWriter(String targetName)

  void delete(String deletionTargetNameSuffix)

  void serialize(IApkExplorationOutput apkExplorationOutput)
  void serialize(IApkExplorationOutput apkExplorationOutput, String nameSuffix)
  void serialize(ExplorationOutput explorationOutput)
  ExplorationOutput deserializeAll()

  Collection<Path> getSerializedRuns()

  IApkExplorationOutput deserializeApkExplorationOutput(Path serPath)

  void deleteEmpty()
}