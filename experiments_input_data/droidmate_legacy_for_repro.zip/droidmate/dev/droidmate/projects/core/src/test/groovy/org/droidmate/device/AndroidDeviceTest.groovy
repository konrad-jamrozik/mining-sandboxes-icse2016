// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org

package org.droidmate.device

import groovy.transform.TypeChecked
import org.droidmate.exploration.DeviceTools
import org.droidmate.frontend.configuration.Configuration
import org.droidmate.frontend.configuration.ConfigurationBuilder
import org.droidmate.init.InitConstants
import org.droidmate.lowlevel.apk.Apk
import org.droidmate.lowlevel.apk.ApksProvider
import org.droidmate.test.DroidmateGroovyTestCase
import org.droidmate.test.suites.RequiresDevice
import org.junit.FixMethodOrder
import org.junit.Test
import org.junit.experimental.categories.Category
import org.junit.runner.RunWith
import org.junit.runners.JUnit4
import org.junit.runners.MethodSorters

import static org.droidmate.device.datatypes.AndroidDeviceAction.*

@TypeChecked
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(JUnit4)
class AndroidDeviceTest extends DroidmateGroovyTestCase
{
  @Category(RequiresDevice)
  @Test
  void "Performs 'launch main activity', 'click widget' and 'reset package' actions on the device"()
  {
    String[] args = [
      //@formatter:off
      Configuration.pn_useApkFixturesDir  , true,
      Configuration.pn_apksNames          , "[$InitConstants.monitored_inlined_apk_fixture_name]",
      Configuration.pn_uiautomatorDaemonWaitForWindowUpdateTimeout  , "50",
      Configuration.pn_delayBetweenAttemptsToObtainValidGuiSnapshot , "0",
      Configuration.pn_delayAfterLaunchingActivity                  , "0"
      //@formatter:on
    ]

    Configuration cfg = new ConfigurationBuilder().build(args)
    DeviceTools deviceTools = new DeviceTools(cfg)

    ApksProvider apksProvider = new ApksProvider(deviceTools.aapt)
    Apk apk = apksProvider.getApks(cfg.apksDirFuncPath, cfg.apksLimit, cfg.apksNames).first()

    deviceTools.deviceDeployer.withSetupDevice(0) {IAndroidDevice device ->
      deviceTools.apkDeployer.withDeployedApk(device, apk) {Apk deployedApk ->

        // Act 1
        device.perform(newLaunchActivityDeviceAction(deployedApk.launchableActivityComponentName))
        assert device.guiSnapshot.guiState.belongsToApp(deployedApk.packageName)

        // Act 2
        device.perform(newClickGuiDeviceAction(100, 100))
        assert device.guiSnapshot.guiState.belongsToApp(deployedApk.packageName)

        // Act 3
        device.perform(newResetPackageDeviceAction(deployedApk.packageName))
        assert device.guiSnapshot.guiState.isHomeScreen()
      }
    }
  }
}
