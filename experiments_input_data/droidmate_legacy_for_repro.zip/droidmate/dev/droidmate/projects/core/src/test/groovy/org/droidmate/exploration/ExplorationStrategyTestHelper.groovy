// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org

package org.droidmate.exploration

import org.droidmate.frontend.configuration.Configuration
import org.droidmate.frontend.configuration.ConfigurationBuilder
import org.droidmate.lowlevel.TimeProvider
import org.droidmate.lowlevel.filesystem.Storage

class ExplorationStrategyTestHelper
{
  static IExplorationStrategy buildStrategy(
    String pkgName, Integer actionsLimit, Integer resetEveryNthExplorationForward)
  {

    String[] args = [
      //@formatter:off
      Configuration.pn_actionsLimit                                 ,  actionsLimit,
      Configuration.pn_resetEveryNthExplorationForward              ,  resetEveryNthExplorationForward,
      Configuration.pn_uiautomatorDaemonWaitForWindowUpdateTimeout  , "50",
      Configuration.pn_delayBetweenAttemptsToObtainValidGuiSnapshot , "0",
      Configuration.pn_delayAfterLaunchingActivity                  , "0"

      //@formatter:on
    ]

    Configuration cfg = new ConfigurationBuilder().build(args)
    def factory = ExplorationComponentsFactory.build(cfg, new TimeProvider(), new Storage(cfg.droidmateOutputDirPath))
    IExplorationStrategy strategy = factory.createStrategy(pkgName)
    return strategy

  }
}
