// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org
package org.droidmate.device

import org.droidmate.device.datatypes.IAndroidDeviceAction
import org.droidmate.device.datatypes.IDeviceGuiSnapshot
import org.droidmate.exceptions.DeviceException

class RobustAndroidDevice implements IRobustAndroidDevice
{

  private final IAndroidDevice device

  RobustAndroidDevice(IAndroidDevice device)
  {
    this.device = device
  }

  @Override
  IDeviceResult<Boolean> hasPackageInstalled(String packageName)
  {
    wrapInDeviceResult(device.&hasPackageInstalled.curry(packageName))
  }

  @Override
  IDeviceResult<IDeviceGuiSnapshot> getGuiSnapshot()
  {
    IDeviceResult<IDeviceGuiSnapshot> guiSnapshot = wrapInDeviceResult(device.&getGuiSnapshot)
    return guiSnapshot
  }

  @Override
  IDeviceResult<Void> perform(IAndroidDeviceAction action)
  {
    IDeviceResult<Void> noResult = wrapInDeviceResult(device.&perform.curry(action))
    return noResult
  }

  private <T> IDeviceResult<T> wrapInDeviceResult(Closure<T> computation)
  {
    T result
    try
    {
      result = computation()
      return new DeviceResultSuccess<T>(result)
    } catch (DeviceException e)
    {
      return new DeviceResultFailure<T>(e)
    }
  }
}
