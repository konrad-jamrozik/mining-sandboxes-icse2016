// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org
package org.droidmate.device

import org.droidmate.test.DroidmateGroovyTestCase

public class AndroidDeviceSimulatorFuncTestHelper
{

  static AndroidDeviceSimulator buildFromSpec(String packageName = DroidmateGroovyTestCase.apkFixture_simple_packageName, String spec = "s1-w1->s1")
  {
    new AndroidDeviceSimulator(packageName, spec)
  }


}
