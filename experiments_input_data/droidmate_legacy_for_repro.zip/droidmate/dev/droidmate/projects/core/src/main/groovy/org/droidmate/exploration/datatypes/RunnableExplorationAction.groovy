// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org
package org.droidmate.exploration.datatypes

import groovy.transform.Canonical
import org.droidmate.device.IRobustAndroidDevice
import org.droidmate.exceptions.UnexpectedIfElseFallthroughError
import org.droidmate.exploration.DeviceLogs
import org.droidmate.lowlevel.apk.IApk

import java.time.LocalDateTime

@Canonical
abstract class RunnableExplorationAction implements IRunnableExplorationAction, Serializable
{

  private static final long serialVersionUID = 1

  @Delegate
  ExplorationAction explorationAction

  LocalDateTime timestamp

  static RunnableExplorationAction from(ExplorationAction action, LocalDateTime timestamp)
  {
    switch (action.class)
    {
      case ResetAppExplorationAction:
        return new RunnableResetExplorationAction(action, timestamp)
        break

      default:
        throw new UnexpectedIfElseFallthroughError("Unhandled ExplorationAction class. The class: ${action.class}")
    }
  }

  public IExplorationActionRunResult run(IApk app, IRobustAndroidDevice device)
  {
    IExplorationActionPerformResult result = this.perform(app, device)

    DeviceLogs logs = new DeviceLogs(device)

    return new ExplorationActionRunResult(result, logs)
  }

  protected abstract IExplorationActionPerformResult perform(IApk app, IRobustAndroidDevice device)

}
