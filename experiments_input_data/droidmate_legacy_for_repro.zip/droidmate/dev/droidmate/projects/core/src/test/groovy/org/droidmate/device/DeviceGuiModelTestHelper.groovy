// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org
package org.droidmate.device

import org.droidmate.device.datatypes.IDeviceGuiSnapshot
import org.droidmate.exceptions.UnexpectedIfElseFallthroughError
import org.droidmate.exploration.DeviceGuiModel
import org.droidmate.exploration.IDeviceGuiModel
import org.droidmate.exploration.datatypes.*

class DeviceGuiModelTestHelper
{

  static IDeviceGuiModel from(IApkExplorationOutput output)
  {
    def homeGuiState = GuiStateTestHelper.newHomeScreenGuiState()

    def resetActionIndex = output.actions.findIndexOf {it.explorationAction instanceof ResetAppExplorationAction}
    assert resetActionIndex == 0
    def launchGuiState = output.guiSnapshots[resetActionIndex].guiState

    def guiModel = DeviceGuiModel.build(homeGuiState, launchGuiState, [], [])

    output.actions.eachWithIndex {TimestampedExplorationAction action, int i ->

      ExplorationAction explAction = action.explorationAction
      IDeviceGuiSnapshot guiSnapshot = output.guiSnapshots[i]

      switch (explAction.class)
      {
        case ResetAppExplorationAction:
          // Do nothing
          break

        case WidgetExplorationAction:
        case EnterTextExplorationAction:
          assert i > 0
          IDeviceGuiSnapshot prevGuiSnapshot = output.guiSnapshots[i - 1]
          guiModel.addTransition(prevGuiSnapshot.guiState, explAction, guiSnapshot.guiState)
          break

        case TerminateExplorationAction:
          assert i == output.actions.size() - 1
          // No transition is added to the GUI model.
          break

        default:
          new UnexpectedIfElseFallthroughError(
            "Unsupported ExplorationAction class while extracting GUI model transition from IApkExplorationOutput. " +
              "The unsupported class: ${explAction.class}")
      }

    }
    return guiModel
  }

  static void assertEqual(IDeviceGuiModel actual, IDeviceGuiModel expected)
  {
    int actualGuiStatesCount = actual.guiStates.size()
    int expectedGuiStatesCount = expected.guiStates.size()

    if (actualGuiStatesCount > expectedGuiStatesCount)
      assert false: "Actual GUI model has more GUI states than expected.\n" +
        "Actual GUI model GUI states: $actualGuiStatesCount.\n" +
        "Expected GUI model GUI states: $expectedGuiStatesCount.\n" +
        "The first actual GUI state not present in the expected model: ${actual.guiStates[expectedGuiStatesCount]}"

    if (actualGuiStatesCount < expectedGuiStatesCount)
      assert false: "Actual GUI model has less GUI states than expected.\n" +
        "Actual GUI model GUI states: $actualGuiStatesCount.\n" +
        "Expected GUI model GUI states: $expectedGuiStatesCount.\n" +
        "The first expected GUI state not present in the actual model: ${expected.guiStates[actualGuiStatesCount]}"

    assert actual == expected

  }
}
