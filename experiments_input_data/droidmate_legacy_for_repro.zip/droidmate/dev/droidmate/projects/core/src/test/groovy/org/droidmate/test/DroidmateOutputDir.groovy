// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org
package org.droidmate.test

import org.droidmate.exploration.datatypes.ExplorationOutput
import org.droidmate.exploration.datatypes.IApkExplorationOutput
import org.droidmate.lowlevel.filesystem.IStorage
import org.droidmate.lowlevel.filesystem.Storage

import java.nio.file.Files
import java.nio.file.Path

class DroidmateOutputDir
{

  private final Path path

  DroidmateOutputDir(Path path)
  {
    this.path = path
    assert Files.isDirectory(path) || !Files.exists(path)
  }

  public void clearContents()
  {
    if (Files.exists(path))
      Files.list(path).each {
        if (Files.isDirectory(it))
          it.deleteDir()
        else
          Files.delete(it)
      }
  }

  public IApkExplorationOutput readOutput()
  {
    IStorage storage = new Storage(path)
    ExplorationOutput out = storage.deserializeAll()
    assert out.size() == 1
    IApkExplorationOutput apkOut = out[0]
    return apkOut
  }

}
