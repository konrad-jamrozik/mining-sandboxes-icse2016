// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org
package org.droidmate.test

import com.google.common.jimfs.Configuration
import com.google.common.jimfs.Jimfs
import org.droidmate.init.InitConstants

import java.nio.file.FileSystem
import java.nio.file.Files
import java.nio.file.Path

class MockFileSystemWithOneApk
{
  final FileSystem fs

  MockFileSystemWithOneApk()
  {
    this.fs = this.build()
  }

  private FileSystem build()
  {
    FileSystem fs = Jimfs.newFileSystem(Configuration.unix())
    Path apksDir = fs.getPath(InitConstants.apks_dir)
    Files.createDirectories(apksDir)
    Files.createFile(apksDir.resolve("mock_app.apk"))
    return fs
  }
}
