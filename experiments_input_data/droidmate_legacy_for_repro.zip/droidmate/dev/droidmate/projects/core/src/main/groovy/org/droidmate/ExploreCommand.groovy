// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org
package org.droidmate

import groovy.util.logging.Slf4j
import org.droidmate.device.IAndroidDevice
import org.droidmate.device.IAndroidDeviceDeployer
import org.droidmate.exploration.IExplorationExecutor
import org.droidmate.exploration.datatypes.ExplorationOutput
import org.droidmate.exploration.datatypes.IApkExplorationOutput
import org.droidmate.exploration.output.IExplorationOutputDataPersister
import org.droidmate.frontend.configuration.Configuration
import org.droidmate.lowlevel.apk.Apk
import org.droidmate.lowlevel.apk.IApkDeployer
import org.droidmate.lowlevel.apk.IApksProvider

@Slf4j
class ExploreCommand extends DroidmateCommand
{

  private final IApksProvider                   apksProvider
  private final IAndroidDeviceDeployer          deviceDeployer
  private final IApkDeployer apkDeployer
  private final IExplorationExecutor            executor
  private final IExplorationOutputDataPersister explorationOutputPersister

  ExploreCommand(
    IApksProvider apksProvider,
    IAndroidDeviceDeployer deviceDeployer,
    IApkDeployer apkDeployer,
    IExplorationExecutor executor,
    IExplorationOutputDataPersister explorationOutputPersister)
  {
    this.apksProvider = apksProvider
    this.deviceDeployer = deviceDeployer
    this.apkDeployer = apkDeployer
    this.executor = executor
    this.explorationOutputPersister = explorationOutputPersister
  }

  @Override
  void execute(Configuration cfg)
  {
    List<Apk> apks = apksProvider.getApks(cfg.apksDirFuncPath, cfg.apksLimit, cfg.apksNames)
    if (apks.size() == 0)
    {
      log.warn("No input apks found. Terminating.")
      return
    }

    ExplorationOutput out = exploreOnDevice(cfg.deviceIndex, apks)

    explorationOutputPersister.persist(out)
  }

  private List<IApkExplorationOutput> exploreOnDevice(int deviceIndex, List<Apk> apks)
  {
    ExplorationOutput out = [] as ExplorationOutput

    deviceDeployer.withSetupDevice(deviceIndex) {IAndroidDevice device ->

      apks.eachWithIndex {Apk apk, int i ->

        log.info("Processing ${i + 1} out of ${apks.size()} apks: ${apk.fileName}")

        apkDeployer.withDeployedApk(device, apk) {Apk deployedApk ->

          // KJA2 replace with exploration when ready
          out << executor.explore(deployedApk.packageName, deployedApk.launchableActivityComponentName, device)
        }
      }
    }
    return out
  }
}
