// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org

package org.droidmate.device.datatypes

import groovy.transform.Canonical
import org.droidmate.common_android.guimodel.GuiAction

@Canonical
class ClickGuiAction extends AndroidDeviceAction
{
  GuiAction guiAction

  @Override
  public String toString()
  {
    return this.getClass().simpleName + " : " + guiAction.toString()
  }
}
