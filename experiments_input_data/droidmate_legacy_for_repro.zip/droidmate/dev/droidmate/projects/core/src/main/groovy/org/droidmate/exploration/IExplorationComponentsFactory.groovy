// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org

package org.droidmate.exploration

import groovy.transform.TypeChecked
import org.droidmate.device.IAndroidDeviceExploration
import org.droidmate.exploration.datatypes.IApkExplorationOutput

@TypeChecked
public interface IExplorationComponentsFactory
{
  IExplorationStrategy createStrategy(String appPackageName)

  IWidgetStrategy createWidgetStrategy(String appPackageName)

  IDeviceExplorationDriver createDriver(IAndroidDeviceExploration device,
                                        String appPackageName,
                                        String appLaunchableActivityComponentName,
                                        IApkExplorationOutput explorationOutput)

  IExplorationActionToVerifiableDeviceActionsTranslator createActionsTranslator(
    String appPackageName,
    String appLaunchableActivityComponentName)

  IVerifiableDeviceActionsExecutor createVerifiableDeviceActionsExecutor(IAndroidDeviceExploration device, IApkExplorationOutput explorationOutput)

  IExplorationOutputCollector createExplorationOutputCollector(String appPackageName)

  IDeviceMessagesReader createDeviceMessagesReader(IAndroidDeviceExploration device)
}