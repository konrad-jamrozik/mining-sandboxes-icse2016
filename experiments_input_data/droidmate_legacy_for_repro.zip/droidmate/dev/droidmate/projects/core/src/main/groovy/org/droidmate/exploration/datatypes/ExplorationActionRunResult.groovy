// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org
package org.droidmate.exploration.datatypes

import org.droidmate.exploration.DeviceLogs

class ExplorationActionRunResult implements IExplorationActionRunResult
{

  private final IExplorationActionPerformResult result
  private final DeviceLogs                      logs

  ExplorationActionRunResult(IExplorationActionPerformResult result, DeviceLogs logs)
  {
    this.result = result
    this.logs = logs
  }

  @Override
  GuiState getGuiState()
  {
    return result.guiState
  }

  @Override
  boolean isSuccessful()
  {
    // KJA2 current work
    assert false: "Not yet implemented!"
  }
}
