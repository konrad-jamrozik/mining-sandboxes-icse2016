// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org

package org.droidmate.lowlevel.androidsdk

import groovy.transform.TypeChecked
import org.droidmate.exploration.DeviceTools
import org.droidmate.lowlevel.apk.Apk
import org.droidmate.test.DroidmateGroovyTestCase
import org.junit.FixMethodOrder
import org.junit.Test
import org.junit.runner.RunWith
import org.junit.runners.JUnit4
import org.junit.runners.MethodSorters

import java.nio.file.Path
import java.nio.file.Paths

import static groovy.transform.TypeCheckingMode.SKIP

@TypeChecked
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(JUnit4)
public class AaptWrapperTest extends DroidmateGroovyTestCase
{
  @Test
  public void "Gets launchable activity component name from badging dump"()
  {
    String aaptBadgingDump = aaptBadgingDump

    // Act
    String launchableActivityName = AaptWrapper.getLaunchableActivityComponentNameFromBadgingDump(aaptBadgingDump)

    assert launchableActivityName == expectedLaunchableActivityName
  }

  @TypeChecked(SKIP)
  @Test
  public void "Gets launchable activity component name"()
  {

    AaptWrapper sut = new DeviceTools().aapt as AaptWrapper
    sut.metaClass.aaptDumpBadging = {Path _ -> aaptBadgingDump}

    Apk ignoredApk = fixtures.apks.monitoredInlined

    // Act
    String launchableActivityName = sut.getLaunchableActivityComponentName(Paths.get(ignoredApk.absolutePath))

    assert launchableActivityName == expectedLaunchableActivityName
  }

  //region Helper methods
  private static String getAaptBadgingDump()
  {
    String aaptBadgingDump = fixtures.f_aaptBadgingDump
    assert aaptBadgingDump.contains("package: name='com.box.android'")
    assert aaptBadgingDump.contains("launchable-activity: name='com.box.android.activities.SplashScreenActivity'")
    return aaptBadgingDump
  }

  private static String getExpectedLaunchableActivityName()
  {
    return "com.box.android/com.box.android.activities.SplashScreenActivity"
  }

  //endregion Helper methods

}
