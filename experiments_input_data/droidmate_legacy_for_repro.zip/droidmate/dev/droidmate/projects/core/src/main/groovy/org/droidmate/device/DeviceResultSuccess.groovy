// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org
package org.droidmate.device

import org.droidmate.exceptions.DeviceException

class DeviceResultSuccess<T> implements IDeviceResult<T>, Serializable
{

  private static final long serialVersionUID = 1L;
  final T result

  DeviceResultSuccess(T result)
  {
    this.result = result
  }

  @Override
  Boolean getSuccess()
  {
    return true
  }

  @Override
  DeviceException getException()
  {
    throw new UnsupportedOperationException()
  }
}

