// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org

package org.droidmate.exploration

import groovy.transform.Canonical
import org.droidmate.common.LabeledEdge
import org.droidmate.exceptions.UnexpectedIfElseFallthroughError
import org.droidmate.exploration.datatypes.*

@Canonical
class DeviceGuiModel implements IDeviceGuiModel, Serializable
{

  private static final long serialVersionUID = 1

  IGuiState homeGuiState
  /**
   * The {@link org.droidmate.exploration.datatypes.GuiState GuiState} of the
   * {@link org.droidmate.device.datatypes.IDeviceGuiSnapshot IDeviceGuiSnapshot}
   * in which the modeled app ends up after the {@link ResetAppExplorationAction} is issued.
   */
  IGuiState launchGuiState

  Set<IGuiState>                                            guiStates
  Set<LabeledEdge<IGuiState, ExplorationAction, IGuiState>> stateTransitions

  static DeviceGuiModel build(
    IGuiState homeGuiState,
    IGuiState launchGuiState,
    Collection<IGuiState> guiStates,
    Collection<LabeledEdge<IGuiState, ExplorationAction, IGuiState>> stateTransitions
  )
  {
    assert homeGuiState?.isHomeScreen()
    assert launchGuiState != null
    assert guiStates != null
    assert stateTransitions != null

    assert !guiStates.contains(homeGuiState)
    assert !guiStates.contains(launchGuiState)

    def homeGuiStateWithId = new GuiState(homeGuiState, "home")
    def launchGuiStateWithId = new GuiState(launchGuiState, "S1")
    Set<IGuiState> allGuiStates = (guiStates + homeGuiStateWithId + launchGuiStateWithId)

    stateTransitions.each {def transition ->
      assert transition.source in allGuiStates
      assert transition.target in allGuiStates
    }



    return new DeviceGuiModel(homeGuiStateWithId, launchGuiStateWithId, allGuiStates, stateTransitions as Set)
  }

  @Override
  IGuiState getTargetGuiState(IGuiState guiState, ExplorationAction action)
  {

    Set<LabeledEdge<IGuiState, ExplorationAction, IGuiState>> matchingTransitions

    switch (action.class)
    {
      case ExitAppExplorationAction:
      case TerminateExplorationAction:
        return homeGuiState
        break

      case ResetAppExplorationAction:
        return launchGuiState
        break
      case WidgetExplorationAction:
      case EnterTextExplorationAction:

        matchingTransitions = stateTransitions.findAll {it.source == guiState && it.label == action}

        assert matchingTransitions.size() >= 1: "No GUI model transition found that starts in the GUI state of $guiState and " +
          "transitions with exploration action of $action"
        assert matchingTransitions.size() <= 1: "More than one GUI model transitions found that start in GUI state of " + guiState +
          " and transition with exploration action of $action. Currently only one (i.e. deterministic) transition is supported"

        def transition = matchingTransitions[0]
        return transition.target
        break

      default:
        throw new UnexpectedIfElseFallthroughError()
    }
  }

  @Override
  boolean addTransition(IGuiState source, ExplorationAction action, IGuiState target)
  {
    assert source != null
    assert action != null
    assert target != null
    assert guiStates.contains(source)

    def newTransition = new LabeledEdge<IGuiState, ExplorationAction, IGuiState>(source, action, target)

    if (!stateTransitions.contains(newTransition))
    {
      if (!guiStates.contains(target))
        guiStates += target

      stateTransitions.add(newTransition)
      return true
    } else
      return false
  }

  public String toDOTString()
  {
    def graph = new DeviceGuiModelGraph(this)
    return graph.toDOTString()
  }


}
