// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org

package org.droidmate.exploration.datatypes

import groovy.transform.Canonical
import groovy.transform.TupleConstructor
import org.droidmate.device.IRobustAndroidDevice

@Canonical
@TupleConstructor(includeSuperProperties = true)
class PressBackExplorationAction extends ExplorationAction
{

  private static final long serialVersionUID = 1

  @Override
  String toString()
  {
    return super.toString()
  }

  @Override
  String toShortString()
  {
    "Press back"
  }

  protected IExplorationActionPerformResult perform(IRobustAndroidDevice device)
  {
    // KJA2 current work
    assert false: "Not yet implemented!"
  }
}
