// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org

package org.droidmate.exploration

import org.droidmate.common.LabeledEdge
import org.droidmate.exploration.datatypes.ExplorationAction
import org.droidmate.exploration.datatypes.IGuiState

interface IDeviceGuiModel
{

  IGuiState getTargetGuiState(IGuiState guiState, ExplorationAction action)

  Set<IGuiState> getGuiStates()

  boolean addTransition(IGuiState origin, ExplorationAction label, IGuiState target)

  Set<LabeledEdge<IGuiState, ExplorationAction, IGuiState>> getStateTransitions()

  String toDOTString()
}

