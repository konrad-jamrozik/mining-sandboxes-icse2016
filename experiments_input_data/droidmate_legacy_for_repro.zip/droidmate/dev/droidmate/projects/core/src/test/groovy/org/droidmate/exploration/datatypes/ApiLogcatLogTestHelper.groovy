// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org

package org.droidmate.exploration.datatypes

import org.droidmate.common.logcat.Api
import org.droidmate.common.logcat.ApiLogcatMessage
import org.droidmate.common.logcat.TimeFormattedLogcatMessage
import org.droidmate.common_android.Constants
import org.droidmate.exploration.output.ExplorationOutputDataExtractor
import org.droidmate.logcat.IApiLogcatMessage

import java.time.LocalDateTime

class ApiLogcatLogTestHelper
{

  public static final String log_level_for_testing = "I"

  static IApiLogcatMessage newApiLogcatMessage(Map apiAttributes)
  {
    def time = apiAttributes.remove("time") as LocalDateTime
    apiAttributes["stackTrace"] = apiAttributes["stackTrace"] ?: "$ExplorationOutputDataExtractor.monitorRedirectionPrefix"

    def logcatMessage = TimeFormattedLogcatMessage.from(
      time ?: TimeFormattedLogcatMessage.assumedDate,
      log_level_for_testing,
      Constants.instrumentation_apiMethodCallLogcatTag,
      "3993", // arbitrary process ID
      ApiLogcatMessage.toLogcatMessagePayload(new Api(apiAttributes))
    )

    return ApiLogcatMessage.from(logcatMessage)
  }


}
