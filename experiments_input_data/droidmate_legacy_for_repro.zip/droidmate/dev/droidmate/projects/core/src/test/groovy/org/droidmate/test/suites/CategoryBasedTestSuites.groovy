// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org

package org.droidmate.test.suites

import org.junit.experimental.categories.Categories
import org.junit.runner.RunWith
import org.junit.runners.Suite

// @formatter:off
public interface Secondary  { /* JUnit test Category marker interface */ }
public interface ExcludedFromFastRegressionTests { /* JUnit test Category marker interface */ }
public interface UnderConstruction extends ExcludedFromFastRegressionTests { /* JUnit test Category marker interface */ }
public interface RequiresDevice extends ExcludedFromFastRegressionTests { /* JUnit test Category marker interface */ }
// @formatter:on

/*
  N00b Reference:

  How test suites work:
  https://github.com/junit-team/junit/wiki/Aggregating-tests-in-suites

  How categories work:
  https://github.com/junit-team/junit/wiki/Categories
*/

@RunWith(Categories)
@Categories.ExcludeCategory(ExcludedFromFastRegressionTests)
@Suite.SuiteClasses([
  AllTestSuites
])
class AllFastTestSuite
{
}

@RunWith(Categories)
@Categories.ExcludeCategory(ExcludedFromFastRegressionTests)
@Suite.SuiteClasses([
  RegressionTestSuite
])
class FastRegressionTestSuite
{
}

@RunWith(Categories)
@Categories.IncludeCategory(RequiresDevice)
@Suite.SuiteClasses([
  RegressionTestSuite
])
class DeviceRequiringRegressionTestSuite
{
}

@RunWith(Categories)
@Categories.ExcludeCategory(ExcludedFromFastRegressionTests)
@Suite.SuiteClasses([
  ExplorationTestSuite
])
class ExplorationTestSuiteWithoutDevice
{
}

@RunWith(Categories)
@Categories.IncludeCategory(UnderConstruction)
@Suite.SuiteClasses([
  AllTestSuites
])
class AllUnderConstructionTestSuite
{
}
