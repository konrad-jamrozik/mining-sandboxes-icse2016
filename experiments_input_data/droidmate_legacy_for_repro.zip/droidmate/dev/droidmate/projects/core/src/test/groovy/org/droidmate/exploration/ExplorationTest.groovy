// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org
package org.droidmate.exploration

import groovy.transform.TypeChecked
import org.droidmate.device.AndroidDeviceSimulatorFuncTestHelper
import org.droidmate.device.IRobustAndroidDevice
import org.droidmate.device.RobustAndroidDevice
import org.droidmate.frontend.configuration.Configuration
import org.droidmate.lowlevel.apk.Apk
import org.droidmate.lowlevel.apk.IApk
import org.droidmate.test.DroidmateGroovyTestCase
import org.droidmate.test.suites.UnderConstruction
import org.junit.FixMethodOrder
import org.junit.Test
import org.junit.experimental.categories.Category
import org.junit.runner.RunWith
import org.junit.runners.JUnit4
import org.junit.runners.MethodSorters

@TypeChecked
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(JUnit4)
public class ExplorationTest extends DroidmateGroovyTestCase
{

  // KJA NEXT current work
  @Category(UnderConstruction)
  @Test
  void "Runs"()
  {
    Exploration exploration = Exploration.build(Configuration.default)

    IApk app = new Apk("mock.apk", "/mock/path/to/mock.apk", "mock.pkg.name", "mock_lActN", "mock_lActCN")
    IRobustAndroidDevice device = new RobustAndroidDevice(AndroidDeviceSimulatorFuncTestHelper.buildFromSpec("mock.pkg.name"))

    exploration.run(app, device)
  }

}