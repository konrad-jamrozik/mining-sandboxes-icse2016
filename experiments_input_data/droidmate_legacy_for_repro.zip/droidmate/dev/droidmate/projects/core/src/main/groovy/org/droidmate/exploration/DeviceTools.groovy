// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org

package org.droidmate.exploration

import groovy.util.logging.Slf4j
import org.droidmate.common.SysCmdExecutor
import org.droidmate.common_android.DeviceCommand
import org.droidmate.common_android.DeviceResponse
import org.droidmate.device.AndroidDeviceDeployer
import org.droidmate.device.IAndroidDeviceDeployer
import org.droidmate.device.IAndroidDeviceFactory
import org.droidmate.device.SerializableTCPClient
import org.droidmate.frontend.configuration.Configuration
import org.droidmate.lowlevel.androidsdk.AaptWrapper
import org.droidmate.lowlevel.androidsdk.AdbWrapper
import org.droidmate.lowlevel.androidsdk.IAaptWrapper
import org.droidmate.lowlevel.androidsdk.IAdbWrapper
import org.droidmate.lowlevel.apk.ApkDeployer
import org.droidmate.lowlevel.apk.IApkDeployer

@Slf4j
class DeviceTools
{

  IAaptWrapper           aapt
  IAndroidDeviceDeployer deviceDeployer
  IApkDeployer apkDeployer


  public DeviceTools(Configuration cfg = Configuration.default, Map substitutes = [:])
  {
    def sysCmdExecutor = new SysCmdExecutor()

    aapt = substitutes[IAaptWrapper] as IAaptWrapper ?: new AaptWrapper(cfg, sysCmdExecutor)

    def adbWrapper = substitutes[IAdbWrapper] as IAdbWrapper ?:
      new AdbWrapper(cfg, sysCmdExecutor)

    def deviceTcpClient = new SerializableTCPClient<DeviceCommand, DeviceResponse>()

    def deviceFactory = substitutes[IAndroidDeviceFactory] as IAndroidDeviceFactory ?:
      new AndroidDeviceFactoryFunc(cfg, deviceTcpClient, adbWrapper)

    deviceDeployer = new AndroidDeviceDeployer(cfg, adbWrapper, deviceFactory)

    apkDeployer = new ApkDeployer(cfg)
  }
}
