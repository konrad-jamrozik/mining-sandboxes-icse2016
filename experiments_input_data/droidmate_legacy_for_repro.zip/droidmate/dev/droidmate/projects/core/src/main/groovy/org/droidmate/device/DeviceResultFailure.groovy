// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org
package org.droidmate.device

import org.droidmate.exceptions.DeviceException

class DeviceResultFailure<T> implements IDeviceResult<T>, Serializable
{

  private static final long serialVersionUID = 1L;
  final DeviceException exception

  DeviceResultFailure(DeviceException exception)
  {
    this.exception = exception
  }

  @Override
  T getResult()
  {
    throw new UnsupportedOperationException()
  }

  @Override
  Boolean getSuccess()
  {
    return false
  }

}
