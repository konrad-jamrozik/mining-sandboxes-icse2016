// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org
package org.droidmate.exploration

import org.droidmate.lowlevel.ITimeProvider
import org.droidmate.lowlevel.filesystem.IStorage

class ExplorationOutputCollectorFactory implements IExplorationOutputCollectorFactory
{

  private final ITimeProvider timeProvider
  private final IStorage      storage

  ExplorationOutputCollectorFactory(ITimeProvider timeProvider, IStorage storage)
  {
    this.storage = storage
    this.timeProvider = timeProvider
  }

  @Override
  IExplorationOutputCollector create(String appPackageName)
  {
    return new ExplorationOutputCollector(appPackageName, timeProvider, storage)
  }
}
