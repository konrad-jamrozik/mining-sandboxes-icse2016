// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org

package org.droidmate.exploration

import groovy.util.logging.Slf4j
import org.droidmate.common.logcat.ApiLogcatMessage
import org.droidmate.common.logging.LogbackConstants
import org.droidmate.common_android.Constants
import org.droidmate.device.IAndroidDeviceExploration
import org.droidmate.device.datatypes.IAndroidDeviceAction
import org.droidmate.exceptions.DeviceException
import org.droidmate.logcat.IApiLogcatMessage
import org.droidmate.logcat.ITimeFormattedLogcatMessage
import org.slf4j.Logger
import org.slf4j.LoggerFactory

import static org.droidmate.logcat.MonitorConstants.*

@Slf4j
class RobustDeviceFunc
{

  static List robustPerform(
    IAndroidDeviceExploration device, String pkgName, String launchableActivityComponentName,
    List<IAndroidDeviceAction> deviceActions)
  {
    // obsolete-to-do: implement missing robustness

    deviceActions.each {device.perform(it)}

    return [device.guiSnapshot, []]

  }

  static List robustReadLogs(IAndroidDeviceExploration device, boolean isFirstReadLogs)
  {
    List<DeviceException> exs = []
    if (isFirstReadLogs)
    {
      exs += readMonitorMessages(device)
      exs += readInstrumentationMessages(device)
    }

    def (List<IApiLogcatMessage> logs, List<DeviceException> apiReadExs) = readApiLogs(device)
    exs += apiReadExs

    exs += readUiaDaemonLogs(device)
    exs += clearLogcat(device)

    return [logs, exs]
  }


  private static Logger monitorLogger = LoggerFactory.getLogger(LogbackConstants.logger_name_monitor)

  private static List<DeviceException> readMonitorMessages(IAndroidDeviceExploration device)
  {
    log.debug("Reading and validating monitor messages sent to logcat.")

    try
    {
      List<ITimeFormattedLogcatMessage> messages = device.readLogcatMessages(tag_monitor_init)

      messages.each {monitorLogger.trace("${it.toLogcatMessage()}")}

      if (messages.size() < 2)
        throw new DeviceException("Expected to read from logcat two messages tagged ${tag_monitor_init} on first " +
          "retrieval of current api logs. First log denoting monitor was just constructed. " +
          "Second log denoting it finished initialization. " +
          "However, the number of such messages is: ${messages.size()}. " +
          "If there is no message, the possible cause is that the explored apk is not inlined or monitor inlining failed. " +
          "In the latter case other logcat messages might point to the underlying cause.")

      messages = validateAndDropDuplicatesWithLaterTimestamps(messages)
      assert messages.size() == 2

      if (!messages[0].messagePayload.contains(message_monitor_constructed))
        throw new DeviceException(
          "Expected that the first message from monitor output to logcat will contain: $message_monitor_constructed. " +
            "However, the message is: ${messages[0].messagePayload}")

      if (!messages[1].messagePayload.contains(message_prefix_monitor_initialized))
        throw new DeviceException(
          "Monitor was constructed, but it failed to successfully initialize. " +
            "Details: expected that the second message from monitor output to logcat will contain: " +
            "$message_prefix_monitor_initialized. However, the message is: ${messages[1].messagePayload}")

    } catch (DeviceException e)
    {
      return [e]
    }
    return []
  }

  private static List<ITimeFormattedLogcatMessage> validateAndDropDuplicatesWithLaterTimestamps(
    List<ITimeFormattedLogcatMessage> msgs)
  {
    Set<String> uniquePayloads = msgs.groupBy {ITimeFormattedLogcatMessage it -> it.messagePayload}.keySet()
    assert uniquePayloads.size() == 2: "We expect only two distinct message payloads: " +
      "one saying monitor was constructed and the other it initialized for currently explored package. " +
      "Instead, we got following message payloads: " + uniquePayloads

    assert msgs == msgs.collect().sort {it.time}

    ITimeFormattedLogcatMessage msg1 = msgs.findAll {it.messagePayload == message_monitor_constructed}.first()
    ITimeFormattedLogcatMessage msg2 = msgs.findAll {it.messagePayload.contains(message_prefix_monitor_initialized)}.first()
    return [msg1, msg2]
  }

  private static List<DeviceException> readInstrumentationMessages(IAndroidDeviceExploration device)
  {
    List<ITimeFormattedLogcatMessage> messages
    try
    {
      messages = device.readLogcatMessages(Constants.instrumentation_redirectionTag)

    } catch (DeviceException e)
    {
      return [e]
    }

    messages.each {monitorLogger.trace("${it.toLogcatMessage()}")}

    return []

  }

  private static List readApiLogs(IAndroidDeviceExploration device) throws DeviceException
  {
    List<ITimeFormattedLogcatMessage> messages = []
    try
    {
      messages = device.readLogcatMessages(Constants.instrumentation_apiMethodCallLogcatTag)
    } catch (DeviceException e)
    {
      return [messages, [e]]
    }

    messages.each {monitorLogger.trace("${it.toLogcatMessage()}")}

    List<ApiLogcatMessage> apiLogs = messages.collect {ApiLogcatMessage.from(it)}

    assert apiLogs == apiLogs.collect().sort {it.time}

    log.debug("Current API logs read count: ${apiLogs.size()}")

    return [apiLogs, []]
  }

  private static Logger uiadLogger = LoggerFactory.getLogger(LogbackConstants.logger_name_uiad)

  private static List<DeviceException> readUiaDaemonLogs(IAndroidDeviceExploration device)
  {
    List<ITimeFormattedLogcatMessage> uiaDaemonLogs = []
    try
    {
      uiaDaemonLogs = device.readLogcatMessages(Constants.uiaDaemon_logcatTag)
    } catch (DeviceException e)
    {
      return [e]
    }
    finally
    {
      uiaDaemonLogs.each {
        if (it.level == "W")
          uiadLogger.warn("${it.messagePayload}")
        else
          uiadLogger.trace("${it.messagePayload}")
      }
    }
    return []
  }

  private static List<DeviceException> clearLogcat(IAndroidDeviceExploration device)
  {
    try
    {
      device.clearLogcat()
    } catch (DeviceException e)
    {
      return [e]
    }
    return []
  }

}
