// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org

package org.droidmate.exploration.datatypes

import groovy.transform.Canonical
import groovy.util.logging.Slf4j
import org.droidmate.common.logging.LogbackConstants
import org.droidmate.device.datatypes.IDeviceGuiSnapshot
import org.droidmate.exceptions.ApkExplorationOutputVerificationException
import org.droidmate.exceptions.DeviceException
import org.droidmate.exploration.output.ExplorationOutputDataExtractor
import org.droidmate.exploration.strategy.ExplorationStrategyState
import org.droidmate.logcat.IApiLogcatMessage

import java.time.Duration
import java.time.LocalDateTime

import static org.droidmate.common.logging.Markers.exceptions

@Slf4j
@Canonical
class ApkExplorationOutputFunc
{
  private static final long serialVersionUID = 1

  String packageName

  // for multiple instances of the same app, e.g. because of different versions.
  String instanceName

  List<ExplorationAction> actions = []

  List<ExplorationStrategyState> explStratStates = []

  List<IDeviceGuiSnapshot> guiSnapshots = []

  /**
   * i-th entry of this instance denotes the logs obtained from the device after i-th instance of {@link #actions} has been
   * executed.
   */
  List<List<IApiLogcatMessage>> logs = []

  List<DeviceException> devicePerformExceptions = []
  List<DeviceException> deviceReadLogsExceptions = []

  IApkExplorationOutput.IUiaTestCaseAnnotations annotations

  static ApkExplorationOutputFunc build(Map params)
  {
    if (params.uiaTestCaseName != null)
      params.annotations = new UiaTestCaseAnnotations(testCaseName: params.uiaTestCaseName)
    params.remove("uiaTestCaseName")
    def out = new ApkExplorationOutputFunc(params)
    return out
  }

  /**
   * Instance of this class, when created, is not complete: it is to be mutated by recording information in it.
   * When the mutation is done, i.e. all necessary data has been recorded to it, the contract is that
   * {@link #completeAndVerify()} is to be called, setting this field to appropriate value.
   *
   * @see #verificationException
   */
  CompletenessVerificationStatus completenessVerificationStatus    = CompletenessVerificationStatus.NOT_YET_DETERMINED
  /**
   * This field will held exception if this instance failed verification done during {@link #completeAndVerify()}. In all other
   * cases it has null.
   *
   * @see #completenessVerificationStatus
   */
  ApkExplorationOutputVerificationException verificationException  = null

  /**
   * @see #completenessVerificationStatus
   */
  enum CompletenessVerificationStatus {

    NOT_YET_DETERMINED,
    SUCCESSFUL,
    FAILURE
  }

  /**
   * Side effect: sets the value of {@link #completenessVerificationStatus} and {@link #verificationException}. See their
   * description for details.
   */
  List completeAndVerify()
  {
    assert completenessVerificationStatus == CompletenessVerificationStatus.NOT_YET_DETERMINED

    ApkExplorationOutputVerificationException exception = verifyIntegrity(this)
    if (exception == null)
    {
      completenessVerificationStatus = CompletenessVerificationStatus.SUCCESSFUL
    } else
    {
      completenessVerificationStatus = CompletenessVerificationStatus.FAILURE
      verificationException = exception
    }

    assert completenessVerificationStatus in [
      CompletenessVerificationStatus.SUCCESSFUL,
      CompletenessVerificationStatus.FAILURE]
    assert (completenessVerificationStatus == CompletenessVerificationStatus.SUCCESSFUL)
      .implies(verificationException == null)
    assert (completenessVerificationStatus == CompletenessVerificationStatus.FAILURE)
      .implies(verificationException != null)

    return [completenessVerificationStatus, verificationException]
  }


  /**
   * <p>
   * Used for time comparisons allowing some imprecision.
   *
   * </p><p>
   * Some time comparisons in DroidMate happen between the time obtained from an Android device and the time obtained from
   * the machine on which DroidMate runs. Because these two computers most likely won't have clocks synchronized with millisecond
   * precision, this variable is incorporated in such time comparisons.
   *
   * </p>
   */
  public static final Duration clockImprecision = Duration.ofMillis(3000)

  static ApkExplorationOutputVerificationException verifyIntegrity(ApkExplorationOutputFunc out)
  {
    out.with {
      try
      {
        assert actions?.size() >= 2
        // to remove: assert actions.first().firstReset
        assert actions.last() instanceof TerminateExplorationAction

        // -1 because the last action terminates exploration without communicating with the device, thus, in particular
        // no logs are obtained from the device.
        assert logs?.size() == actions?.size() - 1

        assert actions.every {it != null}
        assert logs.every {it != null}

        assert explorationStartTime != null
        assert explorationEndTime != null

        assert explorationStartTime <= actions.first().timestampFunc
        assert explorationEndTime >= actions.last().timestampFunc

        // Assert exploration actions have increasing timestamps.
        assert actions*.timestampFunc == actions*.timestampFunc.collect().sort()

        List<IApiLogcatMessage> flatApiLogs = logs.flatten()
        if (!(flatApiLogs.empty))
          warnOnImpreciseClock(out, flatApiLogs)

        // Assertion that is being made here: ensure that stack traces come from DroidMate-provided monitor.
        List<List<String>> stackTraces = logs*.stackTrace.flatten().collect {it.split("->") as List<String>}
        stackTraces.each {List<String> stackTrace ->
          assert stackTrace.any {it.contains(ExplorationOutputDataExtractor.monitorRedirectionPrefix)}
        }

        if (isUiaTestCase)
          assert annotations?.testCaseName?.size() > 0

      } catch (AssertionError e)
      {
        log.error("Verification of exploration output from $packageName failed with: <exception message cut out due to IntelliJ hanging on too long stdout>. " +
          "As a consequence, the output is malformed and attempts of further processing will either throw an exception or result " +
          "in bogus results. $LogbackConstants.err_log_msg")
        log.error(exceptions, "Verification of exploration output from $packageName failed with: \n", e)
        return new ApkExplorationOutputVerificationException(e)
      }

      ApkExplorationOutputVerificationException noException = null
      return noException
    }
  }

  private static void warnOnImpreciseClock(ApkExplorationOutputFunc out, ArrayList<IApiLogcatMessage> flatApiLogs)
  {
    out.with {
      List<LocalDateTime> apiLogsTimes = flatApiLogs*.time.sort()

      /*
        We cannot simply assert that apiLogsTimes.first() >= explorationStartTime.

        Reason: timestamps are not sequential because the Log.i operation is not atomic within system.
        For details, see http://stackoverflow.com/a/13194705/986533
         */
      if (!(apiLogsTimes.first() >= explorationStartTime - Duration.ofSeconds(10)))
        log.warn("First logged API call time is more than 10 seconds earlier than the exploration start time.\n" +
          "The exploration start time is:  ${explorationStartTime},\n" +
          "the first API call log time:    ${apiLogsTimes.first()}.")

      // Assert API logs have increasing timestamps.
      assert (flatApiLogs == flatApiLogs.collect().sort {it.time})

      boolean oneWarningWasAlreadyLogged = false
      // Assert API logs logged after given exploration action have higher timestamps than the action.
      logs.eachWithIndex {List<IApiLogcatMessage> apiLogsForAction, int i ->

        apiLogsForAction.each {
          if (!(it.time >= actions[i].timestampFunc - clockImprecision))
          {
            if (!oneWarningWasAlreadyLogged)
              log.warn("One of the API calls logged after $i-th exploration action has earlier time than " +
                "the $i-th exploration action, even with allowed clock imprecision.\n" +
                "The offending API call has time   of ${it.time},\n" +
                "the exploration action time       is ${actions[i].timestampFunc},\n" +
                "and the allowed clock imprecision is ${clockImprecision.toMillis()} ms.\n" +
                "There might be more offending API calls logged, after the same or other exploration actions. " +
                "If this is the case, the information about them won't be output to avoid spamming " +
                "diagnostic output.")
            oneWarningWasAlreadyLogged = true
          }
        }
      }
    }
  }

  LocalDateTime getExplorationStartTime()
  {
    assert !actions.isEmpty()

    return actions.first().timestampFunc
  }


  LocalDateTime getExplorationEndTime()
  {
    assert !actions.isEmpty()

    ExplorationAction lastAction = actions.last()
    def nonemptyLogs = logs.findAll { it.size() > 0 }

    if (!nonemptyLogs.isEmpty())
    {
      IApiLogcatMessage lastLog = nonemptyLogs.last().last()
      return [lastAction.timestampFunc, lastLog.time].max()
    }
    else
      return lastAction.timestampFunc
  }

  boolean getIsUiaTestCase()
  {
    return annotations != null
  }

  // WISH later on: either adapt for data extraction or remove. Also with getHeader and getComments.
  boolean getExceptionWasThrown()
  {
    return devicePerformExceptions.size() + deviceReadLogsExceptions.size() > 0
  }

  String getHeader()
  {
    if (isUiaTestCase)
      return annotations.testCaseName+":"+packageName
    else
      return "droidmate-run:" + packageName
  }

  List<String> getComments()
  {
    assert isUiaTestCase
    return annotations.comments
  }

  @SuppressWarnings("GroovyUnusedDeclaration")
  // To be used in debugging sessions.
  private void debugTimestamps()
  {
    println "app: " + packageName
    actions.eachWithIndex {TimestampedExplorationAction action, int i ->
      println "action: " + action.explorationAction.class.simpleName + " time: " + action.timestamp
      logs[i].each {
        println "api log time: " + it.time
      }
    }
  }
}
