As of June 29, 2015 the "resources" dirs in "main" and "test" are copied from "core" project. This is a workaround for this problem:

https://youtrack.jetbrains.com/issue/IDEA-122577

The correct solution would be to do in build.gradle:

  Project coreProj = findProject(":projects:core")
  Set<File> coreResDirs = coreProj.sourceSets.main.resources.srcDirs.findAll {it.path.contains(coreProj.name)}
  assert coreResDirs.size() == 1
  sourceSets {
    test {
      resources {
        srcDir coreResDirs.find()
      }
    }
  }
