// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org

package org.droidmate.exploration.strategy

import groovy.util.logging.Slf4j
import org.droidmate.exceptions.DeviceException
import org.droidmate.exploration.IDeviceGuiModel

import static org.droidmate.exploration.strategy.CommonFunc.explorationCanMoveForwardOn

// obsolete-to-do: make this into a trait of Expl. Strat.
@Slf4j
class TerminateFunc
{

  static boolean terminate(Closure limitReached, String pkgName, ExploredGuiState egs, TerminationState state, IDeviceGuiModel guiModel, List<DeviceException> exs)
  {
    def (limitWasReached, msgLR) = limitReached(state)
    def (fatalCannotMoveForward, msgFCMF) = fatalCannotMoveForward(pkgName, egs, state)
    def (allWidgetsExplored, msgAWE) = allWidgetsExplored(guiModel, pkgName)

    boolean doTerminate = limitWasReached || fatalCannotMoveForward || allWidgetsExplored
    if (doTerminate)
    {
      String msg = "Terminate exploration:"+[msgLR, msgFCMF, msgAWE].collect { it != "" ? " "+it : "" }.join("")
      log.info(msg)
    }

    return doTerminate
  }

  static List limitReached(Integer secondsLimit, Integer actionsLimit, TerminationState state)
  {
    assert secondsLimit > 0 ^ actionsLimit > 0

    boolean limitReached = false
    String msg = ""

    if (state.actionsLimited)
    {
      assert !state.timeLimited
      assert state.actionsLeft >= 0

      if (state.actionsLeft == 0)
      {
        limitReached = true
        msg = "No actions left."
      }

    } else if (state.timeLimited)
    {
      assert !state.actionsLimited

      if (state.secondsElapsed >= secondsLimit)
      {
        limitReached = true
        msg = "Allocated exploration time exhausted."
      }
    }
    else
      assert false

    return [limitReached, msg]
  }

  static List fatalCannotMoveForward(String pkgName, ExploredGuiState egs, TerminationState state)
  {
    if (state.lastActionWasReset in [null, true] && !explorationCanMoveForwardOn(pkgName, egs))
      return [true, "Cannot move forward after reset."]

    return [false,""]
  }

  static List allWidgetsExplored(IDeviceGuiModel guiModel, String pkgName)
  {
    List<ExploredGuiState> appGuiStates = guiModel.guiStates.findAll { it.belongsToApp(pkgName) }
    if (appGuiStates.size() > 0 && appGuiStates.every { it.allWidgetsExplored })
      return [true, "All widgets have been explored."]

    return [false,""]
  }


}
