// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org

package org.droidmate.exploration.strategy

import groovy.transform.AutoClone
import groovy.transform.Canonical
import org.droidmate.common.TextUtilsCategory
import org.droidmate.common.exploration.datatypes.Widget
import org.droidmate.exploration.datatypes.GuiState
import org.droidmate.exploration.datatypes.IGuiState

@Canonical
@AutoClone
class ExploredGuiState implements IGuiState, Serializable
{
  private static final long serialVersionUID = 1

  @Delegate
  final IGuiState gs

  int seenCount = 0

  Map<Widget, Integer> widgetToSeenCountMap = [:]
  Map<Widget, Integer> widgetToActedUponCountMap   = [:]
  Map<Widget, Integer> widgetToLongClickedCountMap = [:]
  Map<Widget, Boolean> widgetToIsBlacklistedMap    = [:]

  ExploredGuiState(GuiState gs)
  {
    this.gs = gs
    gs.widgets.findAll { it.canBeActedUpon() }.each {
      widgetToSeenCountMap.put(it, 0)
      widgetToActedUponCountMap.put(it, 0)
      widgetToLongClickedCountMap.put(it, 0)
      widgetToIsBlacklistedMap.put(it, false)
    }
  }

  static ExploredGuiState from(GuiState gs)
  {
    return new ExploredGuiState(gs)
  }

  String getUniqueString()
  {
    return gs.topNodePackageName + " " + gs.widgets.findAll {it.canBeActedUpon()}.collect {
      it.with {
        if (["Switch", "Toggle"].any {className.contains(it)})
          return "$className $resourceId $contentDesc $bounds"
        else
          return "$className $resourceId $text $contentDesc $bounds"
      }

    }
  }

  Boolean getAllWidgetsExplored()
  {
    Boolean allWidgetsExplored = true
    widgetToSeenCountMap.each { widget, seenCount ->
      if (seenCount > 0)
      {
        if (widgetToActedUponCountMap[widget] == 0)
          allWidgetsExplored = false

        if (widget.longClickable && widgetToLongClickedCountMap[widget] == 0)
          allWidgetsExplored = false

        // This case can happen if the widget was always long-clicked, but never just clicked.
        if (widget.clickable && widgetToActedUponCountMap[widget] == widgetToLongClickedCountMap[widget])
          allWidgetsExplored = false
      }
    }
    return allWidgetsExplored
  }


  @Override
  public String toString()
  {
    use(TextUtilsCategory) {
      return ("Explored: ${gs.toString()} "+
        "{ss# $seenCount, " +
        "ws# ${widgetToSeenCountMap.values().sum()}, " +
        "wau# ${widgetToActedUponCountMap.values().sum()}, " +
        "wlc# ${widgetToLongClickedCountMap.values().sum()}, " +
        "wbl# ${widgetToIsBlacklistedMap.values().collect { it ? 1 : 0}.sum()}").wrapWith("<>")
    }
  }
}
