// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org

package org.droidmate.exploration

import groovy.util.logging.Slf4j
import org.droidmate.device.IAndroidDevice
import org.droidmate.device.IAndroidDeviceExploration
import org.droidmate.device.datatypes.IAndroidDeviceAction
import org.droidmate.device.datatypes.IDeviceGuiSnapshot
import org.droidmate.exceptions.DeviceException
import org.droidmate.exploration.datatypes.*
import org.droidmate.exploration.strategy.ExplorationStrategy
import org.droidmate.logcat.IApiLogcatMessage

import java.time.LocalDateTime

import static RobustDeviceFunc.robustPerform
import static RobustDeviceFunc.robustReadLogs
import static org.droidmate.device.datatypes.AndroidDeviceAction.*

@Slf4j
class ExploratorFunc
{

  // KJA2 to be replaced with org.droidmate.exploration.ExplorationExecutor.explore
  // KJA2 try out Flipside from http://getawesomeness.com/get/groovy#language-utilities
  static ApkExplorationOutputFunc explore(IAndroidDevice device, String pkgName, String launchableActivityComponentName)
  {
    Closure driveDevice = this.&driveDevice.curry(device, pkgName, launchableActivityComponentName)
    Closure chooseAction = strategy.chooseAction.curry(pkgName)

    ApkExplorationOutputFunc out = foldUntil(

      ApkExplorationOutputFunc.build(
        packageName: pkgName,
        actions: null, //[newResetAppExplorationAction([timestampFunc: now, isFirstReset: true])],
        explStratStates: [strategy.buildInitState()]
      ),

      {ApkExplorationOutputFunc output ->

        /*
          "action" is the last recorded action. It is going to be executed on the device.
          It is either first action or action to execute determined by exploration strategy at the end of previous iteration.

          Executing the action on the device will result in a new GuiState "gs", which then, together with "explStratState", which
          is last recorded exploration strategy state, will be used to record new action and new exploration strategy state.
         */
        def (action, explStratState) = [output.actions.last(), output.explStratStates.last()]

        def (GuiState gs, List deviceExceptions, ApkExplorationOutputFunc updatedOutput) = driveDevice(action, output)

        def (newAction, newExplStratState) = chooseAction(gs, explStratState, deviceExceptions)

        updatedOutput.actions << newAction
        updatedOutput.explStratStates << newExplStratState
        return updatedOutput
      },

      // obsolete-to-do: introduce new kind of action before terminate, "finalize", working as current terminate, and finish
      // on "terminate". This way we still gather logs and device snapshot after finalize.
      {ApkExplorationOutputFunc it -> it.actions.last() instanceof TerminateExplorationAction}
    )

    // As a side effect, this call sets the (completeness verification status) and (exception encountered, if any) fields.
    out.completeAndVerify()
    return out
  }

  static <T> T foldUntil(T init, Closure<T> fold, Closure predicate)
  {
    T out = init

    while (!predicate(out))
      out = fold(out)

    return out as T
  }

  static LocalDateTime getNow()
  {
    return LocalDateTime.now()
  }

  /**
   * This method takes {@code output} as input as after executing {@code action} it will add to {@code output} the resulting:<br/>
   * - GUI snapshot<br/>
   * - relevant logcat logs<br/>
   * - any exceptions occurring, either while performing action on device or reading logs from it.
   */
  static List driveDevice(
    IAndroidDeviceExploration device, String pkgName, String launchableActivityComponentName,
    ExplorationAction action, ApkExplorationOutputFunc output)
  {
    List<IAndroidDeviceAction> deviceActions = toDeviceActions(launchableActivityComponentName, action)

    def (IDeviceGuiSnapshot snapshot, List<DeviceException> performExs) =
    robustPerform(device, pkgName, launchableActivityComponentName, deviceActions)

    def (List<IApiLogcatMessage> logs, List<DeviceException> readLogsExs) =
    robustReadLogs(device, /* toremove action.firstReset */  false)

    output.guiSnapshots << snapshot
    output.logs << logs
    output.devicePerformExceptions = performExs
    output.deviceReadLogsExceptions = readLogsExs

    return [snapshot.guiState, [performExs, readLogsExs].flatten(), output]
  }

  // obsolete-to-do: finish implementing
  static List<IAndroidDeviceAction> toDeviceActions(String launchableActivityComponentName, ExplorationAction action)
  {
    switch (action.class)
    {
      case ResetAppExplorationAction:

        return [
          newPressHomeDeviceAction(),
          newTurnWifiOnDeviceAction(),
          newLaunchActivityDeviceAction(launchableActivityComponentName)]

        break

      case WidgetExplorationAction:
        def widgetAction = (action as WidgetExplorationAction)
        return [newClickGuiDeviceAction(widgetAction.widget, widgetAction.longClick)]

        break

      default:
        assert false: "Not yet implemented!"
    }


    assert false: "Not yet implemented!"
  }



  private static ExplorationStrategy _strategy = null

  private static ExplorationStrategy getStrategy()
  {
    assert _strategy != null: "There is no ${ExplorationStrategy.class.simpleName} bound. " +
      "If you tried to use one of the public static methods of ${ExploratorFunc.simpleName} requiring the missing class, " +
      "please wrap such call in ${ExploratorFunc.simpleName}.withExplorationStrategy()"
    return _strategy
  }

}


