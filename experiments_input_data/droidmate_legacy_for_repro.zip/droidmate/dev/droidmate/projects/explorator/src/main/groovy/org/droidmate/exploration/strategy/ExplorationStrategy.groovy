// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org

package org.droidmate.exploration.strategy

import com.google.common.base.Stopwatch
import com.google.common.base.Ticker
import groovy.util.logging.Slf4j
import org.droidmate.common.exploration.datatypes.Widget
import org.droidmate.exceptions.DeviceException
import org.droidmate.exploration.DeviceGuiModel
import org.droidmate.exploration.datatypes.*
import org.droidmate.frontend.configuration.Configuration

import java.time.LocalDateTime
import java.util.concurrent.TimeUnit

import static org.droidmate.exploration.datatypes.ExplorationAction.*
import static org.droidmate.exploration.strategy.CommonFunc.explorationCanMoveForwardOn

@Slf4j
class ExplorationStrategy
{

  Closure<ExplorationStrategyState> buildInitState
  Closure<List>                     chooseAction

  static ExplorationStrategy build(Configuration cfg = Configuration.default)
  {
    return new ExplorationStrategy(cfg)
  }

  private ExplorationStrategy(Configuration cfg)
  {
    buildInitState = this.&buildInitState.curry(cfg.secondsLimit != null, cfg.actionsLimit)

    Closure limitReached = TerminateFunc.&limitReached.curry(cfg.secondsLimit, cfg.actionsLimit)
    Closure terminate = TerminateFunc.&terminate.curry(limitReached)

    Random random = new Random(cfg.randomSeed)
    Closure exploreForward = ExplorationStrategy.&exploreForward.curry(random)

    Stopwatch stopwatch = Stopwatch.createUnstarted(Ticker.systemTicker())
    Closure updateExplorationState = ExplorationStrategy.&updateExplorationState.curry(stopwatch)

    chooseAction = ExplorationStrategy.&chooseAction.curry(terminate, exploreForward, updateExplorationState)
  }

  static ExplorationStrategyState buildInitState(boolean timeLimited, Integer actionsLimit)
  {
    def terminationState = new TerminationState(
      actionsLimited: actionsLimit != null,
      actionsLeft: actionsLimit ?: null,
      timeLimited: timeLimited
    )
    def forwardState = new ExploreForwardState(guiModel: DeviceGuiModel.build(null, null, [], []), currentlyExploredGuiState: null)
    return new ExplorationStrategyState(terminationState: terminationState, exploreForwardState: forwardState)
  }

  static List chooseAction(Closure terminate, Closure exploreForward, Closure updateExplorationState, String pkgName, GuiState gs, ExplorationStrategyState state, List<DeviceException> exs)
  {
    def updatedExploreForwardState = updateExploreForwardState(pkgName, gs, state.exploreForwardState)

    ExploredGuiState egs = updatedExploreForwardState.currentlyExploredGuiState

    boolean doTerminate = terminate(pkgName, egs, state.terminationState, updatedExploreForwardState.guiModel, exs)
    boolean doReset = reset(pkgName, egs, doTerminate)
    boolean doLogin = login(pkgName, egs, state, doTerminate, doReset)
    def (boolean doExploreForward, Map forwardExplorationOutput) = exploreForward(egs, doTerminate, doReset, doLogin)

    ExplorationAction action = interpretIntoAction(state, doTerminate, doReset, doLogin, doExploreForward, forwardExplorationOutput)

    ExplorationStrategyState updatedExplorationState = updateExplorationState(state, action, updatedExploreForwardState)

    return [action, updatedExplorationState]
  }

  static boolean reset(String pkgName, ExploredGuiState egs, boolean doTerminate)
  {
    return !doTerminate && !explorationCanMoveForwardOn(pkgName, egs)
  }

  static boolean login(String pkgName, ExploredGuiState egs, ExplorationStrategyState explorationStrategyState, boolean doTerminate, boolean doReset)
  {
    // obsolete-to-do: to implement
    return false
  }

  static ExploreForwardState updateExploreForwardState(String pkgName, GuiState gs, ExploreForwardState state)
  {
    ExploreForwardState updatedState = state.clone()

    ExploredGuiState currentlyExploredGuiState = getCurrentlyExploredGuiState(gs, updatedState)

    currentlyExploredGuiState.seenCount++
    // Increase the "seen count" on each widget on the GUI state by 1.
    currentlyExploredGuiState.widgetToSeenCountMap.entrySet().each {e -> e.value++}

    ExploredGuiState lastExploredGuiState = state.currentlyExploredGuiState
    lastExploredGuiState = blacklistWidgets(lastExploredGuiState, pkgName, state.lastExplorationAction)

    updatedState.guiModel.addTransition(lastExploredGuiState, state.lastExplorationAction, currentlyExploredGuiState)
    updatedState.currentlyExploredGuiState = currentlyExploredGuiState
    return updatedState

  }

  private static ExploredGuiState getCurrentlyExploredGuiState(GuiState gs, ExploreForwardState state)
  {
    ExploredGuiState currentlyExploredGuiState = ExploredGuiState.from(gs)

    List<ExploredGuiState> equivEgs = state.guiModel.guiStates.findAll {
      it.uniqueString == currentlyExploredGuiState.uniqueString
    }

    assert equivEgs.size() < 2:
      "Found ${equivEgs.size()} GUI states in the GUI model that are equivalent to the currently explored GUI state. " +
        "This shouldn't be possible: the GUI model should have 0 or 1 equivalent states."

    if (equivEgs.size() == 1)
      currentlyExploredGuiState = equivEgs[0]
    return currentlyExploredGuiState
  }

  private static ExploredGuiState blacklistWidgets(ExploredGuiState egs, String pkgName, ExplorationAction action)
  {
    if (egs != null && !egs.belongsToApp(pkgName))
    {
      if (action instanceof WidgetExplorationAction)
      {
        Widget blacklistedWidget = ((WidgetExplorationAction) action).widget
        assert blacklistedWidget in egs.widgets
        egs.widgetToIsBlacklistedMap[blacklistedWidget] = true
      }
    }
    return egs
  }

  static List exploreForward(Random random, ExploredGuiState egs, boolean doTerminate, boolean doReset, boolean doLogin)
  {
    boolean doExploreForward = false
    Map forwardExplorationOutput = null

    if (doTerminate || doReset || doLogin)
      return [doExploreForward, forwardExplorationOutput]

    doExploreForward = true

    List<Widget> actionableWidgets = egs.widgets.findAll { it.canBeActedUpon() && !egs.widgetToIsBlacklistedMap[it] }
    assert actionableWidgets.size() >= 1

    // The widgets with minimal "acted upon" count are the candidates to be acted upon.
    int minActedUponCount = egs.widgets.findAll {it.canBeActedUpon() && !egs.widgetToIsBlacklistedMap[it]}.collect {egs.widgetToActedUponCountMap[it]}.min()
    List<Widget> candidates = actionableWidgets.findAll {egs.widgetToActedUponCountMap[it] == minActedUponCount}
    assert candidates.size() >= 1

    Widget actedUponWidget = candidates[random.nextInt(candidates.size())]
    forwardExplorationOutput = [widget: actedUponWidget]

    boolean longClick
    (longClick, egs) = determineLongClickAndUpdateExploredGuiStateCounts(actedUponWidget, egs)
    forwardExplorationOutput.longClick = longClick

    return [doExploreForward, forwardExplorationOutput]
  }

  private static List determineLongClickAndUpdateExploredGuiStateCounts(Widget actedUponWidget, ExploredGuiState egs)
  {
    int actedUponCount = egs.widgetToActedUponCountMap[actedUponWidget]
    int longClickCount = egs.widgetToLongClickedCountMap[actedUponWidget]
    boolean longClick

    if (actedUponWidget.longClickable && !actedUponWidget.clickable && !actedUponWidget.checkable)
    {
      longClick = true
      egs.widgetToLongClickedCountMap[actedUponWidget]++

    } else if (actedUponWidget.longClickable)
    {
      if (!(actedUponCount <= 1).implies(longClickCount == 0))
        log.warn("Following expectation doesn't hold: (actedUponCount <= 1).implies(longClickCount == 0).\n" +
          "Actual clickedCount:     ${egs.widgetToActedUponCountMap[actedUponWidget]}.\n" +
          "Actual longClickedCount: ${egs.widgetToLongClickedCountMap[actedUponWidget]}")

      // The sequence of clicks (C) and long-clicks (LC) is:
      // C, LC, C, C, LC, C, C, LC, ..., C, C, LC, ...
      if (actedUponCount % 3 == 1)
      {

        longClick = true
        egs.widgetToLongClickedCountMap[actedUponWidget]++

      } else
        longClick = false

    } else
      longClick = false

    egs.widgetToActedUponCountMap[actedUponWidget]++

    return [longClick, egs]
  }

  static ExplorationAction interpretIntoAction(ExplorationStrategyState state, boolean doTerminate, boolean doReset, boolean doLogin, boolean doExploreForward, Map<String, Object> forwardExplorationOutput)
  {
    assert doTerminate ^ doReset ^ doLogin ^ doExploreForward
    assert doExploreForward.implies(forwardExplorationOutput != null)

    ExplorationAction action

    if (doExploreForward)
      action = newWidgetExplorationAction([
        timestampFunc: LocalDateTime.now(),
        widget: forwardExplorationOutput.widget as Widget,
        longClick: forwardExplorationOutput.longClick as Boolean])
    else if (doReset)
    {
      action = newResetAppExplorationAction() // newResetAppExplorationAction([timestampFunc: LocalDateTime.now()])

    } else if (doTerminate)
    {
      action = newTerminateExplorationAction([timestampFunc: LocalDateTime.now()])
    }
    else
    {
      action = null
      assert false: "Not yet implemented!"
    }

    // obsolete-to-do: to implement
    return action
  }


  static ExplorationStrategyState updateExplorationState(
    Stopwatch stopwatch,
    ExplorationStrategyState state,
    ExplorationAction currentAction,
    ExploreForwardState updatedExploreForwardState)
  {
    ExplorationStrategyState updatedState = state.clone()

    updatedState.exploreForwardState = updatedExploreForwardState

    if (state.actionIndex == 1)
    {
      stopwatch.reset()
      stopwatch.start()
    }

    updatedState.actionIndex++

    updatedState.exploreForwardState.lastExplorationAction = currentAction

    if (updatedState.terminationState.timeLimited)
      updatedState.terminationState.secondsElapsed = stopwatch.elapsed(TimeUnit.SECONDS)
    if (updatedState.terminationState.actionsLimited)
    {
      assert updatedState.terminationState.actionsLeft > 0 ||
        (updatedState.terminationState.actionsLeft == 0 && currentAction instanceof TerminateExplorationAction)

      updatedState.terminationState.actionsLeft--

    }

    updatedState.terminationState.lastActionWasReset = currentAction instanceof ResetAppExplorationAction

    return updatedState
  }

}
