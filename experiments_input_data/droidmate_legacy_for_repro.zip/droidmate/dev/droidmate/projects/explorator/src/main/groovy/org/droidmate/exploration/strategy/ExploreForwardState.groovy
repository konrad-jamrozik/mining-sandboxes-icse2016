// Copyright (c) 2013-2015 Saarland University Software Engineering Chair.
// All right reserved.
//
// Author: Konrad Jamrozik, jamrozik@st.cs.uni-saarland.de
//
// This file is part of the "DroidMate" project.
//
// www.droidmate.org

package org.droidmate.exploration.strategy

import groovy.transform.Canonical
import org.droidmate.exploration.IDeviceGuiModel
import org.droidmate.exploration.datatypes.ExplorationAction

@Canonical
class ExploreForwardState implements Serializable, Cloneable
{

  private static final long serialVersionUID = 1

  IDeviceGuiModel guiModel

  ExploredGuiState  currentlyExploredGuiState
  ExplorationAction lastExplorationAction

  @Override
  protected ExploreForwardState clone() throws CloneNotSupportedException
  {
    ExploreForwardState clone = (ExploreForwardState) super.clone()
    clone.guiModel = (IDeviceGuiModel) guiModel.clone()
    clone.currentlyExploredGuiState = currentlyExploredGuiState ?: null
    clone.lastExplorationAction = lastExplorationAction ?: null

    return clone
  }
}
